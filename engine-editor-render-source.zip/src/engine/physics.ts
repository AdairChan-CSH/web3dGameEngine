/**
 * Lightweight built-in physics: gravity, velocity integration, ground plane
 * collision and axis-aligned box collisions for the primitives.
 *
 * No external library — deliberately small and predictable so the values in the
 * Inspector mean what a user expects. Rotated objects collide with their
 * world-space AABB.
 */

import type { GameObject } from './scene';

export interface CollisionHit {
  /** the object that moved (the one whose script gets OnCollision) */
  self: GameObject;
  /** what it hit */
  other: GameObject | null;
  point: { x: number; y: number; z: number };
  normal: { x: number; y: number; z: number };
  relativeVelocity: { x: number; y: number; z: number };
}

export interface PhysicsOptions {
  gravity: number;
  groundY: number;
  friction: number;
  sleepVelocity: number;
}

export const DEFAULT_PHYSICS_OPTIONS: PhysicsOptions = {
  gravity: 18,
  groundY: 0,
  friction: 0.86,
  sleepVelocity: 0.08,
};

interface Extent { x: number; y: number; z: number }

export class PhysicsWorld {
  options: PhysicsOptions;
  private extents = new Map<string, Extent>();

  constructor(private three: any, options: Partial<PhysicsOptions> = {}) {
    this.options = { ...DEFAULT_PHYSICS_OPTIONS, ...options };
  }

  /** Half-size of an object's local bounding box, scaled (cached per object). */
  halfExtents(obj: GameObject): Extent {
    const cached = this.extents.get(obj.id);
    if (cached) return cached;

    let extent: Extent = { x: 0.5, y: 0.5, z: 0.5 };
    const mesh: any = obj.three;
    if (mesh && mesh.geometry) {
      if (!mesh.geometry.boundingBox) mesh.geometry.computeBoundingBox();
      const box = mesh.geometry.boundingBox;
      if (box) {
        extent = {
          x: Math.abs(box.max.x - box.min.x) / 2,
          y: Math.abs(box.max.y - box.min.y) / 2,
          z: Math.abs(box.max.z - box.min.z) / 2,
        };
      }
    } else {
      const box = new this.three.Box3().setFromObject(mesh);
      if (!box.isEmpty()) {
        const size = box.getSize(new this.three.Vector3());
        extent = { x: size.x / 2, y: size.y / 2, z: size.z / 2 };
      }
    }
    const out: Extent = {
      x: extent.x * Math.abs(obj.three.scale.x || 1),
      y: extent.y * Math.abs(obj.three.scale.y || 1),
      z: extent.z * Math.abs(obj.three.scale.z || 1),
    };
    this.extents.set(obj.id, out);
    return out;
  }

  invalidate(id: string): void { this.extents.delete(id); }
  invalidateAll(): void { this.extents.clear(); }

  /** One fixed step. `onHit` is called for every collision, both directions. */
  step(dt: number, objects: GameObject[], onHit?: (hit: CollisionHit) => void): void {
    if (dt <= 0) return;
    const bodies = objects.filter((o) => o.physics.usePhysics && o.three.visible);

    // 1. integrate dynamics
    for (const body of bodies) {
      if (body.physics.kinematic) continue;
      if (body.physics.useGravity) {
        body.velocity.y -= this.options.gravity * dt * Math.max(0.05, body.physics.mass);
      }
      body.three.position.x += body.velocity.x * dt;
      body.three.position.y += body.velocity.y * dt;
      body.three.position.z += body.velocity.z * dt;
    }

    // 2. ground plane
    for (const body of bodies) {
      const half = this.halfExtents(body);
      const bottom = body.three.position.y - half.y;
      if (bottom <= this.options.groundY) {
        const penetration = this.options.groundY - bottom;
        body.three.position.y += penetration;
        const impact = -body.velocity.y;
        if (body.velocity.y < 0) {
          body.velocity.y = impact > 0.4 ? impact * body.physics.bounce : 0;
        }
        body.velocity.x *= this.options.friction;
        body.velocity.z *= this.options.friction;
        if (Math.abs(body.velocity.x) < this.options.sleepVelocity) body.velocity.x = 0;
        if (Math.abs(body.velocity.z) < this.options.sleepVelocity) body.velocity.z = 0;
        if (!body.grounded) {
          body.grounded = true;
          onHit?.({
            self: body,
            other: null,
            point: { x: body.three.position.x, y: this.options.groundY, z: body.three.position.z },
            normal: { x: 0, y: 1, z: 0 },
            relativeVelocity: { x: body.velocity.x, y: -impact, z: body.velocity.z },
          });
        }
      } else {
        body.grounded = false;
      }
    }

    // 3. box vs box (n^2 but scenes are small; skipped for pairs sharing a parent)
    for (let i = 0; i < bodies.length; i++) {
      for (let j = i + 1; j < bodies.length; j++) {
        const a = bodies[i];
        const b = bodies[j];
        if (a.physics.kinematic && b.physics.kinematic) continue;
        if (!a.physics.collides || !b.physics.collides) continue;
        if (a.parent === b && b.parent === a) continue;
        const hit = this.resolvePair(a, b);
        if (hit) onHit?.(hit);
      }
    }

    // collision against static (non-physics) colliders flagged in the scene
    for (const body of bodies) {
      for (const solid of objects) {
        if (solid === body || solid.physics.usePhysics) continue;
        if (!solid.physics.collides || solid.type === 'Light' || solid.type === 'Camera') continue;
        const hit = this.resolvePair(body, solid, true);
        if (hit) onHit?.(hit);
      }
    }
  }

  /** Separating-axis resolution on the smallest penetration, returns a hit or null. */
  private resolvePair(a: GameObject, b: GameObject, staticB = false): CollisionHit | null {
    if (!a.three.visible || !b.three.visible) return null;
    const ha = this.halfExtents(a);
    const hb = this.halfExtents(b);

    const overlapX = ha.x + hb.x - Math.abs(a.three.position.x - b.three.position.x);
    const overlapY = ha.y + hb.y - Math.abs(a.three.position.y - b.three.position.y);
    const overlapZ = ha.z + hb.z - Math.abs(a.three.position.z - b.three.position.z);
    if (overlapX <= 0 || overlapY <= 0 || overlapZ <= 0) return null;

    // smallest overlap axis wins
    let axis: 'x' | 'y' | 'z' = 'x';
    let depth = overlapX;
    if (overlapY < depth) { axis = 'y'; depth = overlapY; }
    if (overlapZ < depth) { axis = 'z'; depth = overlapZ; }

    const dir = Math.sign((a.three.position as any)[axis] - (b.three.position as any)[axis]) || 1;
    const normal = { x: 0, y: 0, z: 0 } as any;
    normal[axis] = dir;

    const impact = Math.abs((a.velocity as any)[axis]);

    if (!a.physics.kinematic) {
      (a.three.position as any)[axis] += depth * dir * 0.5;
      const v = (a.velocity as any)[axis];
      if (v * dir < 0) {
        (a.velocity as any)[axis] = -v * a.physics.bounce;
        if (axis === 'x' || axis === 'z') (a.velocity as any)[axis] *= this.options.friction + 0.05;
      }
      if (axis === 'y' && dir > 0 && Math.abs((a.velocity as any).y) < 0.2) (a.velocity as any).y = 0;
    }
    if (!staticB && !b.physics.kinematic && b.physics.usePhysics) {
      (b.three.position as any)[axis] -= depth * dir * 0.5;
      const v = (b.velocity as any)[axis];
      (b.velocity as any)[axis] = v - dir * impact * b.physics.bounce * 0.5;
    }

    return {
      self: a,
      other: b,
      point: {
        x: (a.three.position.x + b.three.position.x) / 2,
        y: (a.three.position.y + b.three.position.y) / 2,
        z: (a.three.position.z + b.three.position.z) / 2,
      },
      normal,
      relativeVelocity: { x: a.velocity.x - b.velocity.x, y: a.velocity.y - b.velocity.y, z: a.velocity.z - b.velocity.z },
    };
  }

  /** Convenience used by the API layer + scripts. */
  applyImpulse(obj: GameObject, x: number, y: number, z: number): void {
    obj.velocity.x += x;
    obj.velocity.y += y;
    obj.velocity.z += z;
  }

  setVelocity(obj: GameObject, x: number, y: number, z: number): void {
    obj.velocity.set(x, y, z);
  }

  getVelocity(obj: GameObject): { x: number; y: number; z: number } {
    return { x: obj.velocity.x, y: obj.velocity.y, z: obj.velocity.z };
  }
}
