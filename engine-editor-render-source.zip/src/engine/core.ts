/**
 * EngineCore — the heart of the editor.
 *
 * Responsibilities
 *  • boots three.js from the CDN into a container element (renderer, cameras, sky, ground)
 *  • owns the scene graph, script runtime, physics world, undo stack and persistence
 *  • runs the frame loop: tweens → scripts → physics → cameras → render → stats
 *  • exposes the documented external API (window.Engine / window.GameEngine) and
 *    the postMessage + WebSocket/poll bridges for outside-the-page control
 *
 * React never touches three.js directly: panels subscribe to 'change' / 'stats' /
 * 'remote' notifications and call the methods here.
 */

import { loadThree, type ThreeBundle } from './three-loader';
import {
  SceneGraph,
  GameObject,
  DEFAULT_PHYSICS,
  OBJECT_TYPES,
} from './scene';
import {
  PREFAB_FORMAT,
  capturePrefabNode,
  newPrefabId,
  prefabNodeToSerialized,
  prefabScriptNames,
  prefabStats,
  prefabSummary,
  readPrefabStore,
  uniquePrefabName,
  writePrefabStore,
  type Prefab,
  type PrefabNode,
  type PrefabScriptSource,
} from './prefabs';
import { ScriptRuntime, type ScriptHost } from './script-vm';
import { PhysicsWorld, type CollisionHit } from './physics';
import { ExternalBridge, RemoteControl, type BridgeResult, type BridgeTarget } from './bridge';
import { EXAMPLE_SCRIPTS, NEW_SCRIPT_TEMPLATE, buildDemoScene, scriptId } from './demo';
import { assetId as makeAssetId, getAsset, putAsset, deleteAsset, isIndexedDbAvailable } from './assets';
import type {
  EnvironmentSettings,
  GizmoMode,
  LogEntry,
  LogLevel,
  MaterialParams,
  ObjectType,
  PlayState,
  ProjectJSON,
  ScriptAsset,
  ScriptInstance,
  SerializedObject,
  ViewTab,
  EngineStats,
  LightParams,
  CameraParams,
  PhysicsParams,
  SceneHealthGizmo,
  SceneHealthIssue,
  SceneHealthReport,
  SceneRepairReport,

} from './types';

export type EngineEvent = 'change' | 'stats' | 'remote';

/** Ground texture shipped with the editor (loaded over the network, optional). */
const GROUND_TEXTURE_URL =
  'https://d38kszyerljeoa.cloudfront.net/posts/scb_3b3a3375f54e7dc88ba635a1/c2e98e4711ae4e24.webp';

const STORAGE_CURRENT = 'webforge.project.current';
const STORAGE_PROJECTS = 'webforge.projects';

export const DEFAULT_ENVIRONMENT: EnvironmentSettings = {
  sky: 'dusk',
  fog: 0.6,
  ground: true,
  grid: true,
  shadows: true,
  ambient: 0.65,
  exposure: 1.05,
};

const SKY_PRESETS: Record<EnvironmentSettings['sky'], { top: string; mid: string; bottom: string; fog: string }> = {
  dusk: { top: '#070c18', mid: '#16233c', bottom: '#402c46', fog: '#121a26' },
  noon: { top: '#2c5c96', mid: '#79a9d8', bottom: '#cdd9e6', fog: '#9fb6ca' },
  night: { top: '#02040a', mid: '#0a1526', bottom: '#101a2c', fog: '#070c16' },
  neon: { top: '#0a0618', mid: '#2a1046', bottom: '#3d0f4a', fog: '#150b26' },
};

export const EASINGS: Record<string, (t: number) => number> = {
  linear: (t) => t,
  easeIn: (t) => t * t,
  easeOut: (t) => 1 - (1 - t) * (1 - t),
  easeInOut: (t) => (t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2),
  sine: (t) => 0.5 - 0.5 * Math.cos(Math.PI * t),
  bounce: (t) => {
    const n1 = 7.5625;
    const d1 = 2.75;
    if (t < 1 / d1) return n1 * t * t;
    if (t < 2 / d1) return n1 * (t -= 1.5 / d1) * t + 0.75;
    if (t < 2.5 / d1) return n1 * (t -= 2.25 / d1) * t + 0.9375;
    return n1 * (t -= 2.625 / d1) * t + 0.984375;
  },
};

interface TweenKey { property: 'position' | 'rotation' | 'scale'; from: number[]; to: number[] }

interface Tween {
  id: string;
  target: GameObject;
  keys: TweenKey[];
  duration: number;
  elapsed: number;
  loop: boolean;
  yoyo: boolean;
  reverse: boolean;
  easing: string;
  base: { position: number[]; rotation: number[]; scale: number[] };
}

interface UndoEntry { label: string; undo: () => void; redo: () => void }

const DEG = Math.PI / 180;

function download(filename: string, content: string | Blob, mime = 'application/json'): void {
  const blob = content instanceof Blob ? content : new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 4000);
}

function vec3From(a: any, b?: any, c?: any): { x: number; y: number; z: number } {
  if (Array.isArray(a)) return { x: Number(a[0]) || 0, y: Number(a[1]) || 0, z: Number(a[2]) || 0 };
  if (a && typeof a === 'object') return { x: Number(a.x) || 0, y: Number(a.y) || 0, z: Number(a.z) || 0 };
  return { x: Number(a) || 0, y: Number(b) || 0, z: Number(c) || 0 };
}

export class EngineCore implements BridgeTarget {
  /* three.js objects */
  bundle: ThreeBundle | null = null;
  three: any = null;
  renderer: any = null;
  scene: any = null;
  editorCamera: any = null;
  gameCamera: any = null;
  orbit: any = null;
  transformControls: any = null;
  transformHelper: any = null;
  selectionHelper: any = null;
  grid: any = null;
  ground: any = null;
  sun: any = null;
  ambient: any = null;
  hemi: any = null;

  graph!: SceneGraph;
  physics!: PhysicsWorld;
  runtime: ScriptRuntime | null = null;

  scripts: ScriptAsset[] = [];
  /** Reusable object subtrees, persisted in browser storage so every scene can use them. */
  prefabs: Prefab[] = [];
  private prefabPlaceSeq = 0;
  logs: LogEntry[] = [];
  projectName = 'Untitled Project';
  environment: EnvironmentSettings = { ...DEFAULT_ENVIRONMENT };

  playState: PlayState = 'stopped';
  gizmoMode: GizmoMode = 'translate';
  snapEnabled = false;
  snapSize = 0.5;
  viewTab: ViewTab = 'scene';
  selectedId: string | null = null;

  stats: EngineStats = { fps: 0, drawCalls: 0, triangles: 0, objects: 0, scripts: 0, textures: 0, geometries: 0 };

  ready = false;
  loading = true;
  loadError: string | null = null;
  threeSourceLabel = 'loading…';

  remote: RemoteControl | null = null;
  bridge: ExternalBridge | null = null;
  api: Record<string, any> = {};
  bridgeHandled = 0;

  /* react-facing version counters */
  version = 0;
  statsVersion = 0;
  remoteVersion = 0;

  private canvasHost: HTMLElement | null = null;
  private resizeObserver: any = null;
  private rafId = 0;
  private lastTime = 0;
  private frameCount = 0;
  private elapsed = 0;
  private currentDelta = 1 / 60;
  private fixedStep = 1 / 60;
  private fixedAccum = 0;
  private fpsSamples: number[] = [];
  private lastStatsPush = 0;

  private listeners: Record<EngineEvent, Set<() => void>> = { change: new Set(), stats: new Set(), remote: new Set() };
  private eventHandlers = new Map<string, Set<Function>>();

  private undoStack: UndoEntry[] = [];
  private redoStack: UndoEntry[] = [];
  private editStart = new Map<string, SerializedObject>();

  private tweens: Tween[] = [];
  private tweenSeq = 1;
  private playSnapshot: ProjectJSON | null = null;

  private keysDown = new Set<string>();
  private keysPressed = new Set<string>();
  private keysUp = new Set<string>();
  private touchAxis = { x: 0, y: 0 };
  private mouseLook = { yaw: 0, pitch: 0, dx: 0, dy: 0 };
  private pointerDown: { x: number; y: number } | null = null;
  private draggingGizmo = false;
  /** The three.js node the gizmo is currently attached to (null while detached). */
  private gizmoTarget: any = null;

  private logId = 1;
  private sceneDirty = false;
  private autosaveTimer: number | null = null;
  private objectSeq = 1;
  private globalListenersAttached = false;
  private disposed = false;

  /* ------------------------------------------------------------------ boot */

  async init(): Promise<void> {
    this.loading = true;
    this.loadError = null;
    this.notify('change');
    try {
      this.bundle = await loadThree();
      this.three = this.bundle.THREE;
      this.threeSourceLabel = `CDN · ${this.bundle.source} r${this.bundle.version}`;
      this.buildRenderer();
      this.buildScene();
      this.buildCameras();
      this.buildRuntime();
      this.buildBridge();
      this.attachGlobalListeners();
      this.loadInitialProject();
      this.loadPrefabs();
      this.startLoop();
      this.ready = true;
      this.log('info', 'WebForge engine ready — three.js loaded from ' + this.threeSourceLabel);
      this.log('log', 'Press Play, then use WASD + Space. Click an object to select it, or an object while playing to fire its OnClick.');
    } catch (err) {
      this.loadError = err instanceof Error ? err.message : String(err);
      // eslint-disable-next-line no-console
      console.error('[engine] init failed', err);
      this.log('error', `Engine failed to start: ${this.loadError}`);
    } finally {
      this.loading = false;
      this.notify('change');
    }
  }

  private buildRenderer(): void {
    const three = this.three;
    let renderer: any;
    try {
      renderer = new three.WebGLRenderer({ antialias: true, powerPreference: 'high-performance', preserveDrawingBuffer: true });
    } catch (err) {
      throw new Error('WebGL is not available in this browser, so the 3D viewport cannot start.');
    }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(960, 540, false);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = three.PCFSoftShadowMap;
    renderer.toneMapping = three.ACESFilmicToneMapping;
    renderer.toneMappingExposure = this.environment.exposure;
    if ('outputColorSpace' in renderer) renderer.outputColorSpace = three.SRGBColorSpace;
    renderer.domElement.style.display = 'block';
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';
    renderer.domElement.style.touchAction = 'none';
    renderer.domElement.setAttribute('aria-label', '3D viewport');
    (renderer.domElement as HTMLElement).tabIndex = 0;
    this.renderer = renderer;

    // HDR-ish studio reflections so PBR metals read properly
    if (this.bundle?.RoomEnvironment) {
      try {
        const pmrem = new three.PMREMGenerator(renderer);
        const env = new this.bundle.RoomEnvironment();
        this.sceneEnvTarget = pmrem.fromScene(env, 0.04);
        env.dispose?.();
      } catch {
        this.sceneEnvTarget = null;
      }
    }
  }

  private sceneEnvTarget: any = null;

  private buildScene(): void {
    const three = this.three;
    this.scene = new three.Scene();
    if (this.sceneEnvTarget) this.scene.environment = this.sceneEnvTarget.texture;

    // the graph needs BOTH: the three.js namespace for constructors and the real
    // THREE.Scene as the Object3D that root-level nodes are parented into.
    this.graph = new SceneGraph(three, this.scene);
    this.graph.engine = this;
    // the engine owns the scene reference, so keep the graph's root in sync with it
    this.graph.setSceneRoot(this.scene);
    this.physics = new PhysicsWorld(three);

    this.buildSky();
    this.buildLights();
    this.buildGround();
  }

  private buildSky(): void {
    const three = this.three;
    const preset = SKY_PRESETS[this.environment.sky] ?? SKY_PRESETS.dusk;
    const skyMat = new three.ShaderMaterial({
      side: three.BackSide,
      depthWrite: false,
      uniforms: {
        topColor: { value: new three.Color(preset.top) },
        midColor: { value: new three.Color(preset.mid) },
        bottomColor: { value: new three.Color(preset.bottom) },
      },
      vertexShader:
        'varying vec3 vPos; void main() { vPos = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
      fragmentShader:
        'uniform vec3 topColor; uniform vec3 midColor; uniform vec3 bottomColor; varying vec3 vPos;' +
        ' void main() { float h = normalize(vPos).y;' +
        ' vec3 c = mix(bottomColor, midColor, smoothstep(-0.25, 0.25, h));' +
        ' c = mix(c, topColor, smoothstep(0.12, 0.8, h));' +
        ' gl_FragColor = vec4(c, 1.0); }',
    });
    this.sky = new three.Mesh(new three.SphereGeometry(500, 40, 24), skyMat);
    this.sky.userData.noPick = true;
    this.scene.add(this.sky);
    this.scene.fog = new three.Fog(new three.Color(preset.fog), 70 * this.environment.fog, 300 * this.environment.fog);
  }

  private buildLights(): void {
    const three = this.three;
    this.sun = new three.DirectionalLight(0xfff0d8, 2.1);
    this.sun.position.set(18, 26, 14);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.width = 2048;
    this.sun.shadow.mapSize.height = 2048;
    this.sun.shadow.camera.near = 1;
    this.sun.shadow.camera.far = 120;
    this.sun.shadow.camera.left = -40;
    this.sun.shadow.camera.right = 40;
    this.sun.shadow.camera.top = 40;
    this.sun.shadow.camera.bottom = -40;
    this.sun.shadow.bias = -0.0006;
    this.scene.add(this.sun);

    this.hemi = new three.HemisphereLight(0xa8ccff, 0x202634, this.environment.ambient);
    this.scene.add(this.hemi);
    this.ambient = new three.AmbientLight(0xffffff, 0.18);
    this.scene.add(this.ambient);
  }

  private buildGround(): void {
    const three = this.three;
    const material = new three.MeshStandardMaterial({ color: 0x20262f, roughness: 0.92, metalness: 0.08 });
    this.ground = new three.Mesh(new three.PlaneGeometry(400, 400), material);
    this.ground.rotation.x = -Math.PI / 2;
    this.ground.position.y = -0.01;
    this.ground.receiveShadow = true;
    this.ground.userData.noPick = true;
    this.ground.visible = this.environment.ground;
    this.scene.add(this.ground);

    // optional texture (never blocks the scene: assigned only after a successful load)
    const loader = new three.TextureLoader();
    loader.setCrossOrigin?.('anonymous');
    try {
      loader.load(
        GROUND_TEXTURE_URL,
        (texture: any) => {
          texture.wrapS = three.RepeatWrapping;
          texture.wrapT = three.RepeatWrapping;
          texture.repeat.set(48, 48);
          texture.anisotropy = Math.min(8, this.renderer?.capabilities?.getMaxAnisotropy?.() ?? 4);
          if ('colorSpace' in texture) texture.colorSpace = three.SRGBColorSpace;
          material.map = texture;
          material.color.set(0x8a93a3);
          material.needsUpdate = true;
        },
        undefined,
        () => {
          this.log('warn', 'Ground texture could not be loaded — using the flat procedural ground colour.');
        },
      );
    } catch {
      /* keep the flat ground */
    }

    this.grid = new three.GridHelper(200, 200, 0x46618c, 0x232c3a);
    (this.grid.material as any).transparent = true;
    (this.grid.material as any).opacity = 0.65;
    this.grid.position.y = 0.002;
    this.grid.userData.noPick = true;
    this.grid.visible = this.environment.grid;
    this.scene.add(this.grid);
  }

  private buildCameras(): void {
    const three = this.three;
    this.editorCamera = new three.PerspectiveCamera(50, 16 / 9, 0.1, 2000);
    this.editorCamera.position.set(14, 10, 17);

    this.gameCamera = new three.PerspectiveCamera(68, 16 / 9, 0.1, 2000);
    this.gameCamera.position.set(0, 2.2, 10);
    this.gameCamera.rotation.order = 'YXZ';

    const Orbit = this.bundle!.OrbitControls;
    this.orbit = new Orbit(this.editorCamera, this.renderer.domElement);
    this.orbit.enableDamping = true;
    this.orbit.dampingFactor = 0.08;
    this.orbit.maxPolarAngle = Math.PI * 0.495;
    this.orbit.target.set(0, 1.6, 0);
    this.orbit.update();

    const TransformControls = this.bundle!.TransformControls;
    this.transformControls = new TransformControls(this.editorCamera, this.renderer.domElement);
    this.transformControls.setSize(0.85);
    this.transformControls.setTranslationSnap(null);
    this.transformControls.setRotationSnap(null);
    this.transformControls.setScaleSnap(null);
    this.transformHelper = this.transformControls.getHelper ? this.transformControls.getHelper() : this.transformControls;
    this.scene.add(this.transformHelper);
    this.transformControls.enabled = false;

    this.transformControls.addEventListener('dragging-changed', (event: any) => {
      this.orbit.enabled = !event.value;
      this.draggingGizmo = !!event.value;
      if (event.value && this.selectedId) {
        this.beginEdit(this.selectedId);
      } else if (this.selectedId) {
        const label = this.gizmoMode === 'rotate' ? 'Rotate object' : this.gizmoMode === 'scale' ? 'Scale object' : 'Move object';
        this.endEdit(this.selectedId, label);
      }
    });
    this.transformControls.addEventListener('objectChange', () => {
      this.invalidateHalfExtents(this.selectedId);
      this.notify('change');
    });

    this.selectionHelper = new three.BoxHelper(new three.Object3D(), 0x59d0ff);
    (this.selectionHelper.material as any).depthTest = false;
    (this.selectionHelper.material as any).transparent = true;
    (this.selectionHelper.material as any).opacity = 0.55;
    this.selectionHelper.visible = false;
    this.selectionHelper.userData.noPick = true;
    this.scene.add(this.selectionHelper);
  }

  private buildRuntime(): void {
    const host: ScriptHost = {
      log: (level, message, info) => this.log(level as LogLevel, message, info),
      clock: () => ({
        delta: this.currentDelta,
        elapsed: this.elapsed,
        frame: this.frameCount,
        fixed: this.fixedStep,
      }),
      input: {
        down: (key) => this.keysDown.has(normalizeKey(key)),
        pressed: (key) => this.keysPressed.has(normalizeKey(key)),
        up: (key) => this.keysUp.has(normalizeKey(key)),
        axis: (name) => this.getAxis(name),
        mouseDelta: () => ({
          x: this.mouseLook.yaw * 57.29578,
          y: -this.mouseLook.pitch * 57.29578,
        }),
      },
      instantiate: (type, position) => {
        const obj = this.createObject(sanitizeType(type), undefined, position);
        // runtime primitives are physical so they fall and bounce out of the box
        if (obj.threeMaterial) {
          obj.physics.usePhysics = true;
          obj.physics.useGravity = true;
          obj.physics.bounce = 0.4;
        }
        return obj;
      },
      destroy: (obj) => {
        if (obj && obj.__kind === 'gameobject') this.deleteObject(obj.id, false);
      },
      find: (name) => this.graph.find(name),
      emit: (instance, name, payload) => this.emitEvent(name, payload ?? { source: instance.className }),
      onFieldWrite: () => { this.sceneDirty = true; },
    };
    this.runtime = new ScriptRuntime({ three: this.three, host });
    this.ensureScriptLibrary();
    for (const asset of this.scripts) this.compileAsset(asset);
  }

  /* --------------------------------------------------------- project load */

  private ensureScriptLibrary(): void {
    for (const example of EXAMPLE_SCRIPTS) {
      if (!this.scripts.some((s) => s.name === example.name)) this.scripts.push({ ...example });
    }
    if (!this.scripts.length) this.scripts.push({ ...EXAMPLE_SCRIPTS[0] });
  }

  private loadInitialProject(): void {
    const raw = this.readStorage(STORAGE_CURRENT);
    if (raw) {
      try {
        const project = JSON.parse(raw) as ProjectJSON;
        this.applyProject(project, false);
        this.projectName = project.name || 'Untitled Project';
        this.log('info', `Restored "${this.projectName}" from the browser's local storage.`);
        return;
      } catch (err) {
        this.log('warn', `Saved project could not be read (${err instanceof Error ? err.message : String(err)}) — loading the demo scene instead.`);
      }
    }
    this.loadDemoScene();
  }

  loadDemoScene(): void {
    this.stop(true);
    this.graph.clear();
    this.ensureScriptLibrary();
    buildDemoScene(this);
    this.projectName = 'Demo Playground';
    this.environment = { ...DEFAULT_ENVIRONMENT };
    this.applyEnvironment();
    this.syncGizmo();
    this.focusSelected(true);
    this.log('info', 'Demo scene built: player capsule, orbiting sphere, spinning props, floating cubes, pulse core, spawner and clickable crates.');
    this.notify('change');
    this.scheduleAutosave();
  }

  /* ------------------------------------------------------------ API: boot */

  /* ----------------------------------------------------------- environment */

  setEnvironment(patch: Partial<EnvironmentSettings>): void {
    Object.assign(this.environment, patch);
    this.applyEnvironment();
    this.notify('change');
    this.scheduleAutosave();
  }

  private applyEnvironment(): void {
    const env = this.environment;
    if (this.ground) this.ground.visible = env.ground;
    if (this.grid) this.grid.visible = env.grid;
    if (this.renderer) {
      this.renderer.shadowMap.enabled = env.shadows;
      this.renderer.toneMappingExposure = env.exposure;
    }
    if (this.hemi) this.hemi.intensity = env.ambient;
    if (this.scene?.fog) {
      const preset = SKY_PRESETS[env.sky] ?? SKY_PRESETS.dusk;
      this.scene.fog.near = 70 * env.fog;
      this.scene.fog.far = 300 * env.fog;
      this.scene.fog.color.set(preset.fog);
    }
    // sky + sun tint follow the preset
    const preset = SKY_PRESETS[env.sky] ?? SKY_PRESETS.dusk;
    if (this.sky?.material?.uniforms) {
      this.sky.material.uniforms.topColor.value.set(preset.top);
      this.sky.material.uniforms.midColor.value.set(preset.mid);
      this.sky.material.uniforms.bottomColor.value.set(preset.bottom);
    }
    if (this.sun) this.sun.intensity = env.sky === 'night' ? 0.9 : env.sky === 'noon' ? 2.8 : 2.1;
  }

  /* --------------------------------------------------------- view / input */

  mountViewport(el: HTMLElement | null): void {
    if (!this.renderer) return;
    if (this.canvasHost === el) return;
    const canvas = this.renderer.domElement;
    if (canvas.parentElement) canvas.parentElement.removeChild(canvas);
    this.canvasHost = el;
    if (!el) return;

    el.appendChild(canvas);

    if (this.resizeObserver) {
      try { this.resizeObserver.disconnect(); } catch { /* ignore */ }
      this.resizeObserver = null;
    }
    if (typeof ResizeObserver !== 'undefined') {
      this.resizeObserver = new ResizeObserver(() => this.resize());
      this.resizeObserver.observe(el);
    }
    this.resize();
  }

  resize(): void {
    if (!this.renderer || !this.canvasHost) return;
    const width = Math.max(1, this.canvasHost.clientWidth);
    const height = Math.max(1, this.canvasHost.clientHeight);
    this.renderer.setSize(width, height, false);
    if (this.editorCamera) {
      this.editorCamera.aspect = width / height;
      this.editorCamera.updateProjectionMatrix();
    }
    if (this.gameCamera) {
      this.gameCamera.aspect = width / height;
      this.gameCamera.updateProjectionMatrix();
    }
  }

  setViewTab(tab: ViewTab): void {
    this.viewTab = tab;
    if (tab !== 'game' && typeof document !== 'undefined' && document.pointerLockElement) {
      document.exitPointerLock?.();
    }
    this.notify('change');
  }

  setGizmoMode(mode: GizmoMode): void {
    this.gizmoMode = mode;
    if (this.transformControls) this.transformControls.setMode(mode);
    this.notify('change');
  }

  setSnap(enabled: boolean, size?: number): void {
    this.snapEnabled = enabled;
    if (size !== undefined) this.snapSize = size;
    this.applySnap();
    this.notify('change');
  }

  private applySnap(): void {
    if (!this.transformControls) return;
    const on = this.snapEnabled;
    this.transformControls.setTranslationSnap(on ? this.snapSize : null);
    this.transformControls.setRotationSnap(on ? this.snapSize * DEG * 10 : null);
    this.transformControls.setScaleSnap(on ? Math.max(0.05, this.snapSize / 2) : null);
  }

  getAxis(name: string): number {
    const key = String(name).toLowerCase();
    const down = (k: string) => this.keysDown.has(k);
    if (key === 'horizontal' || key === 'x') {
      let v = 0;
      if (down('a') || down('arrowleft')) v -= 1;
      if (down('d') || down('arrowright')) v += 1;
      return Math.max(-1, Math.min(1, v + this.touchAxis.x));
    }
    if (key === 'vertical' || key === 'z') {
      let v = 0;
      if (down('s') || down('arrowdown')) v -= 1;
      if (down('w') || down('arrowup')) v += 1;
      return Math.max(-1, Math.min(1, v + this.touchAxis.y));
    }
    return 0;
  }

  /** Used by the on-screen touch stick on small screens. */
  setTouchAxis(x: number, y: number): void {
    this.touchAxis.x = Math.max(-1, Math.min(1, x));
    this.touchAxis.y = Math.max(-1, Math.min(1, y));
  }

  pressVirtualKey(key: string, down: boolean): void {
    const k = normalizeKey(key);
    if (down) {
      if (!this.keysDown.has(k)) this.keysPressed.add(k);
      this.keysDown.add(k);
    } else {
      this.keysDown.delete(k);
      this.keysUp.add(k);
    }
  }

  /* -------------------------------------------------------- object editing */

  createObject(type: ObjectType, name?: string, position?: any, parent?: GameObject | null): GameObject {
    const obj = this.graph.create(type, name, parent ?? null);
    if (position) {
      const p = vec3From(position);
      obj.three.position.set(p.x, p.y, p.z);
    }
    this.syncGizmo();
    this.log('log', `Created ${type} "${obj.name}"`);
    this.notify('change');
    this.scheduleAutosave();
    this.pushUndo({
      label: `Create ${obj.name}`,
      undo: () => { this.graph.remove(obj.id); this.syncGizmo(); this.notify('change'); },
      redo: () => { this.restoreObject(obj.serialize(), null); },
    });
    return obj;
  }

  deleteObject(id: string, record = true): GameObject | null {
    const obj = this.graph.get(id);
    if (!obj) return null;
    const def = obj.serialize();
    const parentId = obj.parent ? obj.parent.id : null;
    if (record) {
      this.pushUndo({
        label: `Delete ${obj.name}`,
        undo: () => { this.restoreObject(def, parentId); },
        redo: () => { this.graph.remove(def.id); this.syncGizmo(); this.notify('change'); },
      });
    }
    if (this.selectedId === id) this.select(null);
    this.graph.remove(id);
    this.physics.invalidate(id);
    // the deleted node may be the one the gizmo was holding on to
    this.syncGizmo();
    this.log('log', `Deleted "${def.name}"`);
    this.notify('change');
    this.scheduleAutosave();
    return obj;
  }
  duplicateObject(id: string): GameObject | null {
    const obj = this.graph.get(id);
    if (!obj) return null;
    const def = obj.serialize();
    const clone = this.restoreObject({ ...def, name: this.graph.uniqueName(obj.name) }, obj.parent ? obj.parent.id : null);
    this.select(clone.id);
    return clone;
  }

  renameObject(id: string, name: string): void {
    const obj = this.graph.get(id);
    if (!obj || !name.trim()) return;
    const before = obj.name;
    obj.rename(name.trim());
    this.pushUndo({
      label: 'Rename object',
      undo: () => { this.graph.get(id)?.rename(before); this.notify('change'); },
      redo: () => { this.graph.get(id)?.rename(name.trim()); this.notify('change'); },
    });
    this.notify('change');
    this.scheduleAutosave();
  }

  setParent(childId: string, parentId: string | null): void {
    const child = this.graph.get(childId);
    if (!child) return;
    const beforeParent = child.parent ? child.parent.id : null;
    const parent = parentId ? this.graph.get(parentId) ?? null : null;
    this.graph.reparent(child, parent);
    this.pushUndo({
      label: 'Reparent object',
      undo: () => { const c = this.graph.get(childId); if (c) this.graph.reparent(c, beforeParent ? this.graph.get(beforeParent) ?? null : null); this.syncGizmo(); this.notify('change'); },
      redo: () => { const c = this.graph.get(childId); if (c) this.graph.reparent(c, parentId ? this.graph.get(parentId) ?? null : null); this.syncGizmo(); this.notify('change'); },
    });
    this.syncGizmo();
    this.notify('change');
  }

  /** Rebuild an object (and its components) from a serialized definition. */
  restoreObject(def: SerializedObject, parentId: string | null): GameObject {
    const obj = this.graph.create(def.type, def.name, parentId ? this.graph.get(parentId) ?? null : null);
    obj.rename(def.name);
    obj.three.position.set(def.position[0], def.position[1], def.position[2]);
    obj.three.rotation.set(def.rotation[0] * DEG, def.rotation[1] * DEG, def.rotation[2] * DEG);
    obj.three.scale.set(def.scale[0], def.scale[1], def.scale[2]);
    obj.three.visible = def.visible;
    if (def.material && obj.materialParams) obj.applyMaterialParams(def.material);
    if (def.light && obj.lightParams) obj.applyLightParams(def.light);
    if (def.camera && obj.cameraParams) obj.applyCameraParams(def.camera);
    if (def.physics) Object.assign(obj.physics, def.physics);
    obj.isPlayer = !!def.isPlayer;
    obj.assetId = def.assetId ?? null;

    if (def.assetId) void this.hydrateModel(obj, def.assetId);
    if (def.material?.textureAssetId) void this.applyTextureFromAsset(obj, def.material.textureAssetId);

    for (const spec of def.scripts ?? []) {
      const instance = this.attachScript(obj, spec.scriptName, spec.fields);
      if (instance) instance.enabled = spec.enabled !== false;
    }
    this.syncGizmo();
    this.notify('change');
    return obj;
  }

  select(id: string | null): void {
    this.selectedId = id;
    const obj = id ? this.graph.get(id) : null;
    if (obj) {
      if (this.selectionHelper) {
        (this.selectionHelper as any).setFromObject(obj.three);
        this.selectionHelper.visible = true;
      }
    } else if (this.selectionHelper) {
      this.selectionHelper.visible = false;
    }
    // the gizmo is only ever attached/detached inside syncGizmo()
    this.syncGizmo();
    this.notify('change');
  }

  /**
   * True only when `node` is reachable from this engine's scene by walking the parent
   * chain — the exact condition three.js's TransformControls checks before it logs
   * "The attached 3D object must be a part of the scene graph."
   */
  private isInScene(node: any): boolean {
    if (!node || !this.scene) return false;
    let current: any = node;
    let guard = 0;
    while (current && guard++ < 10000) {
      if (current === this.scene) return true;
      current = current.parent;
    }
    return false;
  }

  /**
   * Reconcile the gizmo with the current selection. Safe to call at any time, from any
   * code path: it returns silently until the engine is ready and is a cheap identity
   * comparison when nothing changed (re-attaching would reset the gizmo mid-drag).
   */
  syncGizmo(): void {
    const controls = this.transformControls;
    if (!controls || !this.scene || !this.three) return;

    const obj = this.selectedId && this.graph ? this.graph.get(this.selectedId) ?? null : null;
    const node: any = obj ? obj.three : null;

    if (!node || !this.isInScene(node)) {
      if (this.gizmoTarget || controls.object) {
        try { controls.detach(); } catch { /* a stale three.js reference must never throw */ }
      }
      this.gizmoTarget = null;
      try { controls.enabled = false; } catch { /* ignore */ }
      if (this.selectionHelper) this.selectionHelper.visible = false;
      // the selection points at an object the graph no longer contains: drop it so the
      // Inspector stops showing a dead selection
      if (this.selectedId && !this.graph.get(this.selectedId)) {
        this.selectedId = null;
        this.notify('change');
      }
      return;
    }

    if (this.gizmoTarget !== node) {
      try {
        controls.attach(node);
      } catch {
        this.gizmoTarget = null;
        return;
      }
      this.gizmoTarget = node;
      try {
        controls.setMode(this.gizmoMode);
        this.applySnap();
      } catch { /* ignore */ }
    }
    try { controls.enabled = true; } catch { /* ignore */ }
  }

  getSelected(): GameObject | null {
    return this.selectedId ? this.graph.get(this.selectedId) ?? null : null;
  }

  focusSelected(reset = false): void {
    const obj = this.getSelected();
    if (!this.orbit || !this.editorCamera) return;
    if (!obj) {
      this.orbit.target.set(0, 1.6, 0);
      this.editorCamera.position.set(14, 10, 17);
      this.orbit.update();
      return;
    }
    const box = new this.three.Box3().setFromObject(obj.three);
    const center = box.getCenter(new this.three.Vector3());
    const size = box.getSize(new this.three.Vector3());
    const radius = Math.max(2, Math.max(size.x, size.y, size.z));
    this.orbit.target.copy(center);
    if (reset || true) this.editorCamera.position.set(center.x + radius * 2.2, center.y + radius * 1.6, center.z + radius * 2.6);
    this.orbit.update();
    this.notify('change');
  }

  invalidateHalfExtents(id: string | null): void {
    if (id) this.physics.invalidate(id);
  }

  /* ----------------------------------------------------------- components */

  setMaterialParams(id: string, patch: Partial<MaterialParams>, record = true): void {
    const obj = this.graph.get(id);
    if (!obj) return;
    const before = record ? obj.serialize() : null;
    obj.applyMaterialParams(patch);
    if (before) this.pushObjectUndo(id, 'Change material', before);
    this.notify('change');
    this.scheduleAutosave();
  }

  setLightParams(id: string, patch: Partial<LightParams>, record = true): void {
    const obj = this.graph.get(id);
    if (!obj) return;
    const before = record ? obj.serialize() : null;
    obj.applyLightParams(patch);
    if (before) this.pushObjectUndo(id, 'Change light', before);
    this.notify('change');
    this.scheduleAutosave();
  }

  setCameraParams(id: string, patch: Partial<CameraParams>, record = true): void {
    const obj = this.graph.get(id);
    if (!obj) return;
    const before = record ? obj.serialize() : null;
    obj.applyCameraParams(patch);
    if (patch.isMain) {
      // only one Main Camera at a time — the Game view follows it
      for (const other of this.graph.all()) {
        if (other.id !== id && other.cameraParams?.isMain) other.applyCameraParams({ isMain: false });
      }
    }
    if (before) this.pushObjectUndo(id, 'Change camera', before);
    this.notify('change');
    this.scheduleAutosave();
  }

  setPhysicsParams(id: string, patch: Partial<PhysicsParams>, record = true): void {
    const obj = this.graph.get(id);
    if (!obj) return;
    const before = record ? obj.serialize() : null;
    Object.assign(obj.physics, patch);
    if (patch.useGravity === false) obj.velocity.y = Math.min(0, obj.velocity.y);
    if (patch.usePhysics === false) obj.velocity.set(0, 0, 0);
    if (before) this.pushObjectUndo(id, 'Change physics', before);
    this.notify('change');
    this.scheduleAutosave();
  }

  /* Begin/commit helpers used by the Inspector + gizmo for undo granularity. */
  beginEdit(id: string): void {
    const obj = this.graph.get(id);
    if (obj) this.editStart.set(id, obj.serialize());
  }

  endEdit(id: string, label = 'Edit object'): void {
    const before = this.editStart.get(id);
    const obj = this.graph.get(id);
    if (!before || !obj) return;
    this.editStart.delete(id);
    const after = obj.serialize();
    if (JSON.stringify(before) === JSON.stringify(after)) return;
    this.pushObjectUndo(id, label, before, after);
  }

  private pushObjectUndo(id: string, label: string, before: SerializedObject, after?: SerializedObject): void {
    const obj = this.graph.get(id);
    const afterDef = after ?? (obj ? obj.serialize() : null);
    if (!afterDef) return;
    this.pushUndo({
      label,
      undo: () => { const target = this.graph.get(id); if (target) this.applySerializedState(target, before); this.notify('change'); },
      redo: () => { const target = this.graph.get(id); if (target) this.applySerializedState(target, afterDef); this.notify('change'); },
    });
  }

  private pushTransformUndo(id: string, label: string, before: SerializedObject, after: SerializedObject): void {
    this.pushUndo({
      label,
      undo: () => { const t = this.graph.get(id); if (t) this.applySerializedState(t, before); this.notify('change'); },
      redo: () => { const t = this.graph.get(id); if (t) this.applySerializedState(t, after); this.notify('change'); },
    });
  }

  private applySerializedState(obj: GameObject, def: SerializedObject): void {
    obj.three.position.set(def.position[0], def.position[1], def.position[2]);
    obj.three.rotation.set(def.rotation[0] * DEG, def.rotation[1] * DEG, def.rotation[2] * DEG);
    obj.three.scale.set(def.scale[0], def.scale[1], def.scale[2]);
    obj.three.visible = def.visible;
    if (def.material && obj.materialParams) obj.applyMaterialParams(def.material);
    if (def.light && obj.lightParams) obj.applyLightParams(def.light);
    if (def.camera && obj.cameraParams) obj.applyCameraParams(def.camera);
    if (def.physics) Object.assign(obj.physics, def.physics);
    this.physics.invalidate(obj.id);
  }

  /* --------------------------------------------------------------- scripts */

  scriptList(): ScriptAsset[] { return this.scripts; }

  getScript(name: string): ScriptAsset | undefined {
    return this.scripts.find((s) => s.name === name || s.className === name);
  }

  compileAsset(asset: ScriptAsset): void {
    if (!this.runtime) return;
    const result = this.runtime.validate(asset.source, asset.name);
    asset.error = result.ok ? null : result.error;
    asset.className = result.className;
  }

  validateSource(source: string, name: string): { ok: boolean; error: { message: string; line: number } | null; className?: string } {
    if (!this.runtime) return { ok: false, error: { message: 'Engine is still loading', line: 1 } };
    return this.runtime.validate(source, name);
  }

  setScriptSource(id: string, source: string): void {
    const asset = this.scripts.find((s) => s.id === id);
    if (!asset) return;
    asset.source = source;
    this.compileAsset(asset);
    if (asset.error) {
      this.log('warn', `${asset.name}: line ${asset.error.line} — ${asset.error.message}`);
    }
    this.notify('change');
    this.scheduleAutosave();
  }

  createScript(name?: string, source?: string): ScriptAsset {
    const base = (name || 'NewBehaviour').replace(/[^A-Za-z0-9_]/g, '');
    let finalName = base || 'NewBehaviour';
    let i = 1;
    while (this.scripts.some((s) => s.name === finalName)) finalName = `${base}${i++}`;
    const asset: ScriptAsset = {
      id: scriptId(finalName) + '_' + Math.random().toString(36).slice(2, 6),
      name: finalName,
      source: (source ?? NEW_SCRIPT_TEMPLATE).replace(/MyBehaviour/g, finalName),
    };
    this.compileAsset(asset);
    this.scripts.push(asset);
    this.log('log', `Created script "${finalName}"`);
    this.notify('change');
    this.scheduleAutosave();
    return asset;
  }

  deleteScript(id: string): void {
    const asset = this.scripts.find((s) => s.id === id);
    if (!asset) return;
    if (this.scripts.length <= 1) {
      this.log('warn', 'At least one script must stay in the project.');
      return;
    }
    this.scripts = this.scripts.filter((s) => s.id !== id);
    for (const obj of this.graph.all()) {
      obj.scripts = obj.scripts.filter((s) => s.scriptName !== asset.name);
    }
    this.log('log', `Deleted script "${asset.name}"`);
    this.notify('change');
    this.scheduleAutosave();
  }

  /** Attach a script (by asset name or class name) to an object. */
  attachScript(obj: GameObject, scriptName: string, fields?: Record<string, any>): ScriptInstance | null {
    if (!this.runtime) return null;
    const asset = this.getScript(scriptName);
    if (!asset) {
      this.log('error', `No script named "${scriptName}" in this project.`);
      return null;
    }
    const spec = this.runtime.validate(asset.source, asset.name);
    if (!spec.ok || !spec.className) {
      asset.error = spec.error;
      this.log('error', `${asset.name} has a syntax error (line ${spec.error?.line ?? 1}): ${spec.error?.message ?? 'unknown error'}`);
      return null;
    }
    asset.error = null;
    const cls = this.runtime.compile(asset.source, asset.name);
    const instance = this.runtime.createInstance(cls, obj, asset.name);
    if (fields) {
      for (const key of Object.keys(fields)) this.runtime.setField(instance, key, fields[key]);
    }
    obj.scripts.push(instance);
    if (this.playState === 'playing') {
      this.runtime.callLifecycle(instance, 'Start');
      instance.started = true;
    }
    this.notify('change');
    this.scheduleAutosave();
    return instance;
  }

  detachScript(objId: string, instanceId: string): void {
    const obj = this.graph.get(objId);
    if (!obj) return;
    obj.scripts = obj.scripts.filter((s) => s.id !== instanceId);
    this.log('log', `Script removed from "${obj.name}"`);
    this.notify('change');
    this.scheduleAutosave();
  }

  setScriptField(objId: string, instanceId: string, field: string, value: any): boolean {
    const obj = this.graph.get(objId);
    const instance = obj?.scripts.find((s) => s.id === instanceId);
    if (!instance || !this.runtime) return false;
    const ok = this.runtime.setField(instance, field, value);
    if (ok) { this.notify('change'); this.scheduleAutosave(); }
    return ok;
  }

  setScriptEnabled(objId: string, instanceId: string, enabled: boolean): void {
    const obj = this.graph.get(objId);
    const instance = obj?.scripts.find((s) => s.id === instanceId);
    if (!instance) return;
    instance.enabled = enabled;
    this.notify('change');
  }

  /* ------------------------------------------------------------- playback */

  play(): boolean {
    if (this.playState === 'paused') {
      this.playState = 'playing';
      this.notify('change');
      return true;
    }
    if (this.playState === 'playing') return true;
    this.playSnapshot = this.captureProject();
    this.playState = 'playing';
    this.fixedAccum = 0;
    this.mouseLook = { yaw: this.mouseLook.yaw, pitch: this.mouseLook.pitch, dx: 0, dy: 0 };
    if (this.viewTab !== 'game') this.viewTab = 'game';
    for (const obj of this.graph.all()) {
      for (const instance of obj.scripts) {
        this.runtime?.callLifecycle(instance, 'Start');
        instance.started = true;
      }
    }
    this.log('info', 'Play mode — scripts running.');
    this.notify('change');
    return true;
  }

  pause(): boolean {
    if (this.playState !== 'playing') return false;
    this.playState = 'paused';
    this.log('info', 'Paused.');
    this.notify('change');
    return true;
  }

  stop(silent = false): boolean {
    if (this.playState === 'stopped') return false;
    const snapshot = this.playSnapshot;
    this.playState = 'stopped';
    this.keysDown.clear();
    this.keysPressed.clear();
    this.keysUp.clear();
    this.touchAxis = { x: 0, y: 0 };
    if (typeof document !== 'undefined' && document.pointerLockElement) document.exitPointerLock?.();
    if (snapshot) {
      // the objects the gizmo points at are about to be rebuilt from the snapshot
      this.gizmoTarget = null;
      const selectedId = this.selectedId;
      const selectedName = this.getSelected()?.name ?? null;
      this.applyProject(snapshot, false);
      // re-resolve the selection against the rebuilt graph: a selection that survived
      // the restore keeps its gizmo, one that did not is cleanly cleared by syncGizmo()
      const again = (selectedId ? this.graph.get(selectedId) ?? null : null) ?? (selectedName ? this.graph.find(selectedName) : null);
      this.select(again ? again.id : null);
    }
    for (const obj of this.graph.all()) {
      for (const instance of obj.scripts) instance.started = false;
    }
    this.syncGizmo();
    if (!silent) this.log('info', 'Stopped — scene restored to its pre-play state.');
    this.notify('change');
    return true;
  }

  isPlaying(): PlayState { return this.playState; }

  /* ---------------------------------------------------------------- ticks */

  private startLoop(): void {
    this.lastTime = performance.now();
    const tick = (now: number) => {
      if (this.disposed) return;
      this.rafId = requestAnimationFrame(tick);
      const raw = (now - this.lastTime) / 1000;
      this.lastTime = now;
      const dt = Math.max(0, Math.min(raw, 0.05));
      try {
        this.frame(dt, raw);
      } catch (err) {
        // A single bad frame must never kill the editor.
        this.log('error', `Frame error: ${err instanceof Error ? err.message : String(err)}`);
      }
    };
    this.rafId = requestAnimationFrame(tick);
  }

  private frame(dt: number, rawDt: number): void {
    if (!this.ready || !this.renderer) return;
    this.currentDelta = dt;
    this.elapsed += dt;
    this.frameCount++;

    this.updateTweens(dt);

    if (this.playState === 'playing') {
      this.fixedAccum += dt;
      let steps = 0;
      while (this.fixedAccum >= this.fixedStep && steps < 4) {
        this.fixedAccum -= this.fixedStep;
        steps++;
        this.simulateFixed(this.fixedStep);
      }
      this.runScripts('Update', dt);
      this.runScripts('LateUpdate', dt);
      this.dispatchKeyEvents();
    }

    this.updateGameCamera();
    this.updateSelectionHelper();
    if (this.activeCameraIsEditor() && this.orbit) this.orbit.update();

    // Reconcile the gizmo with the current selection immediately before rendering.
    // The check is a cheap identity comparison when nothing changed, and it is the
    // permanent safety net: TransformControls can never be left holding an Object3D
    // that is no longer part of the scene graph.
    this.syncGizmo();

    this.renderer.render(this.scene, this.activeCamera());

    // frame-rate sampling
    if (rawDt > 0) {
      this.fpsSamples.push(1 / rawDt);
      if (this.fpsSamples.length > 40) this.fpsSamples.shift();
    }
    const now = performance.now();
    if (now - this.lastStatsPush > 220) {
      this.lastStatsPush = now;
      this.pushStats();
    }
    if (this.sceneDirty) {
      this.sceneDirty = false;
      this.notify('change');
    }
    this.keysPressed.clear();
    this.keysUp.clear();
    this.mouseLook.dx = 0;
    this.mouseLook.dy = 0;
  }

  private simulateFixed(dt: number): void {
    const objects = this.graph.all();
    this.physics.step(dt, objects, (hit) => this.onCollision(hit));
    this.runScripts('FixedUpdate', dt);
  }

  private runScripts(method: 'Update' | 'LateUpdate' | 'FixedUpdate', dt: number): void {
    if (!this.runtime) return;
    const objects = this.graph.all();
    for (const obj of objects) {
      if (!obj.three.visible) continue;
      for (const instance of [...obj.scripts]) {
        if (!instance.enabled) continue;
        this.runtime.callLifecycle(instance, method, [dt]);
      }
    }
  }

  private dispatchKeyEvents(): void {
    if (!this.runtime || this.keysPressed.size === 0) return;
    const keys = [...this.keysPressed];
    const objects = this.graph.all();
    for (const obj of objects) {
      for (const instance of [...obj.scripts]) {
        if (!instance.enabled) continue;
        if (!this.runtime.hasMethod(instance, 'OnKeyDown')) continue;
        for (const key of keys) this.runtime.callLifecycle(instance, 'OnKeyDown', [key]);
      }
    }
  }

  private dispatchEventTo(target: GameObject, method: string, args: any[]): void {
    if (!this.runtime) return;
    for (const instance of [...target.scripts]) {
      if (!instance.enabled) continue;
      if (!this.runtime.hasMethod(instance, method)) continue;
      this.runtime.callLifecycle(instance, method, args);
    }
  }

  private onCollision(hit: CollisionHit): void {
    const infoSelf = this.collisionInfo(hit);
    const infoOther = this.collisionInfo(hit, true);
    this.dispatchEventTo(hit.self, 'OnCollision', [infoSelf]);
    if (hit.other) this.dispatchEventTo(hit.other, 'OnCollision', [infoOther]);
  }

  private collisionInfo(hit: CollisionHit, swapped = false): any {
    const primary = swapped ? hit.other ?? hit.self : hit.self;
    const secondary = swapped ? hit.self : hit.other;
    const name = secondary ? secondary.name : 'Ground';
    return {
      __kind: 'collision',
      name,
      other: secondary ? { __kind: 'gameobject', id: secondary.id, name: secondary.name } : null,
      object: secondary,
      self: primary ? primary.name : 'Ground',
      point: { x: hit.point.x, y: hit.point.y, z: hit.point.z },
      normal: { x: hit.normal.x, y: hit.normal.y, z: hit.normal.z },
      relativeVelocity: { x: hit.relativeVelocity.x, y: hit.relativeVelocity.y, z: hit.relativeVelocity.z },
    };
  }

  private updateSelectionHelper(): void {
    if (!this.selectionHelper) return;
    const obj = this.getSelected();
    if (obj && obj.three.visible) {
      (this.selectionHelper as any).setFromObject(obj.three);
      this.selectionHelper.visible = !this.draggingGizmo;
    } else {
      this.selectionHelper.visible = false;
    }
  }

  private activeCameraIsEditor(): boolean {
    return this.viewTab !== 'game';
  }

  private activeCamera(): any {
    return this.activeCameraIsEditor() ? this.editorCamera : this.gameCamera;
  }

  /** The camera behaviour in Game view: prefer a Main Camera object, else follow the player. */
  private cameraTarget(): GameObject | null {
    const all = this.graph.all();
    const main = all.find((o) => o.cameraParams?.isMain && o.camera);
    if (main) return main;
    const player = all.find((o) => o.isPlayer);
    if (player) return player;
    return null;
  }

  private updateGameCamera(): void {
    if (!this.gameCamera) return;
    const target = this.cameraTarget();
    if (!target) return;

    if (target.camera) {
      const worldPos = target.three.getWorldPosition(new this.three.Vector3());
      const worldQuat = target.three.getWorldQuaternion(new this.three.Quaternion());
      this.gameCamera.position.copy(worldPos);
      this.gameCamera.quaternion.copy(worldQuat);
      if (target.cameraParams) {
        this.gameCamera.fov = target.cameraParams.fov;
        this.gameCamera.updateProjectionMatrix();
      }
      return;
    }

    const p = target.three.position;
    this.gameCamera.position.set(p.x, p.y + 1.15, p.z);
    this.gameCamera.rotation.order = 'YXZ';
    this.gameCamera.rotation.set(this.mouseLook.pitch, this.mouseLook.yaw, 0);
  }

  private updateTweens(dt: number): void {
    if (!this.tweens.length) return;
    for (const tween of [...this.tweens]) {
      const target = this.graph.get(tween.target.id);
      if (!target) {
        this.tweens = this.tweens.filter((t) => t !== tween);
        continue;
      }
      tween.elapsed += dt;
      let t = tween.duration > 0 ? tween.elapsed / tween.duration : 1;
      if (t >= 1) {
        if (tween.loop) {
          tween.elapsed = tween.elapsed % tween.duration;
          if (tween.yoyo) tween.reverse = !tween.reverse;
          t = tween.elapsed / tween.duration;
        } else {
          t = 1;
        }
      }
      const eased = (EASINGS[tween.easing] ?? EASINGS.easeInOut)(Math.max(0, Math.min(1, tween.reverse ? 1 - t : t)));
      for (const key of tween.keys) {
        const obj: any = target.three[key.property];
        obj.set(
          key.from[0] + (key.to[0] - key.from[0]) * eased,
          key.from[1] + (key.to[1] - key.from[1]) * eased,
          key.from[2] + (key.to[2] - key.from[2]) * eased,
        );
      }
      if (!tween.loop && tween.elapsed >= tween.duration) {
        this.tweens = this.tweens.filter((t) => t !== tween);
      }
    }
  }

  /**
   * Safe object count — it is safe to call before the engine has finished
   * loading (i.e. before buildScene() has created the scene graph), returning 0.
   */
  objectCount(): number {
    return this.graph ? this.graph.count() : 0;
  }

  /**
   * Safe object list — it is safe to call before the engine has finished
   * loading (i.e. before buildScene() has created the scene graph), returning [].
   */
  objectsOrEmpty(): GameObject[] {
    return this.graph ? this.graph.all() : [];
  }

  /* -------------------------------------------------------- scene health */

  /** Object types that are supposed to carry real geometry. */
  private static readonly GEOMETRY_TYPES: ReadonlySet<ObjectType> = new Set<ObjectType>([
    'Cube',
    'Sphere',
    'Plane',
    'Cylinder',
    'Torus',
    'Capsule',
    'Cone',
    'Model',
  ]);

  /**
   * Scene integrity check behind the Console panel's "Health" action.
   *
   * Pure inspection — it never mutates the scene, the selection or the gizmo — and it
   * is safe to call before the engine has finished loading. Returns structured results;
   * the Console panel formats them into log lines.
   */
  checkSceneHealth(): SceneHealthReport {
    const objects = this.objectsOrEmpty();
    const known = new Set<string>();
    for (const obj of objects) known.add(obj.id);

    const report: SceneHealthReport = {
      ready: this.ready && !!this.graph && !!this.scene,
      objectCount: this.objectCount(),
      detached: [],
      selection: [],
      geometry: [],
      gizmoIssues: [],
      gizmo: this.gizmoState(),
      total: 0,
    };

    // 1 — objects whose three.js node is not attached to the scene root
    const seenDetached = new Set<string>();
    for (const obj of objects) {
      if (seenDetached.has(obj.id)) continue;
      const node: any = obj.three;
      let detail: string | null = null;
      if (!node) detail = 'the object has no three.js node';
      else if (!this.isInScene(node)) detail = 'its three.js node is not attached to the scene root';
      if (!detail) continue;
      seenDetached.add(obj.id);
      report.detached.push({ id: obj.id, name: obj.name, detail });
    }

    // 2 — a selection pointing at a deleted or detached object
    const selected = this.getSelected();
    if (this.selectedId && !selected) {
      report.selection.push({
        id: this.selectedId,
        name: '(deleted)',
        detail: 'the selected object is no longer in the scene graph',
      });
    } else if (selected && (!known.has(selected.id) || !this.isInScene(selected.three))) {
      report.selection.push({
        id: selected.id,
        name: selected.name,
        detail: known.has(selected.id)
          ? 'the selected object is detached from the scene root'
          : 'the selected object is not in the scene graph',
      });
    }

    // 3 — objects that should carry geometry but have none
    const seenGeometry = new Set<string>();
    for (const obj of objects) {
      if (seenGeometry.has(obj.id)) continue;
      const detail = this.geometryIssue(obj);
      if (!detail) continue;
      seenGeometry.add(obj.id);
      report.geometry.push({ id: obj.id, name: obj.name, detail });
    }

    // 4 — gizmo attachment problems (the target state itself is always reported)
    const gizmoIssue = this.gizmoAttachmentIssue(report.gizmo);
    if (gizmoIssue) report.gizmoIssues.push(gizmoIssue);


    report.total =
      report.detached.length + report.selection.length + report.geometry.length + report.gizmoIssues.length;
    return report;
  }

  /**
   * The single gizmo-attachment problem, shared by the health check and by the repair's
   * post-fix re-check: returns null when the attachment is fine.
   */
  private gizmoAttachmentIssue(gizmo: SceneHealthGizmo): SceneHealthIssue | null {
    const selected = this.getSelected();
    if (gizmo.attached && !gizmo.valid) {
      return {
        id: gizmo.targetId ?? '(unknown)',
        name: gizmo.targetName ?? '(unnamed node)',
        detail: 'the gizmo is attached to a node that is not in the scene',
      };
    }
    if (!gizmo.attached && selected && this.isInScene(selected.three)) {
      return {
        id: selected.id,
        name: selected.name,
        detail: 'this object is selected and in the scene but the gizmo is detached',
      };
    }
    return null;
  }

  /**
   * Scene repair behind the Console panel's "Repair" action. It runs the same audit as
   * checkSceneHealth() and then applies only the three safe fixes:
   *   1. every three.js node that exists but no longer reaches the scene root is added
   *      back to the scene root,
   *   2. a selection pointing at a deleted or detached object is cleared,
   *   3. the gizmo is re-synced with the (possibly cleared) selection.
   *
   * It never creates or deletes objects and never touches geometry, transforms, materials,
   * child relationships or scripts — problems that are not safe to fix automatically are
   * only reported. Safe to call before the engine has finished loading: it returns an
   * unfixed report instead of throwing.
   */
  repairScene(): SceneRepairReport {
    const audit = this.checkSceneHealth();
    const repair: SceneRepairReport = {
      ready: audit.ready,
      audit,
      reattached: [],
      unrepairable: [],
      selectionCleared: null,
      gizmo: audit.gizmo,
      leftForManualReview: audit.geometry,
      fixed: 0,
    };
    if (!audit.ready || !this.scene || !this.graph) return repair;

    // 1 — a node whose parent chain does not reach the scene root goes back to the root
    for (const issue of audit.detached) {
      const node: any = this.graph.get(issue.id)?.three;
      // use the scene graph's own resolved root (never the three.js namespace), so Repair
      // cannot hit the same invalid-root crash that took the engine down during init
      const root: any = this.graph.resolveRoot();
      if (!node || !root || this.isInScene(node)) {
        repair.unrepairable.push(issue);
        continue;
      }
      if (node.parent === root) {
        repair.reattached.push(issue);
        continue;
      }
      try {
        root.add(node);
      } catch {
        repair.unrepairable.push(issue);
        continue;
      }
      repair.reattached.push(issue);
    }

    // 2 — a selection pointing at a deleted or detached object is dropped
    const deadSelection = audit.selection[0] ?? null;
    if (deadSelection) {
      try {
        this.select(null);
        repair.selectionCleared = deadSelection;
      } catch { /* the selection stays as it is — nothing else is safe to do here */ }
    }

    // 3 — reconcile the gizmo with the selection as it now stands
    try {
      this.syncGizmo();
    } catch { /* a failed re-sync must never break the console action */ }

    repair.gizmo = this.gizmoState();
    const gizmoResolved = audit.gizmoIssues.length > 0 && !this.gizmoAttachmentIssue(repair.gizmo);
    repair.fixed = repair.reattached.length + (repair.selectionCleared ? 1 : 0) + (gizmoResolved ? 1 : 0);
    if (repair.reattached.length || repair.selectionCleared) this.notify('change');
    return repair;
  }

  /** Snapshot of the gizmo mode + attachment, resolved to a GameObject when possible. */
  private gizmoState(): SceneHealthGizmo {
    const controls: any = this.transformControls;
    const controlsTarget: any = controls && controls.object ? controls.object : null;
    const target: any = this.gizmoTarget ?? controlsTarget;
    const owner = target ? this.objectsOrEmpty().find((o) => o.three === target) ?? null : null;
    const engineId = target && target.userData && typeof target.userData.engineId === 'string' ? target.userData.engineId : null;
    return {
      mode: this.gizmoMode,
      attached: !!(this.gizmoTarget || controlsTarget),
      targetId: owner ? owner.id : engineId,
      targetName: owner ? owner.name : target && typeof target.name === 'string' && target.name ? target.name : null,
      valid: !!target && this.isInScene(target),
    };
  }

  /**
   * Returns a short explanation when an object that should carry geometry has none
   * (no mesh at all, missing geometry, or zero vertices), otherwise null.
   */
  private geometryIssue(obj: GameObject): string | null {
    if (!EngineCore.GEOMETRY_TYPES.has(obj.type)) return null;
    const node: any = obj.three;
    if (!node) return 'the object has no three.js node';

    const meshes: any[] = [];
    if (node.isMesh || node.geometry) meshes.push(node);
    else if (typeof node.traverse === 'function') {
      node.traverse((child: any) => {
        if (child && child !== node && (child.isMesh || child.geometry)) meshes.push(child);
      });
    }

    if (!meshes.length) {
      if (obj.type === 'Model') {
        // an imported model that never produced a mesh: only a problem once an asset is assigned
        return obj.assetId ? 'the imported model has no mesh or geometry' : null;
      }
      return 'it has no mesh or geometry';
    }

    for (const mesh of meshes) {
      if (!mesh.geometry) return `"${mesh.name || 'mesh'}" has no geometry`;
      const vertices = mesh.geometry.attributes?.position?.count ?? 0;
      if (!vertices) return `"${mesh.name || 'mesh'}" has empty geometry (0 vertices)`;
    }
    return null;
  }


  private pushStats(): void {
    const info = this.renderer?.info;
    const fps = this.fpsSamples.length
      ? this.fpsSamples.reduce((a, b) => a + b, 0) / this.fpsSamples.length
      : 0;
    this.stats = {
      fps: Math.round(fps),
      drawCalls: info?.render?.calls ?? 0,
      triangles: info?.render?.triangles ?? 0,
      objects: this.graph ? this.graph.count() : 0,
      scripts: this.graph ? this.graph.all().reduce((sum, o) => sum + o.scripts.length, 0) : 0,
      textures: info?.memory?.textures ?? 0,
      geometries: info?.memory?.geometries ?? 0,
    };
    this.notify('stats');
  }

  /* ------------------------------------------------------- mouse picking */

  private pick(clientX: number, clientY: number): GameObject | null {
    if (!this.renderer || !this.canvasHost) return null;
    const rect = this.renderer.domElement.getBoundingClientRect();
    const ndc = new this.three.Vector2(
      ((clientX - rect.left) / rect.width) * 2 - 1,
      -((clientY - rect.top) / rect.height) * 2 + 1,
    );
    const raycaster = new this.three.Raycaster();
    raycaster.setFromCamera(ndc, this.activeCamera());

    const hits = raycaster.intersectObjects(this.scene.children, true);
    for (const hit of hits) {
      let node: any = hit.object;
      while (node) {
        if (node.userData?.engineId) return this.graph.get(node.userData.engineId) ?? null;
        if (node.userData?.noPick) break;
        node = node.parent;
      }
    }
    return null;
  }

  /* ---------------------------------------------------- global listeners */

  private attachGlobalListeners(): void {
    if (this.globalListenersAttached || typeof window === 'undefined') return;
    this.globalListenersAttached = true;

    const onKeyDown = (event: KeyboardEvent) => {
      const typing = isTypingTarget(event.target);
      const key = normalizeKey(event.key);
      if (typing) {
        if (key === 'escape') (event.target as HTMLElement).blur?.();
        return;
      }

      const mod = event.ctrlKey || event.metaKey;
      if (mod && key === 's') { event.preventDefault(); this.saveProject(this.projectName); this.log('log', `Project saved as "${this.projectName}".`); return; }
      if (mod && key === 'd' && this.selectedId && this.playState === 'stopped') { event.preventDefault(); this.duplicateObject(this.selectedId); return; }
      if (mod && key === 'z') { event.preventDefault(); if (event.shiftKey) this.redo(); else this.undo(); return; }
      if (mod && key === 'y') { event.preventDefault(); this.redo(); return; }

      if (this.playState === 'stopped' && !mod) {
        if (key === 'w') { this.setGizmoMode('translate'); }
        else if (key === 'e') { this.setGizmoMode('rotate'); }
        else if (key === 'r') { this.setGizmoMode('scale'); }
        else if (key === 'f') { this.focusSelected(); }
        else if (key === 'delete') {
          if (this.selectedId) this.deleteObject(this.selectedId);
          return;
        }
      }

      if (this.playState === 'playing' && this.viewTab === 'game') {
        if (key === 'space' || key.startsWith('arrow')) event.preventDefault();
        if (key === 'escape' && document.pointerLockElement) document.exitPointerLock?.();
      }

      if (key === 'escape') {
        if (document.pointerLockElement) document.exitPointerLock?.();
        else this.select(null);
      }

      if (!this.keysDown.has(key)) this.keysPressed.add(key);
      this.keysDown.add(key);
    };

    const onKeyUp = (event: KeyboardEvent) => {
      const key = normalizeKey(event.key);
      this.keysDown.delete(key);
      this.keysUp.add(key);
    };

    const onPointerDown = (event: PointerEvent) => {
      if (event.target !== this.renderer?.domElement) return;
      this.pointerDown = { x: event.clientX, y: event.clientY };
      if (this.viewTab === 'game' && this.playState === 'playing' && !document.pointerLockElement) {
        const canvas: any = this.renderer.domElement;
        canvas.requestPointerLock?.();
      }
    };

    const onPointerUp = (event: PointerEvent) => {
      if (event.target !== this.renderer?.domElement) return;
      const start = this.pointerDown;
      this.pointerDown = null;
      if (!start) return;
      const moved = Math.hypot(event.clientX - start.x, event.clientY - start.y);
      if (moved > 6 || this.draggingGizmo) return;
      const hitObject = this.pick(event.clientX, event.clientY);
      if (hitObject) {
        this.select(hitObject.id);
        if (this.playState === 'playing') this.dispatchEventTo(hitObject, 'OnClick', []);
      } else if (this.viewTab !== 'game') {
        this.select(null);
      }
    };

    const onPointerMove = (event: PointerEvent) => {
      if (!document.pointerLockElement) return;
      const dx = event.movementX || 0;
      const dy = event.movementY || 0;
      this.mouseLook.yaw -= dx * 0.0024;
      this.mouseLook.pitch = Math.max(-1.35, Math.min(1.35, this.mouseLook.pitch - dy * 0.0024));
      this.mouseLook.dx += dx;
      this.mouseLook.dy += dy;
    };

    const onContextMenu = (event: MouseEvent) => {
      if (event.target === this.renderer?.domElement) event.preventDefault();
    };

    const onBeforeUnload = () => this.persistNow();

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('pointerdown', onPointerDown);
    window.addEventListener('pointerup', onPointerUp);
    window.addEventListener('mousemove', onPointerMove);
    window.addEventListener('contextmenu', onContextMenu);
    window.addEventListener('beforeunload', onBeforeUnload);
  }

  /* ------------------------------------------------------------- bridges */

  private buildBridge(): void {
    this.api = this.buildApi();
    const g = window as any;
    g.Engine = this.api;
    g.GameEngine = this.api;
    g.WebForge = this.api;
    g.__WEBFORGE_CORE__ = this;

    this.bridge = new ExternalBridge(this);
    this.bridge.start();

    this.remote = new RemoteControl(this, () => { this.bridgeHandled = this.bridge?.handled ?? 0; this.notify('remote'); });
    // "<selected>" in a remote packet resolves to the editor selection, falling
    // back to a real mesh so a remote can drive the scene without one.
    this.remote.selectedProvider = () =>
      this.selectedId ?? this.graph.all().find((o) => !!o.threeMaterial)?.id ?? this.graph.all()[0]?.id ?? null;
  }

  /** Uniform dispatcher shared by window.Engine, postMessage and the remote bridge. */
  execute(method: string, args: any[]): BridgeResult {
    try {
      const fn = this.api?.[method];
      if (typeof fn !== 'function') return { ok: false, error: `Unknown API method '${method}'` };
      const result = fn(...(Array.isArray(args) ? args : []));
      return { ok: true, result: toTransferable(result) };
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      this.log('error', `API ${method}() failed: ${message}`);
      return { ok: false, error: message };
    }
  }

  /* ------------------------------------------------------- the public API */

  private buildApi(): Record<string, any> {
    const core = this;

    const requireObject = (id: string): GameObject => {
      const obj = core.graph.get(String(id));
      if (!obj) throw new Error(`No object with id '${id}'`);
      return obj;
    };

    const api: Record<string, any> = {
      /* -------------------------------------------------------- lifecycle */
      ping: () => ({ engine: 'webforge', version: 1, ready: core.ready, three: core.threeSourceLabel, time: Date.now() }),
      engineName: 'webforge',

      /* ---------------------------------------------------------- objects */
      createObject: (name: string, type = 'Cube') => {
        const obj = core.createObject(sanitizeType(type), String(name ?? 'Object'));
        return obj.id;
      },
      destroy: (id: string) => !!core.deleteObject(String(id)),
      find: (name: string) => {
        const obj = core.graph.find(String(name));
        return obj ? { id: obj.id, name: obj.name, type: obj.type, position: toTransferable(obj.three.position) } : null;
      },
      listObjects: () =>
        core.graph.all().map((o) => ({ id: o.id, name: o.name, type: o.type, visible: o.three.visible, parent: o.parent ? o.parent.name : null })),
      setVisible: (id: string, visible: boolean) => { requireObject(String(id)).visible = !!visible; core.notify('change'); return true; },
      rename: (id: string, name: string) => { core.renameObject(String(id), String(name)); return true; },

      /* -------------------------------------------------------- transforms */
      setPosition: (id: string, x: any, y?: any, z?: any) => { const p = vec3From(x, y, z); requireObject(String(id)).three.position.set(p.x, p.y, p.z); core.notify('change'); return true; },
      setRotation: (id: string, x: any, y?: any, z?: any) => { const p = vec3From(x, y, z); requireObject(String(id)).three.rotation.set(p.x * DEG, p.y * DEG, p.z * DEG); core.notify('change'); return true; },
      setScale: (id: string, x: any, y?: any, z?: any) => { const p = vec3From(x, y, z); requireObject(String(id)).three.scale.set(p.x, p.y, p.z); core.physics.invalidate(String(id)); core.notify('change'); return true; },
      move: (id: string, dx: any, dy?: any, dz?: any) => { const p = vec3From(dx, dy, dz); requireObject(String(id)).three.position.add(new core.three.Vector3(p.x, p.y, p.z)); core.notify('change'); return true; },
      getTransform: (id: string) => {
        const obj = requireObject(String(id));
        return {
          position: { x: round(obj.three.position.x), y: round(obj.three.position.y), z: round(obj.three.position.z) },
          rotation: { x: round(obj.three.rotation.x / DEG), y: round(obj.three.rotation.y / DEG), z: round(obj.three.rotation.z / DEG) },
          scale: { x: round(obj.three.scale.x), y: round(obj.three.scale.y), z: round(obj.three.scale.z) },
        };
      },
      setVelocity: (id: string, x: number, y: number, z: number) => { core.physics.setVelocity(requireObject(String(id)), Number(x) || 0, Number(y) || 0, Number(z) || 0); return true; },
      applyImpulse: (id: string, x: number, y: number, z: number) => { core.physics.applyImpulse(requireObject(String(id)), Number(x) || 0, Number(y) || 0, Number(z) || 0); return true; },
      getVelocity: (id: string) => core.physics.getVelocity(requireObject(String(id))),

      /* --------------------------------------------------------- materials */
      setColor: (id: string, color: string) => {
        const obj = requireObject(String(id));
        if (!obj.materialParams) throw new Error(`Object '${obj.name}' has no material (Lights, Cameras and Empties have no colour).`);
        core.setMaterialParams(obj.id, { color: String(color) });
        return true;
      },
      setMaterial: (id: string, patch: Partial<MaterialParams>) => { core.setMaterialParams(String(id), patch ?? {}); return true; },
      setLight: (id: string, patch: Partial<LightParams>) => { core.setLightParams(String(id), patch ?? {}); return true; },
      setCamera: (id: string, patch: Partial<CameraParams>) => { core.setCameraParams(String(id), patch ?? {}); return true; },
      setPhysics: (id: string, patch: Partial<PhysicsParams>) => { core.setPhysicsParams(String(id), patch ?? {}); return true; },

      /* ----------------------------------------------------------- scripts */
      attachScript: (id: string, scriptName: string, fields?: Record<string, any>) => !!core.attachScript(requireObject(String(id)), String(scriptName), fields),
      removeScript: (id: string, scriptName: string) => {
        const obj = requireObject(String(id));
        const found = obj.scripts.filter((s) => s.scriptName === scriptName || s.className === scriptName);
        for (const s of found) core.detachScript(obj.id, s.id);
        return found.length > 0;
      },
      setScriptField: (id: string, scriptName: string, field: string, value: any) => {
        const obj = requireObject(String(id));
        const instance = obj.scripts.find((s) => s.scriptName === scriptName || s.className === scriptName);
        if (!instance) throw new Error(`'${scriptName}' is not attached to ${obj.name}`);
        return core.setScriptField(obj.id, instance.id, String(field), value);
      },
      getScriptFields: (id: string, scriptName: string) => {
        const obj = requireObject(String(id));
        const instance = obj.scripts.find((s) => s.scriptName === scriptName || s.className === scriptName);
        if (!instance) throw new Error(`'${scriptName}' is not attached to ${obj.name}`);
        return toTransferable(instance.fields);
      },
      listScripts: () => {
        const all = core.graph.all();
        return core.scripts.map((s) => {
          const instances = all.flatMap((o) => o.scripts.filter((i) => i.scriptName === s.name));
          return {
            name: s.name,
            className: s.className ?? null,
            fields: instances.length ? Object.keys(instances[0].fields ?? {}) : [],
            attached: instances.length,
            error: s.error ?? null,
          };
        });
      },
      createScript: (name: string, source?: string) => core.createScript(String(name), source ? String(source) : undefined).name,
      setScriptSource: (name: string, source: string) => {
        const asset = core.getScript(String(name));
        if (!asset) throw new Error(`No script named '${name}'`);
        core.setScriptSource(asset.id, String(source));
        return !asset.error;
      },

      /* --------------------------------------------------------- animation */
      animate: (id: string, options: any = {}) => {
        const obj = requireObject(String(id));
        return core.startTween(obj, options);
      },
      stopAnimation: (animationId: string) => {
        const before = core.tweens.length;
        core.tweens = core.tweens.filter((t) => t.id !== animationId);
        if (core.tweens.length === before) {
          // allow stopping by object id as well — convenient from the console
          const obj = core.graph.get(String(animationId));
          if (obj) core.tweens = core.tweens.filter((t) => t.target.id !== obj.id);
          else return false;
        }
        return true;
      },
      listAnimations: () => core.tweens.map((t) => ({ id: t.id, target: t.target.name, elapsed: round(t.elapsed), duration: t.duration, loop: t.loop })),
      stopAllAnimations: () => { core.tweens = []; return true; },

      /* ------------------------------------------------------------ events */
      emitEvent: (name: string, payload?: any) => { core.emitEvent(String(name), payload); return core.eventHandlers.get(String(name))?.size ?? 0; },
      on: (name: string, handler: any) => core.subscribeEvent(String(name), handler),
      off: (name: string, handler?: any) => core.unsubscribeEvent(String(name), handler),

      /* ---------------------------------------------------------- playback */
      play: () => core.play(),
      pause: () => core.pause(),
      stop: () => core.stop(),
      isPlaying: () => core.playState,
      select: (id: string | null) => { core.select(id ? String(id) : null); return true; },
      getSelection: () => { const obj = core.getSelected(); return obj ? { id: obj.id, name: obj.name, type: obj.type } : null; },
      focusSelection: () => { core.focusSelected(); return true; },

      /* ------------------------------------------------------------ scenes */
      exportScene: () => core.captureProject(),
      loadScene: (json: any) => {
        if (json === null || json === undefined || json === '') return false;
        const project: ProjectJSON = typeof json === 'string' ? JSON.parse(json) : json;
        if (!project || typeof project !== 'object') return false;
        core.applyProject(project, true);
        return true;
      },
      clearScene: () => { core.stop(true); core.graph.clear(); core.syncGizmo(); core.notify('change'); return true; },
      saveProject: (name: string) => core.saveProject(String(name || core.projectName)),
      listProjects: () => core.listProjects(),
      getProjectName: () => core.projectName,

      /* ----------------------------------------------------------- prefabs */
      listPrefabs: () => core.listPrefabs(),
      savePrefab: (id: string | null, name?: string) => {
        const target = id ? String(id) : core.selectedId;
        const saved = core.savePrefab(target, name ? String(name) : undefined);
        return saved ? { id: saved.id, name: saved.name, objects: saved.stats.objects } : null;
      },
      placePrefab: (nameOrId: string, x?: number, y?: number, z?: number) => {
        const prefab = core.getPrefab(String(nameOrId)) ?? core.prefabs.find((p) => p.name === String(nameOrId));
        if (!prefab) throw new Error(`No prefab called '${nameOrId}'`);
        const position = x === undefined ? undefined : { x: Number(x) || 0, y: Number(y) || 0, z: Number(z) || 0 };
        const obj = core.instantiatePrefab(prefab.id, position);
        return obj ? { id: obj.id, name: obj.name } : null;
      },
      deletePrefab: (nameOrId: string) => {
        const prefab = core.getPrefab(String(nameOrId)) ?? core.prefabs.find((p) => p.name === String(nameOrId));
        if (!prefab) throw new Error(`No prefab called '${nameOrId}'`);
        core.deletePrefab(prefab.id);
        return true;
      },
      renamePrefab: (nameOrId: string, name: string) => {
        const prefab = core.getPrefab(String(nameOrId)) ?? core.prefabs.find((p) => p.name === String(nameOrId));
        if (!prefab) throw new Error(`No prefab called '${nameOrId}'`);
        core.renamePrefab(prefab.id, String(name));
        return true;
      },

      /* -------------------------------------------------------- diagnostics */
      log: (message: string) => { core.log('log', String(message)); },
      getStats: () => ({ ...core.stats }),
      getDialogHelp: () => ({ commands: core.api ? Object.keys(core.api).sort() : [], docs: 'See the API & Docs tab' }),
    };

    return api;
  }

  /* --------------------------------------------------------- event bus */

  subscribeEvent(name: string, handler: any): () => void {
    const fn = typeof handler === 'function' ? handler : (payload: any) => this.log('log', `event ${name}: ${JSON.stringify(toTransferable(payload))}`);
    if (!this.eventHandlers.has(name)) this.eventHandlers.set(name, new Set());
    this.eventHandlers.get(name)!.add(fn);
    this.log('log', `Subscribed to event "${name}"`);
    return () => { this.eventHandlers.get(name)?.delete(fn); };
  }

  unsubscribeEvent(name: string, handler?: any): boolean {
    const set = this.eventHandlers.get(name);
    if (!set) return false;
    if (handler) set.delete(handler);
    else set.clear();
    return true;
  }

  /** Fire an engine event: external subscribers + scripts with OnEvent. */
  emitEvent(name: string, payload?: any): void {
    const set = this.eventHandlers.get(name);
    if (set) {
      for (const fn of [...set]) {
        try {
          (fn as Function)(payload);
        } catch (err) {
          this.log('warn', `Event handler for "${name}" threw: ${err instanceof Error ? err.message : String(err)}`);
        }
      }
    }
    for (const obj of this.graph.all()) {
      for (const instance of [...obj.scripts]) {
        if (!instance.enabled) continue;
        if (!this.runtime?.hasMethod(instance, 'OnEvent')) continue;
        this.runtime.callLifecycle(instance, 'OnEvent', [name, payload ?? {}]);
      }
    }
    this.log('log', `Event "${name}" dispatched${payload ? ' with ' + JSON.stringify(toTransferable(payload)) : ''}`);
  }

  /* ------------------------------------------------------------ tweens */

  startTween(obj: GameObject, options: any): string {
    const duration = Math.max(0.05, Number(options.duration) || 1);
    const keys: TweenKey[] = [];
    const base = {
      position: [obj.three.position.x, obj.three.position.y, obj.three.position.z],
      rotation: [obj.three.rotation.x / DEG, obj.three.rotation.y / DEG, obj.three.rotation.z / DEG],
      scale: [obj.three.scale.x, obj.three.scale.y, obj.three.scale.z],
    };

    const addKey = (property: TweenKey['property'], value: any, relative: boolean) => {
      if (value === undefined || value === null || value === false) return;
      const to = vec3From(value, (value as any)?.y, (value as any)?.z);
      const from = [...base[property]];
      if (property === 'rotation') {
        keys.push({ property, from, to: [to.x, to.y, to.z] });
      } else {
        keys.push({
          property,
          from,
          to: relative
            ? [from[0] + to.x, from[1] + to.y, from[2] + to.z]
            : [to.x, to.y, to.z],
        });
      }
    };

    const relative = !!options.relative;
    addKey('position', options.position, relative);
    addKey('rotation', options.rotation, relative);
    addKey('scale', options.scale, relative);

    if (!keys.length) throw new Error('animate() needs at least one of position, rotation or scale.');

    const id = `anim_${this.tweenSeq++}`;
    this.tweens.push({
      id,
      target: obj,
      keys,
      duration,
      elapsed: 0,
      loop: !!options.loop,
      yoyo: !!options.yoyo,
      reverse: false,
      easing: String(options.easing || 'easeInOut'),
      base,
    });
    return id;
  }

  /* ---------------------------------------------------------- undo stack */

  pushUndo(entry: UndoEntry): void {
    this.undoStack.push(entry);
    if (this.undoStack.length > 120) this.undoStack.shift();
    this.redoStack = [];
  }

  undo(): boolean {
    const entry = this.undoStack.pop();
    if (!entry) {
      this.log('warn', 'Nothing left to undo.');
      return false;
    }
    entry.undo();
    this.redoStack.push(entry);
    // an undo can delete or rebuild the object the gizmo was attached to
    this.syncGizmo();
    this.log('log', `Undo: ${entry.label}`);
    this.notify('change');
    this.scheduleAutosave();
    return true;
  }

  redo(): boolean {
    const entry = this.redoStack.pop();
    if (!entry) {
      this.log('warn', 'Nothing left to redo.');
      return false;
    }
    entry.redo();
    this.undoStack.push(entry);
    // a redo can rebuild the objects the gizmo was pointing at
    this.syncGizmo();
    this.log('log', `Redo: ${entry.label}`);
    this.notify('change');
    this.scheduleAutosave();
    return true;
  }

  canUndo(): boolean { return this.undoStack.length > 0; }
  canRedo(): boolean { return this.redoStack.length > 0; }
  undoLabel(): string | null { return this.undoStack.length ? this.undoStack[this.undoStack.length - 1].label : null; }
  redoLabel(): string | null { return this.redoStack.length ? this.redoStack[this.redoStack.length - 1].label : null; }

  /* ------------------------------------------------------------- prefabs */

  private loadPrefabs(): void {
    this.prefabs = readPrefabStore();
    if (!this.prefabs.length) this.seedStarterPrefabs();
  }

  /**
   * First run: the user has no prefabs of their own yet, so offer a few built
   * from the demo scene's own objects. Names that are not in the current scene
   * are simply skipped (a restored project may not contain them).
   */
  private seedStarterPrefabs(): void {
    const starters: Array<{ name: string; object: string }> = [
      { name: 'Orbit Rig', object: 'Orbit Center' },
      { name: 'Glow Core', object: 'Pulse Core' },
      { name: 'Physics Crate', object: 'Crate 1' },
      { name: 'Spinning Prop', object: 'Prop Torus' },
    ];
    const seeded: Prefab[] = [];
    for (const starter of starters) {
      const obj = this.graph.find(starter.object);
      if (obj) seeded.push(this.buildPrefab(obj, starter.name));
    }
    if (!seeded.length) return;
    this.prefabs = seeded;
    this.persistPrefabs();
    this.log('info', `Added ${seeded.length} starter prefabs built from the demo scene — select any object and use "Save as prefab" to make your own.`);
  }

  private buildPrefab(obj: GameObject, name: string): Prefab {
    const root = capturePrefabNode(obj);
    const scriptSources: PrefabScriptSource[] = [];
    for (const scriptName of prefabScriptNames(root)) {
      const asset = this.getScript(scriptName);
      if (asset) scriptSources.push({ name: asset.name, source: asset.source });
    }
    return {
      id: newPrefabId(),
      name,
      format: PREFAB_FORMAT,
      version: 1,
      created: Date.now(),
      updated: Date.now(),
      root,
      scriptSources,
      stats: prefabStats(root),
    };
  }

  private persistPrefabs(): void {
    if (!writePrefabStore(this.prefabs)) {
      this.log('error', 'The prefab library could not be saved — this browser\'s storage is full. Delete a prefab you no longer need and try again.');
      return;
    }
    this.notify('change');
  }

  getPrefab(id: string): Prefab | undefined {
    return this.prefabs.find((p) => p.id === id);
  }

  listPrefabs(): Array<{ id: string; name: string; objects: number; scripts: number; physics: number }> {
    return this.prefabs.map((p) => ({
      id: p.id,
      name: p.name,
      objects: p.stats.objects,
      scripts: p.stats.scripts,
      physics: p.stats.physicsBodies,
    }));
  }

  /** Save the selected object — children, materials, physics and scripts included — as a reusable prefab. */
  savePrefab(objectId: string | null, name?: string): Prefab | null {
    const obj = objectId ? this.graph.get(objectId) : null;
    if (!obj) {
      this.log('warn', 'Select an object in the Hierarchy first, then save it as a prefab.');
      return null;
    }
    const prefab = this.buildPrefab(obj, uniquePrefabName(this.prefabs, (name || obj.name).trim() || obj.name));
    this.prefabs = [prefab, ...this.prefabs];
    this.persistPrefabs();
    this.log('info', `Saved prefab "${prefab.name}" — ${prefabSummary(prefab)}. Drop it into any scene from the Prefabs panel.`);
    this.track('prefab_saved', { objects: prefab.stats.objects, scripts: prefab.stats.scripts, physics: prefab.stats.physicsBodies });
    return prefab;
  }

  /** Re-capture an existing prefab from the current selection (keeps its id and name). */
  updatePrefabFromSelection(prefabId: string): Prefab | null {
    const prefab = this.getPrefab(prefabId);
    if (!prefab) return null;
    const obj = this.getSelected();
    if (!obj) {
      this.log('warn', 'Select an object in the Hierarchy to update this prefab from.');
      return null;
    }
    const fresh = this.buildPrefab(obj, prefab.name);
    const updated: Prefab = { ...fresh, id: prefab.id, created: prefab.created, updated: Date.now() };
    this.prefabs = this.prefabs.map((p) => (p.id === prefab.id ? updated : p));
    this.persistPrefabs();
    this.log('info', `Prefab "${updated.name}" updated from "${obj.name}" — ${prefabSummary(updated)}.`);
    return updated;
  }

  renamePrefab(prefabId: string, name: string): void {
    const prefab = this.getPrefab(prefabId);
    const clean = (name || '').trim();
    if (!prefab || !clean || clean === prefab.name) return;
    const finalName = uniquePrefabName(this.prefabs.filter((p) => p.id !== prefabId), clean);
    this.prefabs = this.prefabs.map((p) => (p.id === prefabId ? { ...p, name: finalName, updated: Date.now() } : p));
    this.persistPrefabs();
    this.log('log', `Prefab renamed to "${finalName}".`);
  }

  duplicatePrefab(prefabId: string): Prefab | null {
    const prefab = this.getPrefab(prefabId);
    if (!prefab) return null;
    const copy: Prefab = {
      ...prefab,
      id: newPrefabId(),
      name: uniquePrefabName(this.prefabs, prefab.name),
      created: Date.now(),
      updated: Date.now(),
      root: cloneNode(prefab.root),
      scriptSources: prefab.scriptSources.map((s) => ({ ...s })),
    };
    this.prefabs = [copy, ...this.prefabs];
    this.persistPrefabs();
    this.log('log', `Duplicated prefab as "${copy.name}".`);
    return copy;
  }

  deletePrefab(prefabId: string): void {
    const prefab = this.getPrefab(prefabId);
    if (!prefab) return;
    this.prefabs = this.prefabs.filter((p) => p.id !== prefabId);
    this.persistPrefabs();
    this.log('log', `Deleted prefab "${prefab.name}". Objects already placed in a scene are not affected.`);
  }

  /** Where a clicked prefab lands: the centre of the view, on the ground plane. */
  private prefabDropPoint(): { x: number; y: number; z: number } {
    const target = this.orbit?.target ?? { x: 0, y: 0, z: 0 };
    const step = this.prefabPlaceSeq++ % 8;
    const angle = (step / 8) * Math.PI * 2;
    const radius = step === 0 ? 0 : 1.2;
    return {
      x: round((target.x ?? 0) + Math.cos(angle) * radius),
      y: 0,
      z: round((target.z ?? 0) + Math.sin(angle) * radius),
    };
  }

  /**
   * Drop a prefab into the current scene and select the new root.
   * position is optional — without it the prefab lands at the centre of the view.
   */
  instantiatePrefab(prefabId: string, position?: any): GameObject | null {
    const prefab = this.getPrefab(prefabId);
    if (!prefab) {
      this.log('error', `No prefab with the id "${prefabId}".`);
      return null;
    }
    this.ensurePrefabScripts(prefab);
    const drop = position ? vec3From(position) : this.prefabDropPoint();
    const rootObj = this.restorePrefabNode(prefab.root, null, drop, true);
    if (!rootObj) return null;
    this.physics.invalidateAll();
    this.select(rootObj.id);
    this.log('info', `Placed prefab "${prefab.name}" — ${prefabSummary(prefab)}.`);
    this.pushUndo({
      label: `Place prefab ${prefab.name}`,
      undo: () => { this.graph.remove(rootObj.id); this.notify('change'); },
      redo: () => { this.instantiatePrefab(prefab.id, drop); },
    });
    this.notify('change');
    this.scheduleAutosave();
    this.track('prefab_placed', { prefab: prefab.name, objects: prefab.stats.objects });
    return rootObj;
  }

  /**
   * Screen point → world position for a dropped prefab. Raycasts the scene geometry
   * (recursive, ground plane included) and lands on the first surface under the
   * cursor, nudged slightly along its normal so the object sits on top of it rather
   * than embedded in it. When nothing is under the cursor the drop point is projected
   * onto a plane at the camera's current focus distance instead.
   */
  private dropPointFromScreen(clientX: number, clientY: number): { x: number; y: number; z: number } {
    const camera = this.activeCamera();
    const canvas = this.renderer?.domElement;
    if (!camera || !canvas) return this.prefabDropPoint();

    const rect = canvas.getBoundingClientRect();
    if (!rect.width || !rect.height) return this.prefabDropPoint();

    const ndc = new this.three.Vector2(
      ((clientX - rect.left) / rect.width) * 2 - 1,
      -((clientY - rect.top) / rect.height) * 2 + 1,
    );
    const raycaster = new this.three.Raycaster();
    raycaster.setFromCamera(ndc, camera);

    // real scene geometry first (recursive), plus the ground plane
    const targets: any[] = this.graph.roots.filter((o) => o.three.visible).map((o) => o.three);
    if (this.ground && !targets.includes(this.ground)) targets.push(this.ground);

    const hit = raycaster.intersectObjects(targets, true)[0];
    if (hit?.point) {
      const normal = hit.face?.normal
        ? hit.face.normal.clone().transformDirection(hit.object.matrixWorld)
        : new this.three.Vector3(0, 1, 0);
      if (!normal.lengthSq()) normal.set(0, 1, 0);
      // a ground/up-facing surface: sit on top of it, keep the default rotation
      if (hit.object === this.ground || normal.y > 0.9) {
        return { x: round(hit.point.x), y: round(hit.point.y + 0.02), z: round(hit.point.z) };
      }
      return {
        x: round(hit.point.x + normal.x * 0.02),
        y: round(hit.point.y + normal.y * 0.02),
        z: round(hit.point.z + normal.z * 0.02),
      };
    }

    // empty sky — project the drop point onto the plane through the camera's focus
    const focus = this.orbit?.target ?? { x: 0, y: 0, z: 0 };
    const origin = camera.getWorldPosition(new this.three.Vector3());
    const distance = Math.max(1, origin.distanceTo(new this.three.Vector3(focus.x ?? 0, focus.y ?? 0, focus.z ?? 0)));
    const point = raycaster.ray.at(distance, new this.three.Vector3());
    return { x: round(point.x), y: round(point.y), z: round(point.z) };
  }

  /**
   * Drop a prefab from the Prefabs panel onto a point in the viewport. Goes through
   * exactly the same creation path as a click-to-place, only the position differs.
   */
  placePrefabAtScreen(prefabId: string, clientX: number, clientY: number): GameObject | null {
    return this.instantiatePrefab(prefabId, this.dropPointFromScreen(clientX, clientY));
  }

  /**
   * Drop a prefab onto a Hierarchy row: created through the same path as a click, then
   * parented to `parentId` with the hierarchy's own reparenting method. A null parent
   * means the scene root, which leaves the object at the default drop position.
   */
  placePrefabUnder(prefabId: string, parentId: string | null): GameObject | null {
    const obj = this.instantiatePrefab(prefabId);
    if (!obj || !parentId) return obj;
    const parent = this.graph.get(parentId);
    if (!parent) return obj;
    this.setParent(obj.id, parentId);
    this.select(obj.id);
    this.log('log', `Placed prefab "${obj.name}" as a child of "${parent.name}".`);
    return obj;
  }

  /** Scripts a prefab needs but this project does not have are re-created from the snapshot it carries. */
  private ensurePrefabScripts(prefab: Prefab): void {
    for (const snapshot of prefab.scriptSources) {
      if (this.getScript(snapshot.name)) continue;
      this.createScript(snapshot.name, snapshot.source);
      this.log('info', `Prefab "${prefab.name}" brought its script "${snapshot.name}" into this project.`);
    }
  }

  private restorePrefabNode(
    node: PrefabNode,
    parent: GameObject | null,
    drop: { x: number; y: number; z: number },
    isRoot: boolean,
  ): GameObject {
    // a prefab camera never steals the view: only one Main Camera may exist
    if (node.camera?.isMain) {
      for (const other of this.graph.all()) {
        if (other.cameraParams?.isMain) other.cameraParams.isMain = false;
      }
    }
    const def = prefabNodeToSerialized(node, {
      name: this.graph.uniqueName(node.name),
      parentId: parent ? parent.id : null,
      // the root lands at the drop point, keeping its authored height; children keep their local transforms
      position: isRoot ? [drop.x, round(drop.y + node.position[1]), drop.z] : undefined,
    });
    const obj = this.restoreObject(def, parent ? parent.id : null);
    for (const child of node.children) this.restorePrefabNode(child, obj, drop, false);
    return obj;
  }

  /* ----------------------------------------------------------- projects */

  captureProject(): ProjectJSON {
    return {
      format: 'webforge-project',
      version: 1,
      name: this.projectName,
      savedAt: Date.now(),
      objects: this.graph.serializeAll(),
      scripts: this.scripts.map((s) => ({ id: s.id, name: s.name, source: s.source, className: s.className, error: null })),
      environment: { ...this.environment },
      cameraRig: this.editorCamera
        ? {
            position: [round(this.editorCamera.position.x), round(this.editorCamera.position.y), round(this.editorCamera.position.z)],
            target: this.orbit ? [round(this.orbit.target.x), round(this.orbit.target.y), round(this.orbit.target.z)] : [0, 1, 0],
          }
        : null,
    };
  }

  /** Replace the whole scene with a project definition. */
  applyProject(project: ProjectJSON, selectFirst = false): void {
    if (!project || !Array.isArray(project.objects)) {
      throw new Error('That JSON is not a WebForge project (no "objects" array).');
    }
    this.playState = 'stopped';
    this.playSnapshot = null;
    this.graph.clear();
    this.projectName = project.name || 'Untitled Project';
    this.environment = { ...DEFAULT_ENVIRONMENT, ...(project.environment ?? {}) };
    this.applyEnvironment();

    if (Array.isArray(project.scripts)) {
      this.scripts = project.scripts
        .filter((s) => s && s.name && typeof s.source === 'string')
        .map((s) => ({ id: s.id || scriptId(s.name), name: s.name, source: s.source }));
    }
    this.ensureScriptLibrary();
    for (const asset of this.scripts) this.compileAsset(asset);

    const defs = project.objects.filter((d) => d && d.type);
    const roots = defs.filter((d) => !d.parentId);
    const children = defs.filter((d) => d.parentId);

    for (const def of roots) this.restoreObject(def, null);
    // two passes so parents exist before their children
    let remaining = children.slice();
    let guard = 0;
    while (remaining.length && guard++ < 12) {
      const next: SerializedObject[] = [];
      for (const def of remaining) {
        if (this.graph.get(def.parentId!)) this.restoreObject(def, def.parentId!);
        else next.push(def);
      }
      if (next.length === remaining.length) break;
      remaining = next;
    }
    for (const def of remaining) this.restoreObject(def, null);

    this.physics.invalidateAll();

    if (project.cameraRig && this.editorCamera && this.orbit) {
      this.editorCamera.position.set(project.cameraRig.position[0], project.cameraRig.position[1], project.cameraRig.position[2]);
      this.orbit.target.set(project.cameraRig.target[0], project.cameraRig.target[1], project.cameraRig.target[2]);
      this.orbit.update();
    }
    if (selectFirst) {
      const first = this.graph.all()[0];
      this.select(first ? first.id : null);
    } else {
      this.select(null);
    }
    this.notify('change');
  }

  listProjects(): string[] {
    const map = this.readProjectsMap();
    return Object.keys(map).sort();
  }

  saveProject(name?: string): boolean {
    const finalName = (name || this.projectName || 'Untitled Project').trim();
    this.projectName = finalName;
    const project = this.captureProject();
    const map = this.readProjectsMap();
    map[finalName] = project;
    const ok = this.writeStorage(STORAGE_PROJECTS, JSON.stringify(map));
    this.writeStorage(STORAGE_CURRENT, JSON.stringify(project));
    if (ok) this.log('info', `Project "${finalName}" saved in this browser.`);
    else this.log('error', 'Saving failed — the browser storage quota is full. Try exporting the project to a file instead.');
    this.notify('change');
    return ok;
  }

  loadProject(name: string): boolean {
    const map = this.readProjectsMap();
    const project = map[name];
    if (!project) {
      this.log('error', `No saved project called "${name}".`);
      return false;
    }
    this.applyProject(project);
    this.currentScriptId = this.scripts[0]?.id ?? null;
    this.log('info', `Opened project "${name}".`);
    this.scheduleAutosave();
    return true;
  }

  deleteProject(name: string): void {
    const map = this.readProjectsMap();
    delete map[name];
    this.writeStorage(STORAGE_PROJECTS, JSON.stringify(map));
    this.log('log', `Removed saved project "${name}".`);
    this.notify('change');
  }

  newProject(): void {
    this.projectName = 'Untitled Project';
    this.undoStack = [];
    this.redoStack = [];
    this.logs = [];
    this.loadDemoScene();
  }

  exportProjectFile(): void {
    const project = this.captureProject();
    download(`${project.name.replace(/\s+/g, '_') || 'webforge-project'}.json`, JSON.stringify(project, null, 2));
    this.log('info', 'Project exported as JSON.');
    this.track('project_export', { project: project.name });
  }

  async importProjectFile(file: File): Promise<void> {
    const text = await file.text();
    const project = JSON.parse(text) as ProjectJSON;
    this.applyProject(project, true);
    this.currentScriptId = this.scripts[0]?.id ?? null;
    this.log('info', `Imported project "${project.name ?? file.name}".`);
    this.scheduleAutosave();
  }

  exportGLTF(): void {
    if (!this.bundle?.GLTFExporter) {
      this.log('error', 'The glTF exporter is unavailable (CDN addon did not load).');
      return;
    }
    const exporter = new this.bundle.GLTFExporter();
    const exportable = new this.three.Scene();
    for (const root of this.graph.roots) exportable.add(root.three.clone(true));
    exporter.parse(
      exportable,
      (result: any) => {
        const data = result?.arraybuffer ?? result;
        download(`${this.projectName.replace(/\s+/g, '_') || 'scene'}.glb`, new Blob([data], { type: 'model/gltf-binary' }));
        this.log('info', 'Scene exported as glTF (.glb).');
      },
      (err: any) => this.log('error', `glTF export failed: ${err?.message ?? err}`),
      { binary: true, onlyVisible: true },
    );
  }

  /* ----------------------------------------------------------- importing */

  async importModelFile(file: File): Promise<GameObject | null> {
    const ext = (file.name.split('.').pop() || '').toLowerCase();
    if (!['glb', 'gltf', 'obj', 'mtl'].includes(ext)) {
      this.log('warn', `"${file.name}" is not a supported model file (.glb, .gltf or .obj).`);
      return null;
    }
    const buffer = await file.arrayBuffer();
    const id = makeAssetId('model');
    if (isIndexedDbAvailable()) {
      try {
        await putAsset({
          id,
          name: file.name,
          kind: 'model',
          ext,
          mime: file.type || 'application/octet-stream',
          size: buffer.byteLength,
          created: Date.now(),
          data: buffer,
        });
      } catch (err) {
        this.log('warn', `The model could not be cached in this browser: ${err instanceof Error ? err.message : String(err)}`);
      }
    }

    const obj = this.graph.create('Model', file.name.replace(/\.[^.]+$/, ''));
    obj.assetId = id;
    const loaded = await this.loadModelInto(obj, buffer, ext);
    this.select(obj.id);
    this.log(loaded ? 'info' : 'error', loaded ? `Imported "${file.name}".` : `"${file.name}" could not be parsed as a 3D model.`);
    this.notify('change');
    this.scheduleAutosave();
    this.track('model_import', { extension: ext });
    return obj;
  }

  private async loadModelInto(obj: GameObject, buffer: ArrayBuffer, ext: string): Promise<boolean> {
    const bundle = this.bundle;
    if (!bundle) return false;
    try {
      if (ext === 'obj') {
        const text = new TextDecoder().decode(buffer);
        const loader = new bundle.OBJLoader();
        const group = loader.parse(text);
        this.adoptImported(obj, group);
        return true;
      }
      const loader = new bundle.GLTFLoader();
      const data = ext === 'glb' ? buffer : new TextDecoder().decode(buffer);
      const gltf: any = await new Promise((resolve, reject) => {
        loader.parse(data, '', (result: any) => resolve(result), (err: any) => reject(err));
      });
      this.adoptImported(obj, gltf.scene ?? gltf.scenes?.[0]);
      return true;
    } catch (err) {
      this.log('error', `Model parse error: ${err instanceof Error ? err.message : String(err)}`);
      return false;
    }
  }

  private adoptImported(obj: GameObject, root: any): void {
    if (!root) return;
    root.traverse?.((child: any) => {
      if (child.isMesh) {
        child.castShadow = true;
        child.receiveShadow = true;
        if (child.material && 'envMapIntensity' in child.material) child.material.envMapIntensity = 1;
      }
    });
    obj.three.add(root);
    this.physics.invalidate(obj.id);
  }

  /** Re-create a model object's geometry from the asset stored in IndexedDB. */
  private async hydrateModel(obj: GameObject, assetId: string): Promise<void> {
    if (!isIndexedDbAvailable()) return;
    try {
      const asset = await getAsset(assetId);
      if (!asset) return;
      await this.loadModelInto(obj, asset.data, asset.ext);
      this.notify('change');
    } catch {
      this.log('warn', `A stored model (${assetId}) could not be restored.`);
    }
  }

  async importTextureFile(file: File): Promise<void> {
    const obj = this.getSelected();
    if (!obj || !obj.materialParams) {
      this.log('warn', 'Select a mesh first, then import a texture (.png/.jpg/.webp) to apply it.');
      return;
    }
    const ext = (file.name.split('.').pop() || 'png').toLowerCase();
    const buffer = await file.arrayBuffer();
    const id = makeAssetId('tex');
    if (isIndexedDbAvailable()) {
      try {
        await putAsset({ id, name: file.name, kind: 'texture', ext, mime: file.type || 'image/png', size: buffer.byteLength, created: Date.now(), data: buffer });
      } catch {
        /* keep going — the texture still applies for this session */
      }
    }
    await this.applyTextureFromAsset(obj, id, buffer);
    this.log('info', `Applied texture "${file.name}" to ${obj.name}.`);
    this.track('texture_import', { target: obj.name });
  }

  private async applyTextureFromAsset(obj: GameObject, assetId: string, provided?: ArrayBuffer): Promise<void> {
    if (!this.three || !obj.materialParams) return;
    try {
      const buffer = provided ?? (await getAsset(assetId))?.data;
      if (!buffer) return;
      const blob = new Blob([buffer]);
      const url = URL.createObjectURL(blob);
      const texture: any = await new Promise((resolve, reject) => {
        new this.three.TextureLoader().load(url, resolve, undefined, reject);
      });
      if ('colorSpace' in texture) texture.colorSpace = this.three.SRGBColorSpace;
      texture.wrapS = this.three.RepeatWrapping;
      texture.wrapT = this.three.RepeatWrapping;
      texture.anisotropy = 4;
      obj.tags.textureObjectUrl = url;
      obj.setTexture(texture, assetId, null);
      this.notify('change');
    } catch (err) {
      this.log('error', `Texture could not be applied: ${err instanceof Error ? err.message : String(err)}`);
    }
  }

  async removeStoredAsset(id: string): Promise<void> {
    if (!isIndexedDbAvailable()) return;
    await deleteAsset(id).catch(() => undefined);
  }

  /* ------------------------------------------------------------- console */

  log(level: LogLevel, message: string, info?: { script?: string; line?: number }): void {
    const entry: LogEntry = {
      id: this.logId++,
      level,
      message,
      time: Date.now(),
      script: info?.script,
      line: info?.line,
    };
    this.logs = [...this.logs.slice(-399), entry];
    this.notify('change');
  }

  clearConsole(): void {
    this.logs = [];
    this.notify('change');
  }

  /* ----------------------------------------------------- script editor UI */

  currentScriptId: string | null = null;

  setCurrentScript(id: string | null): void {
    this.currentScriptId = id;
    this.notify('change');
  }

  /* ------------------------------------------------------- subscriptions */

  subscribe(event: EngineEvent, cb: () => void): () => void {
    this.listeners[event].add(cb);
    return () => { this.listeners[event].delete(cb); };
  }

  private notify(event: EngineEvent): void {
    if (event === 'change') this.version++;
    else if (event === 'stats') this.statsVersion++;
    else this.remoteVersion++;
    for (const cb of [...this.listeners[event]]) {
      try {
        cb();
      } catch {
        /* a broken listener must not break the engine */
      }
    }
  }

  onSceneChanged(): void {
    this.sceneDirty = true;
    this.scheduleAutosave();
  }

  /** UI-friendly alias: mark the scene dirty so panels repaint on the next frame. */
  notifyChange(): void {
    this.onSceneChanged();
  }

  notifyRemote(): void {
    this.bridgeHandled = this.bridge?.handled ?? 0;
    this.notify('remote');
  }

  /* ------------------------------------------------------------ storage */

  private readStorage(key: string): string | null {
    try { return localStorage.getItem(key); } catch { return null; }
  }

  private writeStorage(key: string, value: string): boolean {
    try { localStorage.setItem(key, value); return true; } catch { return false; }
  }

  private readProjectsMap(): Record<string, ProjectJSON> {
    const raw = this.readStorage(STORAGE_PROJECTS);
    if (!raw) return {};
    try { return JSON.parse(raw) as Record<string, ProjectJSON>; } catch { return {}; }
  }

  private scheduleAutosave(): void {
    if (!this.ready) return;
    if (this.autosaveTimer !== null) window.clearTimeout(this.autosaveTimer);
    this.autosaveTimer = window.setTimeout(() => {
      this.autosaveTimer = null;
      this.persistNow();
    }, 1600);
  }

  persistNow(): void {
    if (!this.ready) return;
    try {
      this.writeStorage(STORAGE_CURRENT, JSON.stringify(this.captureProject()));
    } catch {
      /* quota — ignore, the user can still export */
    }
  }

  /* ------------------------------------------------------------ teardown */

  dispose(): void {
    this.disposed = true;
    if (this.rafId) cancelAnimationFrame(this.rafId);
    if (this.autosaveTimer !== null) window.clearTimeout(this.autosaveTimer);
    try { this.persistNow(); } catch { /* ignore */ }
    this.bridge?.stop();
    this.remote?.dispose();
    if (this.resizeObserver) {
      try { this.resizeObserver.disconnect(); } catch { /* ignore */ }
    }
    this.three = null;
  }

  /* ------------------------------------------------------------ helpers */

  track(event: string, props?: Record<string, any>): void {
    try {
      (window as any).supercool?.track?.(event, props);
    } catch {
      /* analytics must never break the app */
    }
  }

  objectTypes(): ObjectType[] { return OBJECT_TYPES; }
}

/* ------------------------------------------------------------------ utils */

function normalizeKey(key: string): string {
  const k = String(key || '').toLowerCase();
  if (k === ' ') return 'space';
  if (k === 'escape' || k === 'esc') return 'escape';
  if (k === 'delete' || k === 'backspace') return 'delete';
  if (k === 'control' || k === 'meta') return k;
  return k;
}

function sanitizeType(type: string): ObjectType {
  const cleaned = String(type || 'Cube');
  const match = OBJECT_TYPES.find((t) => t.toLowerCase() === cleaned.toLowerCase());
  return (match ?? 'Cube') as ObjectType;
}

function isTypingTarget(target: EventTarget | null): boolean {
  const el = target as HTMLElement | null;
  if (!el || !el.tagName) return false;
  const tag = el.tagName.toLowerCase();
  return tag === 'input' || tag === 'textarea' || tag === 'select' || el.isContentEditable === true;
}

/** Prefab nodes are plain JSON, so a structured copy is all a duplicate needs. */
function cloneNode(node: PrefabNode): PrefabNode {
  return JSON.parse(JSON.stringify(node)) as PrefabNode;
}

function round(n: number): number {
  return Math.round(n * 1000) / 1000;
}

/** Strip engine internals before sending anything back over an API boundary. */
function toTransferable(value: any, depth = 0): any {
  if (value === null || value === undefined) return value ?? null;
  if (typeof value === 'number' || typeof value === 'string' || typeof value === 'boolean') return value;
  if (depth > 4) return '[…]';
  if (value.__kind === 'gameobject') return { id: value.id, name: value.name, type: value.type };
  if (value.__kind === 'transform') return { position: value.position, rotation: value.rotation };
  if (Array.isArray(value)) return value.map((v) => toTransferable(v, depth + 1));
  if (value.isVector3 || (typeof value.x === 'number' && typeof value.y === 'number' && typeof value.z === 'number')) {
    return { x: round(value.x), y: round(value.y), z: round(value.z) };
  }
  if (typeof value === 'object') {
    const out: Record<string, any> = {};
    for (const key of Object.keys(value)) {
      const v = value[key];
      if (typeof v === 'function' || typeof v === 'symbol') continue;
      out[key] = toTransferable(v, depth + 1);
    }
    return out;
  }
  return String(value);
}
