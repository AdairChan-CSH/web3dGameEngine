/**
 * Shared types for the WebForge engine.
 * Everything in src/engine is plain imperative code (no React) so the engine
 * can also be driven from an iframe, the browser console or a remote server.
 */

export type LogLevel = 'log' | 'info' | 'warn' | 'error';

export interface LogEntry {
  id: number;
  level: LogLevel;
  message: string;
  time: number;
  /** script the error came from, when known */
  script?: string;
  /** 1-based source line inside that script */
  line?: number;
}

/** A user script as stored in the project + edited in the Script Editor. */
export interface ScriptAsset {
  id: string;
  name: string;
  source: string;
  /** filled in after a successful compile */
  className?: string;
  error?: { message: string; line: number } | null;
}

export type FieldKind = 'number' | 'string' | 'bool' | 'vec3';

/** Public field of a script class, surfaced as an Inspector input. */
export interface FieldSpec {
  name: string;
  type: string;
  kind: FieldKind;
  value: any;
}

/** Live instance of a compiled class attached to a GameObject. */
export interface ScriptInstance {
  id: string;
  scriptName: string;
  className: string;
  fields: Record<string, any>;
  started: boolean;
  /** opaque per-instance interpreter scope */
  state: any;
  enabled: boolean;
}

export type ObjectType =
  | 'Cube'
  | 'Sphere'
  | 'Plane'
  | 'Cylinder'
  | 'Torus'
  | 'Capsule'
  | 'Cone'
  | 'Light'
  | 'Camera'
  | 'Empty'
  | 'Model';

export interface MaterialParams {
  color: string;
  metalness: number;
  roughness: number;
  emissive: string;
  emissiveIntensity: number;
  wireframe: boolean;
  opacity: number;
  transparent: boolean;
  doubleSided: boolean;
  textureUrl?: string | null;
  textureAssetId?: string | null;
}

export interface LightParams {
  kind: 'point' | 'directional' | 'spot';
  color: string;
  intensity: number;
  distance: number;
  castShadow: boolean;
}

export interface CameraParams {
  fov: number;
  near: number;
  far: number;
  isMain: boolean;
}

export interface PhysicsParams {
  usePhysics: boolean;
  useGravity: boolean;
  kinematic: boolean;
  mass: number;
  bounce: number;
  collides: boolean;
}

export interface SerializedScript {
  scriptName: string;
  className: string;
  fields: Record<string, any>;
  enabled: boolean;
}

export interface SerializedObject {
  id: string;
  name: string;
  type: ObjectType;
  parentId: string | null;
  position: [number, number, number];
  rotation: [number, number, number];
  scale: [number, number, number];
  visible: boolean;
  material?: MaterialParams;
  light?: LightParams;
  camera?: CameraParams;
  physics?: PhysicsParams;
  scripts: SerializedScript[];
  assetId?: string | null;
  isPlayer?: boolean;
}

export interface EnvironmentSettings {
  sky: 'dusk' | 'noon' | 'night' | 'neon';
  fog: number;
  ground: boolean;
  grid: boolean;
  shadows: boolean;
  ambient: number;
  exposure: number;
}

export interface ProjectJSON {
  format: 'webforge-project';
  version: 1;
  name: string;
  savedAt: number;
  objects: SerializedObject[];
  scripts: ScriptAsset[];
  environment: EnvironmentSettings;
  /** cameras, in preset order */
  cameraRig?: { position: [number, number, number]; target: [number, number, number] } | null;
}

export type GizmoMode = 'translate' | 'rotate' | 'scale';
export type PlayState = 'stopped' | 'playing' | 'paused';
export type ViewTab = 'scene' | 'game' | 'api' | 'remote' | 'docs';

export interface EngineStats {
  fps: number;
  drawCalls: number;
  triangles: number;
  objects: number;
  scripts: number;
  textures: number;
  geometries: number;
}

/** A single diagnosed problem from the scene health check. */
export interface SceneHealthIssue {
  /** object id (or the node id that is at fault) */
  id: string;
  name: string;
  /** short, human-readable explanation */
  detail: string;
}

/** Snapshot of the gizmo attachment taken while the health check runs. */
export interface SceneHealthGizmo {
  mode: GizmoMode;
  /** true when the transform gizmo currently has a node attached */
  attached: boolean;
  /** id of the attached object, when it can be resolved */
  targetId: string | null;
  /** name of the attached object, when it can be resolved */
  targetName: string | null;
  /** true when the attached node still reaches the scene root */
  valid: boolean;
}

/** Structured result of EngineCore.checkSceneHealth(). */
export interface SceneHealthReport {
  /** false while the engine is still loading (scene / graph not built yet) */
  ready: boolean;
  /** number of objects the check inspected */
  objectCount: number;
  /** objects whose three.js node is not attached to the scene root */
  detached: SceneHealthIssue[];
  /** the current selection pointing at a deleted or detached object */
  selection: SceneHealthIssue[];
  /** objects that should carry geometry but have none */
  geometry: SceneHealthIssue[];
  /** problems with the gizmo attachment itself */
  gizmoIssues: SceneHealthIssue[];
  /** the gizmo target state (reported whether or not it is a problem) */
  gizmo: SceneHealthGizmo;
  /** total number of problems found across every category */
  total: number;

}

/** Structured result of EngineCore.repairScene(): the audit plus everything the repair changed. */
export interface SceneRepairReport {
  /** false while the engine is still loading (scene / graph not built yet) */
  ready: boolean;
  /** the scene health audit the repair ran first */
  audit: SceneHealthReport;
  /** detached nodes that were added back to the scene root */
  reattached: SceneHealthIssue[];
  /** detached objects the repair could not fix (e.g. no three.js node at all) */
  unrepairable: SceneHealthIssue[];
  /** the dead selection that was cleared, when there was one */
  selectionCleared: SceneHealthIssue | null;
  /** the gizmo attachment state after the repair ran */
  gizmo: SceneHealthGizmo;
  /** no-geometry objects, deliberately left untouched for manual review */
  leftForManualReview: SceneHealthIssue[];
  /** number of fixes the repair applied */
  fixed: number;
}


export interface ApiMethodDoc {
  name: string;
  signature: string;
  description: string;
  /** JSON array of arguments, executed by the "Run" button */
  sample: string;
  category: ApiCategory;
  returns?: string;
}

export type ApiCategory =
  | 'Objects'
  | 'Transforms'
  | 'Materials'
  | 'Scripts'
  | 'Animation'
  | 'Events'
  | 'Playback'
  | 'Scenes'
  | 'Prefabs'
  | 'Diagnostics';

export interface RemoteLogEntry {
  id: number;
  direction: 'in' | 'out' | 'status';
  text: string;
  time: number;
}

export interface RemoteStatus {
  mode: 'mock' | 'websocket' | 'poll';
  status: 'disconnected' | 'connecting' | 'connected' | 'error';
  url: string;
  detail: string;
}
