/**
 * Ready-made content: the preloaded example scripts plus the demo scene that is
 * built on first load (and whenever "New Project" is chosen).
 *
 * The scripts here are written in the engine's own C#/Java-flavoured language
 * and are compiled by src/engine/script-vm.ts — nothing is evaluated as JS.
 */

import type { GameObject, ObjectType } from './scene';
import type { ScriptAsset } from './types';

/** The slice of the engine the demo scene builder needs. */
export interface DemoEngine {
  createObject(type: ObjectType, name?: string, position?: any, parent?: GameObject | null): GameObject;
  attachScript(obj: GameObject, scriptName: string, fields?: Record<string, any>): any;
}

export function scriptId(name: string): string {
  return `script_${name}`;
}

/* ------------------------------------------------------------ example code */

const PLAYER_CONTROLLER = `class PlayerController extends Component {
  public float moveSpeed = 7.0;
  public float jumpForce = 10.0;
  public float gravity = 22.0;
  public float groundY = 1.0;

  float vy = 0.0;
  bool onGround = true;

  void Start() {
    Debug.log("PlayerController ready on " + this.object.name);
  }

  void Update(float dt) {
    float x = 0.0;
    float z = 0.0;
    if (Input.getKey("w") || Input.getKey("arrowup")) { z = z - 1.0; }
    if (Input.getKey("s") || Input.getKey("arrowdown")) { z = z + 1.0; }
    if (Input.getKey("a") || Input.getKey("arrowleft")) { x = x - 1.0; }
    if (Input.getKey("d") || Input.getKey("arrowright")) { x = x + 1.0; }

    float speed = this.moveSpeed;
    if (Input.getKey("shift")) { speed = this.moveSpeed * 1.8; }

    Vector3 dir = new Vector3(x, 0.0, z);
    if (dir.length() > 0.001) {
      dir = dir.normalize();
      this.transform.position.x = this.transform.position.x + dir.x * speed * dt;
      this.transform.position.z = this.transform.position.z + dir.z * speed * dt;
      this.transform.rotation.y = Math.atan2(dir.x, dir.z) * 57.29578;
    }

    this.vy = this.vy - this.gravity * dt;
    this.transform.position.y = this.transform.position.y + this.vy * dt;

    if (this.transform.position.y <= this.groundY) {
      this.transform.position.y = this.groundY;
      this.vy = 0.0;
      this.onGround = true;
    } else {
      this.onGround = false;
    }

    if (Input.getKeyDown("space") && this.onGround) {
      this.vy = this.jumpForce;
      this.onGround = false;
      this.emit("player_jump", 1);
      Debug.log("Player jumped");
    }
  }
}`;

const ROTATOR = `class Rotator extends Component {
  public float speedX = 0.0;
  public float speedY = 60.0;
  public float speedZ = 0.0;

  void Update(float dt) {
    this.transform.rotate(this.speedX * dt, this.speedY * dt, this.speedZ * dt);
  }
}`;

const ORBIT = `class Orbit extends Component {
  public string targetName = "Orbit Center";
  public float radius = 6.0;
  public float speed = 45.0;
  public float height = 3.0;

  float angle = 0.0;

  void Start() {
    this.angle = Random.range(0.0, 360.0);
  }

  void Update(float dt) {
    this.angle = this.angle + this.speed * dt;
    float rad = Math.deg2Rad(this.angle);
    float cx = 0.0;
    float cz = 0.0;

    GameObject target = this.find(this.targetName);
    if (target != null) {
      cx = target.transform.position.x;
      cz = target.transform.position.z;
    }

    this.transform.position.x = cx + Math.cos(rad) * this.radius;
    this.transform.position.z = cz + Math.sin(rad) * this.radius;
    this.transform.position.y = this.height;
  }
}`;

const FOLLOW_CAMERA = `class FollowCamera extends Component {
  public string targetName = "Player";
  public float distance = 8.0;
  public float height = 4.0;
  public float damping = 4.0;

  void Update(float dt) {
    GameObject target = this.find(this.targetName);
    if (target == null) { return; }

    float k = Math.clamp01(this.damping * dt);
    float tx = target.transform.position.x;
    float ty = target.transform.position.y + this.height;
    float tz = target.transform.position.z + this.distance;

    this.transform.position.x = this.transform.position.x + (tx - this.transform.position.x) * k;
    this.transform.position.y = this.transform.position.y + (ty - this.transform.position.y) * k;
    this.transform.position.z = this.transform.position.z + (tz - this.transform.position.z) * k;

    this.transform.lookAt(target);
  }
}`;

const BOB_AND_FLOAT = `class BobAndFloat extends Component {
  public float amplitude = 0.5;
  public float speed = 1.8;
  public float spin = 30.0;

  float baseY = 0.0;
  float t = 0.0;

  void Start() {
    this.baseY = this.transform.position.y;
    this.t = Random.range(0.0, 6.283);
  }

  void Update(float dt) {
    this.t = this.t + dt * this.speed;
    this.transform.position.y = this.baseY + Math.sin(this.t) * this.amplitude;
    this.transform.rotate(0.0, this.spin * dt, 0.0);
  }
}`;

const PULSATE = `class Pulsate extends Component {
  public float amount = 0.25;
  public float speed = 3.0;
  public float emissiveBoost = 1.6;

  float base = 1.0;
  float t = 0.0;

  void Start() {
    this.base = this.transform.scale.x;
  }

  void Update(float dt) {
    this.t = this.t + dt * this.speed;
    float pulse = 1.0 + Math.sin(this.t) * this.amount;
    this.transform.scale = new Vector3(this.base * pulse, this.base * pulse, this.base * pulse);
  }
}`;

const SPAWNER = `class Spawner extends Component {
  public float interval = 2.5;
  public string spawnType = "Cube";
  public int maxSpawned = 10;
  public float radius = 7.0;
  public float dropHeight = 9.0;

  int spawned = 0;
  float timer = 0.0;

  void Update(float dt) {
    this.timer = this.timer + dt;
    if (this.timer < this.interval) { return; }
    if (this.spawned >= this.maxSpawned) { return; }

    this.timer = 0.0;
    this.spawned = this.spawned + 1;

    float a = Random.range(0.0, 6.2832);
    float x = Math.cos(a) * this.radius;
    float z = Math.sin(a) * this.radius;

    GameObject cube = this.instantiate(this.spawnType, x, this.dropHeight, z);
    if (cube != null) {
      cube.setColor("#7cd4ff");
      Debug.log("Spawner dropped " + cube.name);
    }
  }
}`;

const CLICK_TO_DESTROY = `class ClickToDestroy extends Component {
  public int hitsToDestroy = 3;
  public float shrinkPerHit = 0.22;

  int hits = 0;

  void OnClick() {
    this.hits = this.hits + 1;
    Debug.log(this.object.name + " clicked (" + this.hits + "/" + this.hitsToDestroy + ")");

    float s = this.transform.scale.x - this.shrinkPerHit;
    if (s < 0.2) { s = 0.2; }
    this.transform.scale = new Vector3(s, s, s);

    if (this.hits >= this.hitsToDestroy) {
      this.emit("object_destroyed", this.object.name);
      Debug.log("Destroying " + this.object.name);
      this.destroy();
    }
  }
}`;

const COLLISION_REPORTER = `class CollisionReporter extends Component {
  public bool logHits = true;
  public float bounceForce = 7.0;
  public int hitsBeforeReset = 4;

  int hits = 0;

  void Start() {
    Debug.log("CollisionReporter watching " + this.object.name);
  }

  void OnCollision(Collision other) {
    this.hits = this.hits + 1;
    if (this.logHits) {
      Debug.log(this.object.name + " hit " + other.name + " (" + this.hits + ")");
    }
    this.object.velocity.y = this.bounceForce;

    if (this.hits >= this.hitsBeforeReset) {
      this.hits = 0;
      this.transform.position = new Vector3(Random.range(-6.0, 6.0), 8.0, Random.range(-6.0, 6.0));
      this.emit("ball_reset", this.object.name);
    }
  }

  void OnKeyDown(string key) {
    if (key == "r") {
      Debug.log("Manual reset of " + this.object.name);
      this.transform.position = new Vector3(0.0, 8.0, 0.0);
      this.object.velocity = new Vector3(0.0, 0.0, 0.0);
    }
  }
}`;

export const EXAMPLE_SCRIPTS: ScriptAsset[] = [
  { id: scriptId('PlayerController'), name: 'PlayerController', source: PLAYER_CONTROLLER },
  { id: scriptId('Rotator'), name: 'Rotator', source: ROTATOR },
  { id: scriptId('Orbit'), name: 'Orbit', source: ORBIT },
  { id: scriptId('FollowCamera'), name: 'FollowCamera', source: FOLLOW_CAMERA },
  { id: scriptId('BobAndFloat'), name: 'BobAndFloat', source: BOB_AND_FLOAT },
  { id: scriptId('Pulsate'), name: 'Pulsate', source: PULSATE },
  { id: scriptId('Spawner'), name: 'Spawner', source: SPAWNER },
  { id: scriptId('ClickToDestroy'), name: 'ClickToDestroy', source: CLICK_TO_DESTROY },
  { id: scriptId('CollisionReporter'), name: 'CollisionReporter', source: COLLISION_REPORTER },
];

export const NEW_SCRIPT_TEMPLATE = `class MyBehaviour extends Component {
  public float speed = 1.0;
  public bool active = true;

  void Start() {
    Debug.log("Hello from " + this.object.name);
  }

  void Update(float dt) {
    // dt is the frame time in seconds
    if (!this.active) { return; }
    this.transform.rotate(0.0, this.speed * 30.0 * dt, 0.0);
  }
}`;

/* ------------------------------------------------------------ demo scene */

/**
 * Builds the showcase scene: lit ground, a controllable player capsule, orbiting
 * and spinning props, floating cubes, a pulsating core with a coloured light,
 * a spawner and clickable crates.
 */
export function buildDemoScene(engine: DemoEngine): void {
  const v3 = (x: number, y: number, z: number) => [x, y, z] as [number, number, number];

  // --- playground centre (parents the orbiter so `find` works inside a branch)
  const center = engine.createObject('Empty', 'Orbit Center', v3(0, 0, 0));

  // --- the player
  const player = engine.createObject('Capsule', 'Player', v3(0, 1, 0));
  player.applyMaterialParams({ color: '#4ea8ff', metalness: 0.5, roughness: 0.25 });
  player.isPlayer = true;
  engine.attachScript(player, 'PlayerController', { moveSpeed: 7.5, jumpForce: 10.5 });

  // --- a smooth-follow chase camera (promote it to Main Camera in the Inspector)
  const camera = engine.createObject('Camera', 'Follow Camera', v3(0, 5, 10));
  engine.attachScript(camera, 'FollowCamera', { distance: 9, height: 4, damping: 3.5 });

  // --- orbiting sphere
  const orbiter = engine.createObject('Sphere', 'Orbiter', v3(6, 3, 0), center);
  orbiter.transform.scale.set(0.9, 0.9, 0.9);
  orbiter.applyMaterialParams({ color: '#ffd166', metalness: 0.7, roughness: 0.2, emissive: '#3a2200', emissiveIntensity: 0.6 });
  engine.attachScript(orbiter, 'Orbit', { radius: 6.5, speed: 42, height: 3.2, targetName: 'Orbit Center' });

  // --- spinning props
  const propSpecs: Array<[string, string, [number, number, number], number[]]> = [
    ['Prop Cube A', 'Cube', v3(-6, 1.2, -5), [0, 55, 0]],
    ['Prop Cube B', 'Cube', v3(-6, 1.2, 5), [25, 55, 0]],
    ['Prop Torus', 'Torus', v3(6, 1.4, -6), [40, 0, 0]],
    ['Spin Cylinder', 'Cylinder', v3(6, 1.5, 6), [0, 90, 12]],
  ];
  const propColors = ['#ff6b9d', '#8be9a8', '#c792ea', '#ffb457'];
  propSpecs.forEach((spec, i) => {
    const [name, type, pos, spin] = spec;
    const obj = engine.createObject(type as ObjectType, name, pos);
    obj.applyMaterialParams({ color: propColors[i % propColors.length], metalness: 0.35, roughness: 0.4 });
    engine.attachScript(obj, 'Rotator', { speedX: spin[0], speedY: spin[1], speedZ: spin[2] });
  });

  // --- floating cubes
  const floatSpecs: Array<[string, [number, number, number], number]> = [
    ['Floating Cube 1', v3(-2.5, 3.2, -2.5), 3],
    ['Floating Cube 2', v3(2.5, 4.4, -1.5), 4],
    ['Floating Cube 3', v3(0, 5.6, 3), 5],
  ];
  floatSpecs.forEach(([name, pos, height], i) => {
    const obj = engine.createObject('Cube', name, pos);
    obj.transform.scale.set(0.7, 0.7, 0.7);
    obj.applyMaterialParams({ color: '#7cd4ff', metalness: 0.6, roughness: 0.25, emissive: '#123a4d', emissiveIntensity: 0.5 });
    engine.attachScript(obj, 'BobAndFloat', { amplitude: 0.35 + i * 0.12, speed: 1.4 + i * 0.3, spin: 25 + i * 10 });
  });

  // --- pulsating core with a coloured glow light
  const core = engine.createObject('Sphere', 'Pulse Core', v3(0, 2.2, -8));
  core.transform.scale.set(1.4, 1.4, 1.4);
  core.applyMaterialParams({ color: '#ff4fa3', metalness: 0.2, roughness: 0.15, emissive: '#ff2e88', emissiveIntensity: 1.1 });
  engine.attachScript(core, 'Pulsate', { amount: 0.2, speed: 2.4 });

  const coreLight = engine.createObject('Light', 'Core Glow', v3(0, 2.2, -8));
  coreLight.applyLightParams({ color: '#ff3fa4', intensity: 12, distance: 26 });

  // --- extra coloured lights
  const cyanLight = engine.createObject('Light', 'Cyan Accent', v3(-8, 3.5, 7));
  cyanLight.applyLightParams({ color: '#28d6ff', intensity: 9, distance: 24 });

  // --- clickable crates (they fall and settle with physics on)
  const cratePositions: Array<[number, number, number]> = [
    [-2.2, 0.5, 4.5],
    [-4.4, 0.5, 2.2],
    [-1.2, 0.5, 6.8],
  ];
  cratePositions.forEach((pos, i) => {
    const crate = engine.createObject('Cube', `Crate ${i + 1}`, pos);
    crate.transform.scale.set(0.9, 0.9, 0.9);
    crate.applyMaterialParams({ color: '#d8a657', metalness: 0.2, roughness: 0.75 });
    crate.physics.usePhysics = true;
    crate.physics.bounce = 0.18;
    engine.attachScript(crate, 'ClickToDestroy', { hitsToDestroy: 3, shrinkPerHit: 0.2 });
  });

  // --- a bouncing ball that reports every collision
  const ball = engine.createObject('Sphere', 'Reporter Ball', v3(4.5, 8, 2));
  ball.transform.scale.set(1.1, 1.1, 1.1);
  ball.applyMaterialParams({ color: '#a6ff6b', metalness: 0.3, roughness: 0.3, emissive: '#1f3d0a', emissiveIntensity: 0.5 });
  ball.physics.usePhysics = true;
  ball.physics.bounce = 0.55;
  engine.attachScript(ball, 'CollisionReporter', { bounceForce: 8, hitsBeforeReset: 5, logHits: true });

  // --- runtime spawner (spawned primitives get physics, so they fall and bounce)
  const spawner = engine.createObject('Empty', 'Spawner', v3(0, 0.1, 0));
  engine.attachScript(spawner, 'Spawner', { interval: 3.0, maxSpawned: 8, radius: 8, dropHeight: 10 });
}
