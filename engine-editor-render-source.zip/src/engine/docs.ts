/**
 * Content for the in-app "API & Docs" tab.
 * Pure data + copyable code samples: the external API reference, the scripting
 * reference, the postMessage/WebSocket protocols and the PHP bridge examples.
 */

import type { ApiMethodDoc } from './types';

/** The documented external control API (window.Engine / window.GameEngine). */
export const API_METHODS: ApiMethodDoc[] = [
  /* ----------------------------------------------------------- objects */
  {
    name: 'createObject',
    signature: 'Engine.createObject(name: string, type?: string) → string',
    description:
      'Adds a GameObject to the scene and returns its id. Types: Cube, Sphere, Plane, Cylinder, Torus, Capsule, Cone, Light, Camera, Empty.',
    sample: '["RemoteCube", "Cube"]',
    category: 'Objects',
    returns: 'object id',
  },
  {
    name: 'destroy',
    signature: 'Engine.destroy(id: string) → boolean',
    description: 'Removes the object and its children from the scene.',
    sample: '["<selected>"]',
    category: 'Objects',
    returns: 'boolean',
  },
  {
    name: 'find',
    signature: 'Engine.find(name: string) → { id, name, type, position } | null',
    description: 'Looks an object up by name (depth first, first match wins).',
    sample: '["Orbiter"]',
    category: 'Objects',
    returns: 'object info or null',
  },
  {
    name: 'listObjects',
    signature: 'Engine.listObjects() → Array<{ id, name, type }>',
    description: 'Flat list of every object in the scene, handy for building external UIs.',
    sample: '[]',
    category: 'Objects',
    returns: 'array of objects',
  },
  {
    name: 'setVisible',
    signature: 'Engine.setVisible(id: string, visible: boolean) → boolean',
    description: 'Shows or hides an object (and anything parented to it).',
    sample: '["<selected>", true]',
    category: 'Objects',
    returns: 'boolean',
  },
  {
    name: 'rename',
    signature: 'Engine.rename(id: string, name: string) → boolean',
    description: 'Renames an object. Scripts that look it up by name see the new name immediately.',
    sample: '["<selected>", "Renamed From API"]',
    category: 'Objects',
    returns: 'boolean',
  },

  /* --------------------------------------------------------- transforms */
  {
    name: 'setPosition',
    signature: 'Engine.setPosition(id: string, x: number, y: number, z: number) → boolean',
    description: 'Sets the world position of an object.',
    sample: '["<selected>", 2, 1.5, 0]',
    category: 'Transforms',
    returns: 'boolean',
  },
  {
    name: 'setRotation',
    signature: 'Engine.setRotation(id: string, xDeg: number, yDeg: number, zDeg: number) → boolean',
    description: 'Sets the euler rotation in degrees (same numbers the Inspector shows).',
    sample: '["<selected>", 0, 45, 0]',
    category: 'Transforms',
    returns: 'boolean',
  },
  {
    name: 'setScale',
    signature: 'Engine.setScale(id: string, x: number, y: number, z: number) → boolean',
    description: 'Sets the local scale.',
    sample: '["<selected>", 1.5, 1.5, 1.5]',
    category: 'Transforms',
    returns: 'boolean',
  },
  {
    name: 'move',
    signature: 'Engine.move(id: string, dx: number, dy: number, dz: number) → boolean',
    description: 'Relative move — adds to the current position.',
    sample: '["<selected>", 0, 1, 0]',
    category: 'Transforms',
    returns: 'boolean',
  },
  {
    name: 'getTransform',
    signature: 'Engine.getTransform(id: string) → { position, rotation, scale }',
    description: 'Reads the transform. Rotation is in degrees.',
    sample: '["<selected>"]',
    category: 'Transforms',
    returns: 'transform',
  },
  {
    name: 'setVelocity',
    signature: 'Engine.setVelocity(id: string, x: number, y: number, z: number) → boolean',
    description: 'Sets the physics velocity. The object needs "Use Physics" enabled in the Inspector.',
    sample: '["<selected>", 0, 8, 0]',
    category: 'Transforms',
    returns: 'boolean',
  },
  {
    name: 'applyImpulse',
    signature: 'Engine.applyImpulse(id: string, x: number, y: number, z: number) → boolean',
    description: 'Adds to the current physics velocity — the classic "launch object" call.',
    sample: '["<selected>", 0, 6, 0]',
    category: 'Transforms',
    returns: 'boolean',
  },

  /* ---------------------------------------------------------- materials */
  {
    name: 'setColor',
    signature: 'Engine.setColor(id: string, cssColor: string) → boolean',
    description: 'Sets the albedo colour of a mesh.',
    sample: '["<selected>", "#ff8844"]',
    category: 'Materials',
    returns: 'boolean',
  },
  {
    name: 'setMaterial',
    signature: 'Engine.setMaterial(id: string, { metalness, roughness, emissive, emissiveIntensity, opacity, wireframe }) → boolean',
    description: 'Patches any PBR material property in one call.',
    sample: '["<selected>", {"metalness": 0.9, "roughness": 0.15}]',
    category: 'Materials',
    returns: 'boolean',
  },
  {
    name: 'setLight',
    signature: 'Engine.setLight(id: string, { color, intensity, distance }) → boolean',
    description: 'Updates a Light object created with createObject(name, "Light").',
    sample: '["<selected>", {"color": "#ff44aa", "intensity": 4}]',
    category: 'Materials',
    returns: 'boolean',
  },

  /* ------------------------------------------------------------ scripts */
  {
    name: 'attachScript',
    signature: 'Engine.attachScript(id: string, scriptName: string, fields?: object) → boolean',
    description: 'Attaches one of the project scripts to an object, optionally overriding its public fields.',
    sample: '["<selected>", "Rotator", {"speedY": 120}]',
    category: 'Scripts',
    returns: 'boolean',
  },
  {
    name: 'removeScript',
    signature: 'Engine.removeScript(id: string, scriptName: string) → boolean',
    description: 'Detaches a script by class name.',
    sample: '["<selected>", "Rotator"]',
    category: 'Scripts',
    returns: 'boolean',
  },
  {
    name: 'setScriptField',
    signature: 'Engine.setScriptField(id: string, scriptName: string, field: string, value: any) → boolean',
    description: 'Changes a public field of a running script — the same inputs the Inspector shows.',
    sample: '["<selected>", "Rotator", "speedY", 240]',
    category: 'Scripts',
    returns: 'boolean',
  },
  {
    name: 'listScripts',
    signature: 'Engine.listScripts() → Array<{ name, className, fields, attached }>',
    description: 'Lists the project scripts and how many objects currently use them.',
    sample: '[]',
    category: 'Scripts',
    returns: 'array of scripts',
  },

  /* ---------------------------------------------------------- animation */
  {
    name: 'animate',
    signature: 'Engine.animate(id, { position, rotation, scale, duration, loop, yoyo, relative, easing }) → animationId',
    description:
      'Tween helper. position/rotation/scale accept [x,y,z] or {x,y,z}. duration is in seconds, loop repeats forever, yoyo ping-pongs, easing is linear | easeIn | easeOut | easeInOut | sine | bounce.',
    sample: '["<selected>", {"position": [0, 3, 0], "duration": 1.5, "loop": true, "yoyo": true, "easing": "easeInOut"}]',
    category: 'Animation',
    returns: 'animation id',
  },
  {
    name: 'stopAnimation',
    signature: 'Engine.stopAnimation(animationId: string) → boolean',
    description: 'Stops a tween created by animate().',
    sample: '["<selected>"]',
    category: 'Animation',
    returns: 'boolean',
  },
  {
    name: 'listAnimations',
    signature: 'Engine.listAnimations() → Array<{ id, target, elapsed, duration }>',
    description: 'Shows every running tween.',
    sample: '[]',
    category: 'Animation',
    returns: 'array of animations',
  },

  /* ------------------------------------------------------------- events */
  {
    name: 'emitEvent',
    signature: 'Engine.emitEvent(name: string, payload?: any) → number',
    description: 'Fires a named engine event; every subscriber and every script listening through this.emit sees it.',
    sample: '["demo_config", {"theme": "neon", "wave": 3}]',
    category: 'Events',
    returns: 'number of subscribers notified',
  },
  {
    name: 'on',
    signature: 'Engine.on(name: string, handler: (payload) => void) → unsubscribe()',
    description:
      'Subscribes to an engine event from outside the app (browser console, parent page, your own UI). Returns an unsubscribe function.',
    sample: '["demo_config", null]',
    category: 'Events',
    returns: 'unsubscribe function',
  },
  {
    name: 'off',
    signature: 'Engine.off(name: string, handler?: Function) → boolean',
    description: 'Removes one handler, or every handler when omitted.',
    sample: '["demo_config"]',
    category: 'Events',
    returns: 'boolean',
  },

  /* ----------------------------------------------------------- playback */
  { name: 'play', signature: 'Engine.play() → boolean', description: 'Starts play mode: Start() runs once, then Update(dt) every frame and physics steps.', sample: '[]', category: 'Playback', returns: 'boolean' },
  { name: 'pause', signature: 'Engine.pause() → boolean', description: 'Freezes the simulation but keeps rendering the scene.', sample: '[]', category: 'Playback', returns: 'boolean' },
  { name: 'stop', signature: 'Engine.stop() → boolean', description: 'Stops play mode and restores the scene to the state it had when play started.', sample: '[]', category: 'Playback', returns: 'boolean' },
  { name: 'isPlaying', signature: 'Engine.isPlaying() → "playing" | "paused" | "stopped"', description: 'Current playback state.', sample: '[]', category: 'Playback', returns: 'string' },

  /* -------------------------------------------------------------- scenes */
  {
    name: 'exportScene',
    signature: 'Engine.exportScene() → projectJson',
    description: 'Serialises the whole project (objects, transforms, components, scripts) to a JSON object you can store anywhere.',
    sample: '[]',
    category: 'Scenes',
    returns: 'project JSON',
  },
  {
    name: 'loadScene',
    signature: 'Engine.loadScene(json: object | string) → boolean',
    description: 'Replaces the current scene with a previously exported project. Null or empty input changes nothing.',
    sample: '[null]',
    category: 'Scenes',
    returns: 'boolean',
  },
  {
    name: 'clearScene',
    signature: 'Engine.clearScene() → boolean',
    description: 'Deletes every object. Useful for starting a fresh remote-built scene.',
    sample: '[]',
    category: 'Scenes',
    returns: 'boolean',
  },
  {
    name: 'saveProject',
    signature: 'Engine.saveProject(name: string) → boolean',
    description: 'Saves the project into the browser (localStorage) under a name so it appears in the Projects menu.',
    sample: '["API Saved Project"]',
    category: 'Scenes',
    returns: 'boolean',
  },
  {
    name: 'listProjects',
    signature: 'Engine.listProjects() → string[]',
    description: 'Names of every project saved in this browser.',
    sample: '[]',
    category: 'Scenes',
    returns: 'array of names',
  },
  /* -------------------------------------------------------------- prefabs */
  {
    name: 'listPrefabs',
    signature: 'Engine.listPrefabs() → [{ id, name, objects, scripts, physics }]',
    description: 'Every prefab saved in this browser — the same library the Prefabs panel shows.',
    sample: '[]',
    category: 'Prefabs',
    returns: 'array of prefabs',
  },
  {
    name: 'savePrefab',
    signature: 'Engine.savePrefab(id: string, name?: string) → { id, name, objects } | null',
    description:
      'Saves an object — with its children, materials, physics settings and attached scripts — as a reusable prefab. Pass null as the id to use the current Hierarchy selection.',
    sample: '[null, "Console Prefab"]',
    category: 'Prefabs',
    returns: 'the new prefab',
  },
  {
    name: 'placePrefab',
    signature: 'Engine.placePrefab(nameOrId: string, x?: number, y?: number, z?: number) → { id, name }',
    description: 'Drops a copy of a prefab into the current scene. Without coordinates it lands at the centre of the view.',
    sample: '["Physics Crate"]',
    category: 'Prefabs',
    returns: 'the new root object',
  },

  /* --------------------------------------------------------- diagnostics */
  { name: 'log', signature: 'Engine.log(message: string) → void', description: 'Writes a line into the in-app Console.', sample: '["hello from the API"]', category: 'Diagnostics' },
  { name: 'getStats', signature: 'Engine.getStats() → { fps, drawCalls, triangles, objects, scripts }', description: 'Live renderer statistics.', sample: '[]', category: 'Diagnostics', returns: 'stats' },
  { name: 'getSelection', signature: 'Engine.getSelection() → { id, name } | null', description: 'The object currently selected in the Hierarchy.', sample: '[]', category: 'Diagnostics', returns: 'object or null' },
  { name: 'ping', signature: 'Engine.ping() → { engine, version, ready, time }', description: 'Health check — good first call when a parent page needs to know the editor is loaded.', sample: '[]', category: 'Diagnostics', returns: 'handshake object' },
];

export const API_CATEGORIES = [
  'Objects',
  'Transforms',
  'Materials',
  'Scripts',
  'Animation',
  'Events',
  'Playback',
  'Scenes',
  'Prefabs',
  'Diagnostics',
] as const;

export interface ScriptRefEntry { signature: string; description: string }
export interface ScriptRefGroup { group: string; entries: ScriptRefEntry[] }

/** Everything a user script can call. */
export const SCRIPT_REFERENCE: ScriptRefGroup[] = [
  {
    group: 'Lifecycle',
    entries: [
      { signature: 'void Start()', description: 'Called once when play mode starts or the script is attached while playing.' },
      { signature: 'void Update(float dt)', description: 'Called every frame. dt is the frame time in seconds.' },
      { signature: 'void FixedUpdate(float dt)', description: 'Called at a fixed 60 Hz step — use it for physics work.' },
      { signature: 'void LateUpdate(float dt)', description: 'Called after Update, just before rendering.' },
      { signature: 'void OnCollision(Collision other)', description: 'Called when this object hits the ground or another object. other.name, other.point, other.normal, other.relativeVelocity.' },
      { signature: 'void OnKeyDown(string key)', description: 'Called the frame a key is pressed while playing ("w", "space", "arrowup"…).' },
      { signature: 'void OnClick()', description: 'Called when this object is clicked in the viewport while playing.' },
      { signature: 'void OnEvent(string name, object payload)', description: 'Called when Engine.emitEvent(name, payload) fires.' },
    ],
  },
  {
    group: 'this — the component',
    entries: [
      { signature: 'this.transform', description: 'Transform of the owning object: .position, .rotation (degrees), .scale, .translate(x,y,z), .rotate(x,y,z), .lookAt(target), .setPosition/.setRotation/.setScale.' },
      { signature: 'this.object', description: 'The GameObject: .name, .id, .type, .visible, .find(name), .setColor(hex), .setActive(bool), .destroy(), .instantiate(type).' },
      { signature: 'this.emit(name, payload)', description: 'Fires an engine event that external code can subscribe to with Engine.on().' },
      { signature: 'this.log(...values)', description: 'Writes to the Console.' },
      { signature: 'this.find(name)', description: 'Shorthand for this.object.find(name) — returns a GameObject or null.' },
      { signature: 'this.instantiate(type, x, y, z)', description: 'Creates a primitive at runtime (physics enabled so it falls). Returns the new GameObject.' },
      { signature: 'this.destroy()', description: 'Destroys the owning object.' },
      { signature: 'this.setColor(hex)', description: 'Sets the object colour.' },
      { signature: 'this.deltaTime / this.time', description: 'Frame time and seconds since play started.' },
      { signature: 'this.enabled', description: 'Set false to pause this script without detaching it.' },
    ],
  },
  {
    group: 'Input',
    entries: [
      { signature: 'Input.getKey(key)', description: 'True while held. Keys: "w","a","s","d","space","shift","arrowup","arrowdown","arrowleft","arrowright","escape","q","e","r","f".' },
      { signature: 'Input.getKeyDown(key)', description: 'True only on the frame the key went down — the right choice for jump.' },
      { signature: 'Input.getKeyUp(key)', description: 'True on the frame the key was released.' },
      { signature: 'Input.getAxis("horizontal" | "vertical")', description: 'Analog axis in -1..1 driven by the keyboard or the on-screen touch stick.' },
      { signature: 'Input.mouseX / Input.mouseY', description: 'Mouse look delta for the current frame.' },
    ],
  },
  {
    group: 'Math / Random / Time',
    entries: [
      { signature: 'Math.sin cos tan atan2 sqrt abs floor ceil round sign min max pow hypot', description: 'Standard maths, angles in radians.' },
      { signature: 'Math.random()', description: '0..1.' },
      { signature: 'Math.lerp(a, b, t)', description: 'Linear interpolation.' },
      { signature: 'Math.clamp(v, lo, hi) / Math.clamp01(v)', description: 'Clamp a value.' },
      { signature: 'Math.moveTowards(a, b, d) / Math.smoothstep(t)', description: 'Handy easing helpers.' },
      { signature: 'Math.deg2Rad(d) / Math.rad2Deg(r)', description: 'Angle conversion.' },
      { signature: 'Random.range(a, b)', description: 'Float between a and b.' },
      { signature: 'Random.int(a, b)', description: 'Integer between a and b inclusive.' },
      { signature: 'Random.chance(p)', description: 'True with probability p.' },
      { signature: 'Random.insideUnitSphere()', description: 'Random Vector3 inside a unit sphere.' },
      { signature: 'Time.deltaTime / Time.time / Time.frameCount', description: 'Frame timing.' },
      { signature: 'Time.fixedDeltaTime', description: 'The physics step (1/60).' },
    ],
  },
  {
    group: 'Vector3 / Quaternion',
    entries: [
      { signature: 'new Vector3(x, y, z)', description: 'Creates a vector. Also accepts another vector or [x,y,z].' },
      { signature: 'Vector3.zero / one / up / down / left / right / forward / back', description: 'Shared constants (fresh copies).' },
      { signature: 'v.add(v2) v.sub(v2) v.mul(scalar) v.normalize() v.set(x,y,z)', description: 'Mutating operations, return the same vector.' },
      { signature: 'v.length() / v.magnitude / v.distanceTo(v2)', description: 'Magnitude helpers.' },
      { signature: 'Vector3.lerp(a, b, t) / Vector3.distance(a, b) / Vector3.dot(a, b) / Vector3.cross(a, b)', description: 'Static helpers.' },
      { signature: 'new Quaternion() / Quaternion.euler(x,y,z) / Quaternion.axisAngle(x,y,z,deg)', description: 'Rotation values. Assign to this.transform.rotation to apply.' },
      { signature: 'Quaternion.slerp(a, b, t)', description: 'Spherical interpolation.' },
    ],
  },
  {
    group: 'Language',
    entries: [
      { signature: 'class X extends Component { }', description: 'One class per script file. Public fields become Inspector inputs.' },
      { signature: 'public float speed = 5.0;', description: 'Field types: float, int, double, string, bool, Vector3, Quaternion, or an inferred `let`.' },
      { signature: 'float Helper(float a) { return a * 2; }', description: 'Your own methods, callable as this.Helper(x).' },
      { signature: 'if / else if / else', description: 'Conditionals with && || ! and full comparison operators.' },
      { signature: 'while (cond) { }   for (int i = 0; i < n; i++) { }', description: 'Loops with break and continue.' },
      { signature: 'let / var / typed locals', description: 'Local variables: `let x = 1;` or `float x = 1;`.' },
    ],
  },
];

export const SCRIPT_EXAMPLE = `class PlayerController extends Component {
  public float moveSpeed = 6.0;
  public float jumpForce = 9.0;
  public bool canFly = false;

  void Start() {
    Debug.log("Player ready: " + this.object.name);
  }

  void Update(float dt) {
    float x = 0.0;
    float z = 0.0;
    if (Input.getKey("w")) { z = z - 1; }
    if (Input.getKey("s")) { z = z + 1; }
    if (Input.getKey("a")) { x = x - 1; }
    if (Input.getKey("d")) { x = x + 1; }

    Vector3 dir = new Vector3(x, 0, z);
    if (dir.length() > 0) {
      dir = dir.normalize();
      this.transform.position.x = this.transform.position.x + dir.x * this.moveSpeed * dt;
      this.transform.position.z = this.transform.position.z + dir.z * this.moveSpeed * dt;
    }

    if (Input.getKeyDown("space")) { this.emit("player_jump", this.object.name); }
  }
}`;

export const POSTMESSAGE_EXAMPLE = `<!-- Parent page: drive the embedded editor -->
<iframe id="forge" src="https://your-editor-url/" width="100%" height="720"></iframe>

<script>
  const frame = document.getElementById('forge');
  let seq = 0;
  const pending = new Map();

  // Send a command and get a promise for the result
  function call(method, args = []) {
    const id = ++seq;
    frame.contentWindow.postMessage({ target: 'engine', id, method, args }, '*');
    return new Promise((resolve) => pending.set(id, resolve));
  }

  window.addEventListener('message', (event) => {
    const data = event.data;
    if (!data || data.target !== 'parent') return;
    const resolve = pending.get(data.id);
    if (resolve) { pending.delete(data.id); resolve(data); }
  });

  (async () => {
    // wait for the editor to boot
    await new Promise((r) => setTimeout(r, 3000));
    console.log(await call('ping'));
    const id = (await call('createObject', ['From Parent Page', 'Cube'])).result;
    await call('setPosition', [id, 0, 4, 0]);
    await call('setMaterial', [id, { metalness: 0.8, roughness: 0.2 }]);
    await call('animate', [id, { rotation: [0, 360, 0], duration: 4, loop: true }]);
    await call('on', ['player_jump', null]);      // subscribe inside the editor
    await call('play', []);
  })();
</script>`;

export const WS_PROTOCOL = `// ---- handshake: the engine sends this the moment the socket opens ----
{ "type": "handshake", "engine": "webforge", "version": 1, "transport": "json-commands" }

// ---- server -> engine: one command packet (or an array of them) ----
{ "id": 42, "method": "setPosition", "args": ["obj_abc", 1, 2, 3] }

// ---- engine -> server: the reply, logged in the Remote Control panel ----
{ "id": 42, "ok": true, "result": true }

// Any method from the API table works. "<selected>" resolves to the
// object selected in the Hierarchy, so a remote can drive the editor's
// current selection:
{ "id": 43, "method": "setColor", "args": ["<selected>", "#ff4488"] }`;

export const PHP_BRIDGE = `<?php
/**
 * engine_bridge.php — WebForge command bridge (plain PHP, no Composer, no Ratchet).
 *
 * Polling transport (works on any shared host):
 *   Run:  php -S localhost:8099 engine_bridge.php
 *   Then set the Remote Control panel to "HTTP polling" with
 *   URL http://localhost:8099/engine_bridge.php?action=poll and Connect.
 *
 * Endpoints
 *   POST ?action=poll      engine hands in its status, gets queued commands
 *   POST ?action=response  engine reports the result of a command
 *   POST ?action=push      any server-side code queues a command for the engine
 *   GET  ?action=log       recent traffic, for debugging
 */

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

define('QUEUE_FILE', __DIR__ . '/engine_queue.json');
define('RESPONSE_FILE', __DIR__ . '/engine_responses.json');

function load_json($file) {
    if (!file_exists($file)) { return array(); }
    $data = json_decode(file_get_contents($file), true);
    return is_array($data) ? $data : array();
}
function save_json($file, $data) {
    file_put_contents($file, json_encode($data), LOCK_EX);
}
function read_body() {
    $raw = file_get_contents('php://input');
    $json = json_decode($raw, true);
    return is_array($json) ? $json : array();
}

$action = isset($_GET['action']) ? $_GET['action'] : 'poll';
$body = read_body();

switch ($action) {
    case 'poll':
        // Engine asks: "anything for me?"
        $queue = load_json(QUEUE_FILE);
        save_json(QUEUE_FILE, array());       // commands are delivered once
        echo json_encode(array(
            'ok' => true,
            'engine' => 'webforge',
            'commands' => array_values($queue),
        ));
        break;

    case 'push':
        // A PHP script (or curl) queues a command for the engine.
        if (empty($body['method'])) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'method required'));
            break;
        }
        $queue = load_json(QUEUE_FILE);
        $queue[] = array(
            'id'     => uniqid('cmd_', true),
            'method' => $body['method'],
            'args'   => isset($body['args']) ? $body['args'] : array(),
        );
        save_json(QUEUE_FILE, $queue);
        echo json_encode(array('ok' => true, 'queued' => count($queue)));
        break;

    case 'response':
        // Engine reports a result so the server can act on it.
        $log = load_json(RESPONSE_FILE);
        $log[] = array('at' => date('c'), 'reply' => $body);
        save_json(RESPONSE_FILE, array_slice($log, -200));
        echo json_encode(array('ok' => true));
        break;

    case 'log':
        echo json_encode(array(
            'queue' => load_json(QUEUE_FILE),
            'responses' => array_slice(load_json(RESPONSE_FILE), -50),
        ));
        break;

    default:
        http_response_code(404);
        echo json_encode(array('ok' => false, 'error' => 'unknown action'));
}
`;

export const PHP_REST_RELAY = `<?php
/**
 * control.php — one-call REST relay. The browser page (or curl) asks for a
 * single command; the queue is handed to the engine on its next poll.
 *
 *   /control.php?cmd=moveObject&id=obj_abc&x=0&y=2&z=0
 *   /control.php?cmd=setColor&id=obj_abc&color=%23ff4488
 */

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

$cmd = isset($_GET['cmd']) ? $_GET['cmd'] : '';
$args = array();
switch ($cmd) {
    case 'moveObject':
        $args = array(
            isset($_GET['id']) ? $_GET['id'] : '',
            (float)(isset($_GET['x']) ? $_GET['x'] : 0),
            (float)(isset($_GET['y']) ? $_GET['y'] : 0),
            (float)(isset($_GET['z']) ? $_GET['z'] : 0),
        );
        $method = 'move';
        break;
    case 'setColor':
        $method = 'setColor';
        $args = array(isset($_GET['id']) ? $_GET['id'] : '', isset($_GET['color']) ? $_GET['color'] : '#ffffff');
        break;
    case 'play':   $method = 'play';  break;
    case 'stop':   $method = 'stop';  break;
    case 'status': $method = 'getStats'; break;
    default:
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'unknown cmd'));
        exit;
}

// queue it for the engine
$queue = file_exists(__DIR__ . '/engine_queue.json')
    ? json_decode(file_get_contents(__DIR__ . '/engine_queue.json'), true)
    : array();
if (!is_array($queue)) { $queue = array(); }
$queue[] = array('id' => uniqid('rest_', true), 'method' => $method, 'args' => $args);
file_put_contents(__DIR__ . '/engine_queue.json', json_encode($queue), LOCK_EX);

echo json_encode(array('ok' => true, 'queued' => $method, 'args' => $args, 'pending' => count($queue)));
`;

export const CURL_EXAMPLES = `# 1. Queue a command for the engine (the editor picks it up on its next poll)
curl -X POST "https://your-host/engine_bridge.php?action=push" \\
     -H "Content-Type: application/json" \\
     -d '{"method":"createObject","args":["Curl Cube","Cube"]}'

# 2. Move an object that already exists
curl -X POST "https://your-host/engine_bridge.php?action=push" \\
     -H "Content-Type: application/json" \\
     -d '{"method":"setPosition","args":["Curl Cube",0,3,0]}'

# 3. Start play mode from the server
curl -X POST "https://your-host/engine_bridge.php?action=push" \\
     -H "Content-Type: application/json" -d '{"method":"play","args":[]}'

# 4. Read the traffic log
curl "https://your-host/engine_bridge.php?action=log"

# 5. Same thing over the REST relay
curl "https://your-host/control.php?cmd=moveObject&id=Curl%20Cube&x=0&y=5&z=2"`;

export const WEBSOCKET_NOTE = `A raw WebSocket server cannot be written in plain PHP without an event loop, so
the shipped bridge uses HTTP polling (see engine_bridge.php) — it works on any
shared host and needs no extensions.

If you want true push delivery, run any small WebSocket relay in front of the
same queue and point the Remote Control panel at it (ws://…). The engine sends a
JSON handshake on connect and then speaks the packet format shown above, so a
relay is 20 lines in Node, Go, Rust or Python — it only has to move two kinds of
JSON message between the socket and the queue.`;

export const SCRIPTS_QUICKSTART = `// Open the "Script Editor" tab at the bottom, press "New Script", paste this
// and attach it to any object from the Inspector → Scripts → Add Script.
//
// Note what is NOT needed: you never register Update, never build a loop and
// never touch the DOM. The engine parses this file and calls your methods.

class Spinner extends Component {
  public float speed = 90.0;      // becomes a drag-able Inspector input
  public bool bob = true;

  float t = 0.0;
  float baseY = 0.0;

  void Start() {
    this.baseY = this.transform.position.y;
  }

  void Update(float dt) {
    this.t = this.t + dt;
    this.transform.rotate(0, this.speed * dt, 0);
    if (this.bob) {
      this.transform.position.y = this.baseY + Math.sin(this.t * 2) * 0.4;
    }
  }
}`;
