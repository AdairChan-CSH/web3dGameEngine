/**
 * Prefab drag-and-drop coordination.
 *
 * A prefab card in the Prefabs panel can be dragged onto the 3D viewport (place it
 * where the cursor is) or onto a Hierarchy row (place it as a child of that object).
 * While the drag runs this module keeps:
 *
 *   - the prefab currently being dragged (`id` + `name`), used as a fallback because
 *     some browsers zero out `dataTransfer` during `dragover`,
 *   - a translucent "ghost" chip that follows the cursor,
 *   - a class on `document.body` so the viewport and the Hierarchy tree can show
 *     their drop affordances through CSS,
 *   - the window listeners that move the ghost and clean everything up on dragend.
 *
 * Everything here is additive: the plain click-to-place path never touches it.
 */

/** Custom MIME type carried by a prefab drag. */
export const PREFAB_DRAG_MIME = 'application/x-prefab';
/** Prefix of the `text/plain` fallback payload. */
const TEXT_PREFIX = 'prefab:';
/** Class put on <body> for the duration of a prefab drag. */
export const PREFAB_DRAG_BODY_CLASS = 'prefab-drag-active';
/** Class of the floating drag chip. */
const GHOST_CLASS = 'prefab-drag-ghost';

export type PrefabDragState = { id: string; name: string };

let state: PrefabDragState | null = null;
let ghost: HTMLDivElement | null = null;
let listening = false;

/** The prefab being dragged right now (null when no prefab drag is in progress). */
export function getPrefabDrag(): PrefabDragState | null {
  return state;
}

export function isPrefabDragActive(): boolean {
  return state !== null;
}

/**
 * Read the prefab id out of a drag event. Tries the custom type first, then the
 * `text/plain` fallback, and finally the module-level drag state — browsers that
 * hide `dataTransfer` during dragover still work through the last one.
 */
export function readPrefabDragId(dt: DataTransfer | null): string | null {
  if (dt) {
    let custom = '';
    try {
      custom = dt.getData(PREFAB_DRAG_MIME);
    } catch {
      custom = '';
    }
    if (custom) return custom;

    let text = '';
    try {
      text = dt.getData('text/plain');
    } catch {
      text = '';
    }
    if (text && text.startsWith(TEXT_PREFIX)) {
      const id = text.slice(TEXT_PREFIX.length).split('|')[0].trim();
      if (id) return id;
    }
  }
  return state ? state.id : null;
}

/** Stamp a prefab drag onto the event and flag the drag as in progress. */
export function writePrefabDragData(dt: DataTransfer | null, id: string, name: string): void {
  if (dt) {
    try {
      dt.setData(PREFAB_DRAG_MIME, id);
      dt.setData('text/plain', `${TEXT_PREFIX}${id}|${name}`);
    } catch {
      /* a browser that refuses custom types is covered by the module state */
    }
    dt.effectAllowed = 'copy';
  }
  beginPrefabDrag(id, name);
}

/** Flag a prefab drag as in progress and show the cursor ghost. */
export function beginPrefabDrag(id: string, name: string): void {
  state = { id, name };
  if (typeof document === 'undefined') return;

  document.body?.classList.add(PREFAB_DRAG_BODY_CLASS);
  showGhost(name);
  listen(true);
}

/** Clear every trace of the drag: ghost, body class, highlight state, listeners. */
export function endPrefabDrag(): void {
  if (typeof document !== 'undefined') document.body?.classList.remove(PREFAB_DRAG_BODY_CLASS);
  hideGhost();
  listen(false);
  state = null;
}

/* ------------------------------------------------------------------ internals */

function showGhost(name: string): void {
  hideGhost();
  if (typeof document === 'undefined') return;
  const el = document.createElement('div');
  el.className = GHOST_CLASS;
  el.setAttribute('aria-hidden', 'true');
  el.textContent = name;
  document.body.appendChild(el);
  ghost = el;
}

function hideGhost(): void {
  if (!ghost) return;
  ghost.remove();
  ghost = null;
}

function moveGhost(x: number, y: number): void {
  if (!ghost) return;
  ghost.style.transform = `translate3d(${Math.round(x + 14)}px, ${Math.round(y + 14)}px, 0)`;
}

function onWindowDragOver(event: DragEvent): void {
  if (!state) return;
  moveGhost(event.clientX, event.clientY);
}

function onWindowDragEnd(): void {
  endPrefabDrag();
}

function listen(on: boolean): void {
  if (typeof window === 'undefined' || on === listening) return;
  listening = on;
  if (on) {
    window.addEventListener('dragover', onWindowDragOver, true);
    window.addEventListener('dragend', onWindowDragEnd);
    window.addEventListener('drop', onWindowDragEnd);
  } else {
    window.removeEventListener('dragover', onWindowDragOver, true);
    window.removeEventListener('dragend', onWindowDragEnd);
    window.removeEventListener('drop', onWindowDragEnd);
  }
}
