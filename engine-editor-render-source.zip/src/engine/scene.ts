/**
 * Scene graph: GameObjects, transform handles, primitive mesh factory.
 *
 * A GameObject is a thin editor-facing wrapper around a three.js Object3D:
 * it carries the identity (id/name/type), the user-editable component data
 * (material / light / camera / physics / scripts) and the hierarchy links the
 * Hierarchy panel walks.
 */

import type {
  CameraParams,
  LightParams,
  MaterialParams,
  ObjectType,
  PhysicsParams,
  ScriptInstance,
  SerializedObject,
} from './types';

export const DEFAULT_MATERIAL: MaterialParams = {
  color: '#9aa7bd',
  metalness: 0.3,
  roughness: 0.55,
  emissive: '#000000',
  emissiveIntensity: 0,
  wireframe: false,
  opacity: 1,
  transparent: false,
  doubleSided: false,
  textureUrl: null,
  textureAssetId: null,
};

export const DEFAULT_LIGHT: LightParams = {
  kind: 'point',
  color: '#ffd7a8',
  intensity: 2.4,
  distance: 22,
  castShadow: true,
};

export const DEFAULT_CAMERA: CameraParams = { fov: 60, near: 0.1, far: 600, isMain: false };
export const DEFAULT_PHYSICS: PhysicsParams = {
  usePhysics: false,
  useGravity: true,
  kinematic: false,
  mass: 1,
  bounce: 0.25,
  collides: true,
};

/** Mesh primitives offered in the Add Object menu (plus Light/Camera/Empty/Model). */
export const OBJECT_TYPES: ObjectType[] = [
  'Cube',
  'Sphere',
  'Plane',
  'Cylinder',
  'Torus',
  'Capsule',
  'Cone',
  'Light',
  'Camera',
  'Empty',
  'Model',
];

const DEG = Math.PI / 180;

export function hexToNumber(hex: string): number {
  if (!hex) return 0xffffff;
  const clean = hex.replace('#', '').trim();
  const full = clean.length === 3 ? clean.split('').map((c) => c + c).join('') : clean;
  const n = parseInt(full, 16);
  return Number.isNaN(n) ? 0xffffff : n;
}

export function numberToHex(value: number): string {
  return '#' + ('000000' + (value | 0).toString(16)).slice(-6);
}
/* -------------------------------------------------------------------- ids */

/**
 * Module-scope id generator for scene objects (prefix convention `obj_…`,
 * matching the ids the external API docs hand back for created objects).
 *
 * Deliberately NOT a class method — callers use the free function `newId(...)`,
 * never `this.newId(...)`. Counter + random suffix, so every call is unique.
 */
let __idCounter = 0;
export function newId(prefix = 'obj'): string {
  __idCounter += 1;
  return `${prefix}_${__idCounter.toString(36)}${Math.random().toString(36).slice(2, 6)}`;
}

/* --------------------------------------------------------------- transform */

/** Rotation wrapper that speaks degrees (editor friendly) over a three Euler. */
export class EulerHandle {
  constructor(private euler: any) {}

  get x() { return this.euler.x / DEG; }
  set x(v: number) { this.euler.x = (v || 0) * DEG; }
  get y() { return this.euler.y / DEG; }
  set y(v: number) { this.euler.y = (v || 0) * DEG; }
  get z() { return this.euler.z / DEG; }
  set z(v: number) { this.euler.z = (v || 0) * DEG; }

  set(x: number, y: number, z: number): EulerHandle { this.x = x; this.y = y; this.z = z; return this; }
  add(x: number, y: number, z: number): EulerHandle { this.x += x; this.y += y; this.z += z; return this; }
  clone(): EulerHandle { return new EulerHandle({ x: this.euler.x, y: this.euler.y, z: this.euler.z }); }
  toString(): string { return `(${this.x.toFixed(1)}, ${this.y.toFixed(1)}, ${this.z.toFixed(1)})`; }
}

export class TransformHandle {
  __kind = 'transform';
  constructor(private obj: any, private three: any) {}

  get position(): any { return this.obj.position; }
  set position(v: any) { writeVec(this.obj.position, v); }

  get rotation(): EulerHandle { return new EulerHandle(this.obj.rotation); }
  set rotation(v: any) {
    if (v && v.isQuaternion) {
      const e = new this.three.Euler().setFromQuaternion(v, 'XYZ');
      this.obj.rotation.set(e.x, e.y, e.z);
      return;
    }
    this.obj.rotation.set(readComponent(v, 'x') * DEG, readComponent(v, 'y') * DEG, readComponent(v, 'z') * DEG);
  }

  get scale(): any { return this.obj.scale; }
  set scale(v: any) { writeVec(this.obj.scale, v); }

  /** relative move, in world units */
  translate(x: any, y?: number, z?: number): TransformHandle {
    if (x && typeof x === 'object') this.obj.position.add(x);
    else this.obj.position.add(new this.three.Vector3(Number(x) || 0, Number(y) || 0, Number(z) || 0));
    return this;
  }

  /** relative rotation in degrees */
  rotate(x: any, y?: number, z?: number): TransformHandle {
    if (x && typeof x === 'object') {
      this.obj.rotation.x += readComponent(x, 'x') * DEG;
      this.obj.rotation.y += readComponent(x, 'y') * DEG;
      this.obj.rotation.z += readComponent(x, 'z') * DEG;
    } else {
      this.obj.rotation.x += (Number(x) || 0) * DEG;
      this.obj.rotation.y += (Number(y) || 0) * DEG;
      this.obj.rotation.z += (Number(z) || 0) * DEG;
    }
    return this;
  }

  setPosition(x: any, y?: number, z?: number): TransformHandle {
    if (x && typeof x === 'object') writeVec(this.obj.position, x);
    else this.obj.position.set(Number(x) || 0, Number(y) || 0, Number(z) || 0);
    return this;
  }

  setRotation(x: any, y?: number, z?: number): TransformHandle {
    if (x && typeof x === 'object') this.rotation = x;
    else {
      this.obj.rotation.set((Number(x) || 0) * DEG, (Number(y) || 0) * DEG, (Number(z) || 0) * DEG);
    }
    return this;
  }

  setScale(x: any, y?: number, z?: number): TransformHandle {
    if (x && typeof x === 'object') writeVec(this.obj.scale, x);
    else this.obj.scale.set(Number(x) || 1, Number(y) || 1, Number(z) || 1);
    return this;
  }

  lookAt(target: any): TransformHandle {
    const t = target && target.__kind === 'gameobject' ? target.three.position : target;
    if (t) this.obj.lookAt(new this.three.Vector3(readComponent(t, 'x'), readComponent(t, 'y'), readComponent(t, 'z')));
    return this;
  }

  copyFrom(other: TransformHandle): TransformHandle {
    this.obj.position.copy(other.obj.position);
    this.obj.rotation.copy(other.obj.rotation);
    this.obj.scale.copy(other.obj.scale);
    return this;
  }
}

function readComponent(v: any, axis: string): number {
  if (typeof v === 'number') return v;
  if (!v) return 0;
  const n = Number(v[axis]);
  return Number.isFinite(n) ? n : 0;
}

function writeVec(target: any, v: any): void {
  if (!v) return;
  if (Array.isArray(v)) target.set(Number(v[0]) || 0, Number(v[1]) || 0, Number(v[2]) || 0);
  else target.set(Number(v.x) || 0, Number(v.y) || 0, Number(v.z) || 0);
}

/* -------------------------------------------------------------- GameObject */

export interface GameObjectDef {
  id: string;
  name: string;
  type: ObjectType;
  object3D?: any;
  parentId?: string | null;
}

export class GameObject {
  __kind = 'gameobject';
  id: string;
  name: string;
  type: ObjectType;
  three: any;
  transform: TransformHandle;
  graph: SceneGraph;

  parent: GameObject | null = null;
  children: GameObject[] = [];

  materialParams: MaterialParams | null = null;
  threeMaterial: any = null;
  lightParams: LightParams | null = null;
  light: any = null;
  cameraParams: CameraParams | null = null;
  camera: any = null;
  physics: PhysicsParams = { ...DEFAULT_PHYSICS };

  scripts: ScriptInstance[] = [];
  assetId: string | null = null;
  isPlayer = false;

  /** runtime state used by the physics world + user scripts */
  velocity: any;
  angularVelocity: any;
  grounded = false;

  tags: Record<string, any> = {};

  constructor(private threeNS: any, graph: SceneGraph, def: GameObjectDef) {
    this.graph = graph;
    this.id = def.id;
    this.name = def.name;
    this.type = def.type;
    this.three = def.object3D ?? new threeNS.Group();
    this.three.userData.engineId = def.id;
    this.transform = new TransformHandle(this.three, threeNS);
    this.velocity = new threeNS.Vector3();
    this.angularVelocity = new threeNS.Vector3();
  }

  get visible(): boolean { return this.three.visible; }
  set visible(v: boolean) { this.three.visible = !!v; }

  rename(name: string): GameObject {
    this.name = name;
    this.three.name = name;
    this.graph.touch();
    return this;
  }

  setActive(on: boolean): GameObject {
    this.visible = on;
    this.graph.touch();
    return this;
  }

  addChild(child: GameObject): void {
    if (child.parent === this) return;
    child.detach();
    this.children.push(child);
    child.parent = this;
    this.three.add(child.three);
    child.three.matrixAutoUpdate = true;
    this.graph.touch();
  }

  detach(): void {
    if (this.parent) {
      const idx = this.parent.children.indexOf(this);
      if (idx >= 0) this.parent.children.splice(idx, 1);
      this.parent.three.remove(this.three);
      this.parent = null;
    }
  }

  removeChild(child: GameObject): void {
    const idx = this.children.indexOf(child);
    if (idx >= 0) {
      this.children.splice(idx, 1);
      this.three.remove(child.three);
      child.parent = null;
    }
  }

  /** Depth first search by name (self included). */
  find(name: string): GameObject | null {
    if (this.name === name) return this;
    for (const child of this.children) {
      const hit = child.find(name);
      if (hit) return hit;
    }
    return null;
  }

  /** Look up a component instance by class name. */
  getComponent(className: string): ScriptInstance | null {
    return this.scripts.find((s) => s.className === className || s.scriptName === className) ?? null;
  }

  getScriptsByClassName(className: string): ScriptInstance[] {
    return this.scripts.filter((s) => s.className === className || s.scriptName === className);
  }

  traverse(cb: (obj: GameObject) => void): void {
    cb(this);
    for (const child of this.children) child.traverse(cb);
  }

  setColor(hex: string): GameObject {
    if (this.materialParams) this.applyMaterialParams({ color: hex });
    return this;
  }

  applyMaterialParams(patch: Partial<MaterialParams>): GameObject {
    if (!this.materialParams || !this.threeMaterial) return this;
    Object.assign(this.materialParams, patch);
    const p = this.materialParams;
    if (patch.color) this.threeMaterial.color.set(hexToNumber(p.color));
    if (patch.emissive !== undefined) this.threeMaterial.emissive.set(hexToNumber(p.emissive));
    if (patch.emissiveIntensity !== undefined) this.threeMaterial.emissiveIntensity = p.emissiveIntensity;
    if (patch.metalness !== undefined) this.threeMaterial.metalness = p.metalness;
    if (patch.roughness !== undefined) this.threeMaterial.roughness = p.roughness;
    if (patch.wireframe !== undefined) this.threeMaterial.wireframe = p.wireframe;
    if (patch.opacity !== undefined) this.threeMaterial.opacity = p.opacity;
    if (patch.transparent !== undefined) this.threeMaterial.transparent = p.transparent || p.opacity < 1;
    if (patch.doubleSided !== undefined) this.threeMaterial.side = p.doubleSided ? 2 : 0;
    this.threeMaterial.needsUpdate = true;
    this.graph.touch();
    return this;
  }

  setTexture(texture: any, assetId: string | null, url: string | null): GameObject {
    if (!this.threeMaterial || !this.materialParams) return this;
    this.materialParams.textureUrl = url;
    this.materialParams.textureAssetId = assetId;
    this.threeMaterial.map = texture;
    this.threeMaterial.needsUpdate = true;
    this.graph.touch();
    return this;
  }

  applyLightParams(patch: Partial<LightParams>): GameObject {
    if (!this.light || !this.lightParams) return this;
    Object.assign(this.lightParams, patch);
    const p = this.lightParams;
    this.light.color.set(hexToNumber(p.color));
    this.light.intensity = p.intensity;
    this.light.distance = p.distance;
    this.light.castShadow = p.castShadow;
    this.graph.touch();
    return this;
  }

  applyCameraParams(patch: Partial<CameraParams>): GameObject {
    if (!this.camera || !this.cameraParams) return this;
    Object.assign(this.cameraParams, patch);
    this.camera.fov = this.cameraParams.fov;
    this.camera.near = this.cameraParams.near;
    this.camera.far = this.cameraParams.far;
    this.camera.updateProjectionMatrix();
    this.graph.touch();
    return this;
  }

  destroy(): void { this.graph.remove(this.id); }

  instantiate(type: string, position?: any): GameObject {
    return this.graph.engine.createObject(type as ObjectType, undefined, position);
  }

  attachment<T extends GameObject>(): T { return this as unknown as T; }

  serialize(): SerializedObject {
    return {
      id: this.id,
      name: this.name,
      type: this.type,
      parentId: this.parent ? this.parent.id : null,
      position: [this.three.position.x, this.three.position.y, this.three.position.z],
      rotation: [this.three.rotation.x / DEG, this.three.rotation.y / DEG, this.three.rotation.z / DEG],
      scale: [this.three.scale.x, this.three.scale.y, this.three.scale.z],
      visible: this.three.visible,
      material: this.materialParams ? { ...this.materialParams } : undefined,
      light: this.lightParams ? { ...this.lightParams } : undefined,
      camera: this.cameraParams ? { ...this.cameraParams } : undefined,
      physics: { ...this.physics },
      scripts: this.scripts.map((s) => ({
        scriptName: s.scriptName,
        className: s.className,
        fields: JSON.parse(JSON.stringify(s.fields ?? {})),
        enabled: s.enabled,
      })),
      assetId: this.assetId,
      isPlayer: this.isPlayer,
    };
  }
}

/* ---------------------------------------------------------------- SceneGraph */

/** True only when a reference really is a THREE.Object3D-like root (Scene / Group / Object3D). */
export function isSceneRootLike(node: any): boolean {
  return !!node && typeof node.add === 'function' && Array.isArray(node.children);
}

export class SceneGraph {
  roots: GameObject[] = [];
  byId = new Map<string, GameObject>();
  engine: any = null;

  private counter = 1;

  /**
   * The scene root nodes are parented into: the engine's THREE.Scene (an Object3D).
   * NOTE: `three` is the three.js MODULE NAMESPACE (Vector3, Mesh, ...) and has no
   * `.add`/`.remove` — it must never be used as a parent.
   */
  private sceneRoot: any = null;

  constructor(private three: any, sceneRoot?: any) {
    this.sceneRoot = isSceneRootLike(sceneRoot) ? sceneRoot : null;
  }

  /** Late-bind the real scene root, for engines that build their THREE.Scene afterwards. */
  setSceneRoot(root: any): void {
    if (isSceneRootLike(root)) this.sceneRoot = root;
    else this.warn('SceneGraph: ignored an invalid scene root (expected a THREE.Scene/Object3D)');
  }

  private warn(message: string): void {
    try { this.engine?.log?.('warn', message); } catch { /* logging must never throw */ }
  }

  /** The Object3D that root-level nodes hang from — never the three.js namespace. */
  resolveRoot(): any {
    if (isSceneRootLike(this.sceneRoot)) return this.sceneRoot;
    const fallback: any = this.engine?.scene;
    if (isSceneRootLike(fallback)) {
      this.sceneRoot = fallback;
      return fallback;
    }
    return null;
  }

  /**
   * Attach a root-level node to the real scene root.
   *
   * Idempotent — a node that already has a parent is never re-added — and defensive: an
   * invalid or missing root pushes a warning to the engine log instead of throwing, so a
   * bad reference can never kill startup again.
   */
  attachToSceneRoot(obj: GameObject | null | undefined): boolean {
    if (!obj || !obj.three) return false;
    const root = this.resolveRoot();
    if (!root) {
      this.warn(`SceneGraph: no valid scene root for ${obj.name}`);
      return false;
    }
    if (obj.three.parent === root) return true; // already attached
    if (obj.three.parent) return true; // has a parent — never double-add
    try {
      root.add(obj.three);
      return true;
    } catch (err) {
      this.warn(`SceneGraph: no valid scene root for ${obj.name} — ${err instanceof Error ? err.message : String(err)}`);
      return false;
    }
  }


  /** Notify listeners (React panels) that the hierarchy changed. */
  touch(): void {
    this.engine?.onSceneChanged?.();
  }

  uniqueName(base: string): string {
    const all = this.all().map((o) => o.name);
    if (!all.includes(base)) return base;
    let i = 1;
    while (all.includes(`${base} ${i}`)) i++;
    return `${base} ${i}`;
  }

  create(type: ObjectType, name?: string, parent?: GameObject | null): GameObject {
    const id = newId();
    const finalName = this.uniqueName(name || type);
    const def: GameObjectDef = { id, name: finalName, type };
    const three = this.three;

    if (type === 'Light') {
      const light = new three.PointLight(hexToNumber(DEFAULT_LIGHT.color), DEFAULT_LIGHT.intensity, DEFAULT_LIGHT.distance);
      light.castShadow = true;
      light.position.set(0, 6, 0);
      def.object3D = light;
    } else if (type === 'Camera') {
      def.object3D = new three.PerspectiveCamera(DEFAULT_CAMERA.fov, 16 / 9, DEFAULT_CAMERA.near, DEFAULT_CAMERA.far);
    } else if (type === 'Empty') {
      def.object3D = new three.Group();
    } else if (type !== 'Model') {
      def.object3D = new three.Mesh(buildGeometry(three, type), buildStandardMaterial(three, DEFAULT_MATERIAL));
    } else {
      def.object3D = new three.Group();
    }

    const obj = new GameObject(three, this, def);
    obj.three.name = finalName;

    if (type === 'Light') {
      obj.light = def.object3D;
      obj.lightParams = { ...DEFAULT_LIGHT };
    } else if (type === 'Camera') {
      obj.camera = def.object3D;
      obj.cameraParams = { ...DEFAULT_CAMERA };
    } else if (type !== 'Empty' && type !== 'Model') {
      obj.threeMaterial = def.object3D.material;
      obj.materialParams = { ...DEFAULT_MATERIAL };
      obj.three.castShadow = type !== 'Plane';
      obj.three.receiveShadow = true;
    }

    this.byId.set(id, obj);
    this.attach(obj, parent ?? null);
    return obj;
  }

  attach(obj: GameObject, parent: GameObject | null): void {
    if (parent) parent.addChild(obj);
    else {
      obj.parent = null;
      this.roots.push(obj);
    }
    if (!obj.parent) {
      // make sure it is in the scene graph exactly once
      if (!this.roots.includes(obj)) this.roots.push(obj);
      // ...and actually parented into the three.js scene, so nothing that holds a
      // reference to the node (the transform gizmo in particular) ever sees an
      // orphaned Object3D. Idempotent: never double-add an object with a parent.
      this.attachToSceneRoot(obj);
    }
    this.touch();
  }

  /** Move an existing object under a new parent (or to the scene root). */
  reparent(child: GameObject, parent: GameObject | null): void {
    if (parent) {
      let p: GameObject | null = parent;
      while (p) {
        if (p === child) return; // no cycles
        p = p.parent;
      }
    }
    child.detach();
    const idx = this.roots.indexOf(child);
    if (idx >= 0) this.roots.splice(idx, 1);
    if (parent) {
      parent.addChild(child);
    } else {
      child.parent = null;
      this.roots.push(child);
      this.attachToSceneRoot(child);
    }
    this.touch();
  }

  get(id: string): GameObject | undefined { return this.byId.get(id); }

  find(name: string): GameObject | null {
    for (const root of this.roots) {
      const hit = root.find(name);
      if (hit) return hit;
    }
    return null;
  }

  all(): GameObject[] {
    const out: GameObject[] = [];
    for (const root of this.roots) root.traverse((o) => out.push(o));
    return out;
  }

  remove(id: string): GameObject | null {
    const obj = this.byId.get(id);
    if (!obj) return null;

    obj.traverse((child) => {
      this.byId.delete(child.id);
      child.scripts = [];
      if (child.threeMaterial) child.threeMaterial.dispose?.();
      if (child.three?.geometry) child.three.geometry.dispose?.();
    });

    obj.detach();
    const idx = this.roots.indexOf(obj);
    if (idx >= 0) this.roots.splice(idx, 1);
    if (obj.three.parent) obj.three.parent.remove(obj.three);

    this.touch();
    return obj;
  }

  clear(): void {
    for (const root of [...this.roots]) this.remove(root.id);
    this.roots = [];
    this.byId.clear();
  }

  count(): number { return this.byId.size; }

  serializeAll(): SerializedObject[] {
    return this.all().map((o) => o.serialize());
  }
}

/* ------------------------------------------------------- geometry / material */

export function buildGeometry(three: any, type: ObjectType): any {
  switch (type) {
    case 'Sphere': return new three.SphereGeometry(0.5, 40, 24);
    case 'Plane': {
      const g = new three.PlaneGeometry(4, 4);
      g.rotateX(-Math.PI / 2);
      return g;
    }
    case 'Cylinder': return new three.CylinderGeometry(0.5, 0.5, 1, 32);
    case 'Torus': return new three.TorusGeometry(0.4, 0.16, 20, 40);
    case 'Capsule': return new three.CapsuleGeometry(0.35, 0.8, 12, 24);
    case 'Cone': return new three.ConeGeometry(0.5, 1.2, 32);
    case 'Cube':
    default: return new three.BoxGeometry(1, 1, 1);
  }
}

export function buildStandardMaterial(three: any, params: MaterialParams): any {
  const material = new three.MeshStandardMaterial({
    color: hexToNumber(params.color),
    metalness: params.metalness,
    roughness: params.roughness,
    emissive: hexToNumber(params.emissive),
    emissiveIntensity: params.emissiveIntensity,
    wireframe: params.wireframe,
    transparent: params.transparent || params.opacity < 1,
    opacity: params.opacity,
    side: params.doubleSided ? three.DoubleSide : three.FrontSide,
  });
  return material;
}

export function buildLight(three: any, params: LightParams): any {
  const color = hexToNumber(params.color);
  if (params.kind === 'directional') return new three.DirectionalLight(color, params.intensity);
  if (params.kind === 'spot') return new three.SpotLight(color, params.intensity, params.distance, Math.PI / 5);
  return new three.PointLight(color, params.intensity, params.distance);
}
