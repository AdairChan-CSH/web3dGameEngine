/**
 * External control bridge.
 *
 *  1. ExternalBridge — listens for window.postMessage commands so the editor can
 *     be embedded in an iframe and driven by a parent page (or by any script on
 *     the same page). Requests:
 *        { target: "engine", id: 7, method: "setPosition", args: [id, 1, 2, 3] }
 *     Replies are posted back to the caller as:
 *        { target: "parent", id: 7, ok: true, result: ... , engine: "webforge" }
 *
 *  2. RemoteControl — connects the engine to an external command server, either
 *     over a real WebSocket, over HTTP polling, or against a built-in MOCK
 *     server so the whole flow can be demonstrated with no backend at all.
 *
 * Both go through the same `BridgeTarget.execute()` dispatcher, which is the
 * same API surface exposed as window.Engine.
 */

import type { RemoteLogEntry, RemoteStatus } from './types';

export interface BridgeResult { ok: boolean; result?: any; error?: string }

export interface BridgeTarget {
  execute(method: string, args: any[]): BridgeResult;
  log(level: 'log' | 'info' | 'warn' | 'error', message: string): void;
}

export const HANDSHAKE = {
  type: 'handshake',
  engine: 'webforge',
  version: 1,
  transport: 'json-commands',
} as const;

/* ------------------------------------------------------------- postMessage */

export class ExternalBridge {
  private target: BridgeTarget;
  private handler: (event: MessageEvent) => void;
  private running = false;
  private trustAllOrigins = true;
  private allowedOrigins: string[] = [];
  handled = 0;

  constructor(target: BridgeTarget) {
    this.target = target;
    this.handler = (event: MessageEvent) => this.onMessage(event);
  }

  start(allowedOrigins?: string[]): void {
    if (this.running) return;
    if (allowedOrigins && allowedOrigins.length) {
      this.allowedOrigins = allowedOrigins;
      this.trustAllOrigins = false;
    }
    window.addEventListener('message', this.handler);
    this.running = true;
  }

  stop(): void {
    if (!this.running) return;
    window.removeEventListener('message', this.handler);
    this.running = false;
  }

  private onMessage(event: MessageEvent): void {
    const data: any = event.data;
    if (!data || typeof data !== 'object') return;
    if (data.target !== 'engine' && data.type !== 'engine-command') return;
    if (typeof data.method !== 'string') return;
    if (!this.trustAllOrigins) {
      const origin = event.origin || '';
      if (!this.allowedOrigins.includes(origin) && origin !== window.location.origin) return;
    }

    const args: any[] = Array.isArray(data.args) ? data.args : [];
    const outcome = this.target.execute(data.method, args);
    this.handled++;

    // reply to whoever asked (parent frame, opener, or the same window)
    const reply = {
      target: 'parent',
      engine: HANDSHAKE.engine,
      id: data.id ?? null,
      method: data.method,
      ok: outcome.ok,
      result: outcome.ok ? outcome.result : undefined,
      error: outcome.ok ? undefined : outcome.error,
      at: Date.now(),
    };

    const ports: Array<Window | null> = [event.source as Window | null, window.parent, window.opener as Window | null];
    for (const port of ports) {
      if (!port || port === window) continue;
      try {
        port.postMessage(reply, '*');
      } catch {
        /* cross-origin or detached frame — ignore */
      }
    }
    if (data.replyInWindow || (!event.source && event.origin === window.location.origin)) {
      try { window.postMessage(reply, '*'); } catch { /* ignore */ }
    }
  }
}

/* ---------------------------------------------------------- remote control */

interface MockCommand { method: string; args: any[] }

const MOCK_SERVER_COMMANDS: MockCommand[] = [
  { method: 'listObjects', args: [] },
  { method: 'setColor', args: ['<selected>', '#66e0ff'] },
  { method: 'move', args: ['<selected>', 0, 1, 0] },
  { method: 'emitEvent', args: ['server_ping', { from: 'mock-server', tick: 'n' }] },
  { method: 'animate', args: ['<selected>', { rotation: [0, 360, 0], duration: 2, loop: true }] },
  { method: 'getStats', args: [] },
];

export class RemoteControl {
  private target: BridgeTarget;
  private notify: () => void;
  private ws: WebSocket | null = null;
  private timers: number[] = [];
  private pollTimer: number | null = null;
  private mockStep = 0;
  private seq = 0;

  status: RemoteStatus = { mode: 'mock', status: 'disconnected', url: '', detail: 'Idle' };
  log: RemoteLogEntry[] = [];
  private logId = 1;

  constructor(target: BridgeTarget, notify: () => void) {
    this.target = target;
    this.notify = notify;
  }

  setMode(mode: RemoteStatus['mode']): void {
    if (this.status.status !== 'disconnected') this.disconnect();
    this.status = { ...this.status, mode, detail: `Mode: ${mode}` };
    this.pushLog('status', `Transport set to ${mode}`);
    this.notify();
  }

  setUrl(url: string): void {
    this.status = { ...this.status, url };
    this.notify();
  }

  connect(url?: string): void {
    if (url !== undefined) this.status = { ...this.status, url };
    this.disconnect(true);
    const mode = this.status.mode;
    this.status = { ...this.status, status: 'connecting', detail: `Connecting (${mode})…` };
    this.pushLog('status', `Connecting via ${mode}${this.status.url ? ' → ' + this.status.url : ''}`);
    this.notify();

    if (mode === 'websocket') this.connectWebSocket();
    else if (mode === 'poll') this.connectPoll();
    else this.connectMock();
  }

  disconnect(silent = false): void {
    for (const t of this.timers) window.clearTimeout(t);
    this.timers = [];
    if (this.pollTimer !== null) { window.clearInterval(this.pollTimer); this.pollTimer = null; }
    if (this.ws) {
      try { this.ws.close(); } catch { /* ignore */ }
      this.ws = null;
    }
    if (!silent && this.status.status !== 'disconnected') {
      this.pushLog('status', 'Disconnected');
    }
    this.status = { ...this.status, status: 'disconnected', detail: 'Disconnected' };
    this.notify();
  }

  dispose(): void { this.disconnect(true); }

  getStatus(): RemoteStatus { return this.status; }
  getLog(): RemoteLogEntry[] { return this.log; }

  clearLog(): void { this.log = []; this.notify(); }

  /** Send an arbitrary packet to the connected server (used by the UI too). */
  send(packet: any): void {
    const text = JSON.stringify(packet);
    if (this.status.mode === 'websocket' && this.ws && this.ws.readyState === 1) {
      try { this.ws.send(text); } catch { /* ignore */ }
      this.pushLog('out', text);
      return;
    }
    if (this.status.mode === 'poll' && this.status.url) {
      void this.postJson(this.status.url, packet).then((reply) => {
        this.pushLog('out', text);
        if (reply) this.pushLog('in', JSON.stringify(reply));
      });
      return;
    }
    this.pushLog('out', text + '  (mock: not transmitted)');
  }

  /** Run an inbound command and reply, writing both sides to the log. */
  private handleInbound(packet: any): void {
    if (!packet || typeof packet !== 'object') return;
    this.pushLog('in', JSON.stringify(packet));

    if (packet.type === 'handshake-ack' || packet.type === 'welcome') {
      this.status = { ...this.status, status: 'connected', detail: packet.message || 'Server acknowledged handshake' };
      this.notify();
      return;
    }

    const method = String(packet.method ?? packet.cmd ?? '');
    if (!method) return;
    const args = Array.isArray(packet.args) ? this.resolveArgs(packet.args) : [];
    const outcome = this.target.execute(method, args);
    this.pushLog('out', JSON.stringify({ id: packet.id ?? null, ok: outcome.ok, result: outcome.result ?? outcome.error }));
  }

  /** "<selected>" in a remote packet means "whatever is selected in the editor". */
  private resolveArgs(args: any[]): any[] {
    return args.map((a) => (a === '<selected>' ? this.selectedProvider?.() ?? '<selected>' : a));
  }

  selectedProvider: (() => string | null) | null = null;

  private pushLog(direction: RemoteLogEntry['direction'], text: string): void {
    this.log = [...this.log.slice(-160), { id: this.logId++, direction, text, time: Date.now() }];
    this.notify();
  }

  /* ------------------------------------------------------------- transports */

  private connectMock(): void {
    const timers: number[] = [];
    timers.push(window.setTimeout(() => {
      this.status = { ...this.status, status: 'connected', detail: 'Mock server connected (no backend required)' };
      this.pushLog('in', JSON.stringify({ type: 'welcome', message: 'mock server ready' }));
      this.notify();
    }, 400));

    // stream a rotating set of realistic commands so the panels come alive
    timers.push(window.setTimeout(() => this.startMockStream(), 1200));
    this.timers = timers;
  }

  private startMockStream(): void {
    const send = () => {
      if (this.status.status !== 'connected' || this.status.mode !== 'mock') return;
      const template = MOCK_SERVER_COMMANDS[this.mockStep % MOCK_SERVER_COMMANDS.length];
      this.mockStep++;
      const packet = {
        type: 'command',
        id: ++this.seq,
        method: template.method,
        args: template.args.map((a) => (typeof a === 'string' && a.startsWith('tick:') ? this.seq : a)),
      };
      this.handleInbound(packet);
      const t = window.setTimeout(send, 2600);
      this.timers.push(t);
    };
    send();
  }

  private connectWebSocket(): void {
    const url = this.status.url.trim();
    if (!url) {
      this.status = { ...this.status, status: 'error', detail: 'Enter a WebSocket URL first (ws:// or wss://)' };
      this.pushLog('status', 'No URL provided');
      this.notify();
      return;
    }
    let socket: WebSocket;
    try {
      socket = new WebSocket(url);
    } catch (err) {
      this.status = { ...this.status, status: 'error', detail: 'Invalid WebSocket URL' };
      this.pushLog('status', String(err));
      this.notify();
      return;
    }
    this.ws = socket;

    socket.onopen = () => {
      this.status = { ...this.status, status: 'connected', detail: `WebSocket connected to ${url}` };
      this.pushLog('status', `socket open → ${url}`);
      this.pushLog('out', JSON.stringify(HANDSHAKE));
      socket.send(JSON.stringify(HANDSHAKE));
      this.notify();
    };
    socket.onmessage = (event) => {
      try {
        const parsed = JSON.parse(String(event.data));
        if (Array.isArray(parsed)) parsed.forEach((p) => this.handleInbound(p));
        else this.handleInbound(parsed);
      } catch {
        this.pushLog('in', String(event.data));
      }
    };
    socket.onerror = () => {
      this.status = { ...this.status, status: 'error', detail: 'WebSocket error — is the server running?' };
      this.pushLog('status', 'socket error');
      this.notify();
    };
    socket.onclose = () => {
      if (this.status.status === 'connected') this.pushLog('status', 'socket closed');
      this.status = { ...this.status, status: 'disconnected', detail: 'Socket closed' };
      this.notify();
    };
  }

  private connectPoll(): void {
    const url = this.status.url.trim();
    if (!url) {
      this.status = { ...this.status, status: 'error', detail: 'Enter an HTTP endpoint URL first (https://…)' };
      this.pushLog('status', 'No URL provided');
      this.notify();
      return;
    }
    this.status = { ...this.status, status: 'connected', detail: `Polling ${url} every 2s` };
    this.pushLog('status', `poll loop started → ${url}`);
    this.notify();

    const loop = async () => {
      const reply = await this.postJson(url, {
        engine: HANDSHAKE.engine,
        type: 'command-poll',
        status: 'online',
        objects: this.target.execute('listObjects', []).result,
      });
      if (reply) {
        const commands = Array.isArray(reply) ? reply : Array.isArray(reply.commands) ? reply.commands : [reply];
        for (const cmd of commands) {
          if (cmd && (cmd.method || cmd.cmd)) this.handleInbound(cmd);
        }
      }
    };

    void loop();
    this.pollTimer = window.setInterval(loop, 2000);
  }

  private async postJson(url: string, body: any): Promise<any> {
    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      this.pushLog('out', JSON.stringify(body));
      if (!res.ok) {
        this.pushLog('status', `HTTP ${res.status} from ${url}`);
        return null;
      }
      const text = await res.text();
      if (!text) return null;
      try { return JSON.parse(text); } catch { return { raw: text }; }
    } catch (err) {
      this.status = { ...this.status, status: 'error', detail: 'Request failed (CORS or server offline)' };
      this.pushLog('status', `request failed: ${err instanceof Error ? err.message : String(err)}`);
      this.notify();
      return null;
    }
  }
}
