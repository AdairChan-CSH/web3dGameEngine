/**
 * Three.js loader.
 *
 * The engine has no build-time dependency on three: it is pulled from a CDN at
 * runtime (as required by the workspace brief: "no build step, Three.js from a
 * CDN").  index.html ships an import map for the bare specifiers, and we keep a
 * full-URL CDN fallback in case the map is unavailable.
 *
 * Nothing else in the engine imports 'three' directly — everything receives the
 * loaded bundle, which keeps the whole engine swappable and tree-shakeable.
 */

export interface ThreeBundle {
  version: string;
  THREE: any;
  OrbitControls: any;
  TransformControls: any;
  GLTFLoader: any;
  OBJLoader: any;
  MTLLoader: any;
  GLTFExporter: any;
  RoomEnvironment: any | null;
  source: 'unpkg' | 'esm.sh';
}

const VERSION = '0.160.0';
const UNPKG = `https://unpkg.com/three@${VERSION}`;
const ESM = `https://esm.sh/three@${VERSION}`;

const ADDON_PATHS = {
  OrbitControls: 'controls/OrbitControls.js',
  TransformControls: 'controls/TransformControls.js',
  GLTFLoader: 'loaders/GLTFLoader.js',
  OBJLoader: 'loaders/OBJLoader.js',
  MTLLoader: 'loaders/MTLLoader.js',
  GLTFExporter: 'exporters/GLTFExporter.js',
  RoomEnvironment: 'environments/RoomEnvironment.js',
} as const;

/** Runtime dynamic import: the variable specifier keeps Vite from bundling it. */
async function dynImport(spec: string): Promise<any> {
  return await import(/* @vite-ignore */ spec);
}

async function tryImport(primary: string, fallback: string): Promise<any> {
  try {
    return await dynImport(primary);
  } catch (err) {
    // eslint-disable-next-line no-console
    console.warn('[engine] CDN import failed, trying fallback:', primary, err);
    return await dynImport(fallback);
  }
}

/**
 * `import('…/OrbitControls.js')` resolves to a MODULE NAMESPACE object
 * (`{ OrbitControls: class }`, and on some CDNs also a `default`) — never the
 * class itself. Consumers do `new bundle.OrbitControls(...)`, so every addon
 * must be unwrapped to its real export ONCE here, or `new` throws
 * "… is not a constructor" the first time it is used.
 */
function unwrapAddon(mod: any, exportName: string): any {
  if (mod == null) return mod;
  // Some CDNs hand back the class (or a function) directly.
  if (typeof mod === 'function') return mod;
  // The named export we expect, e.g. mod.OrbitControls.
  const named = mod[exportName];
  if (typeof named === 'function') return named;
  // A `default` that IS the class, or that carries it (double-wrapped).
  if (typeof mod.default === 'function') return mod.default;
  if (mod.default && typeof mod.default[exportName] === 'function') return mod.default[exportName];
  // Last resort: the first exported function (every addon here is a class).
  for (const key of Object.keys(mod)) {
    if (typeof mod[key] === 'function') return mod[key];
  }
  return mod.default ?? mod;
}

let cached: ThreeBundle | null = null;
let pending: Promise<ThreeBundle> | null = null;

/**
 * Loads three + the addons once and memoizes the result.
 * Tries the import-map bare specifiers first, then explicit CDN URLs.
 */
export function loadThree(): Promise<ThreeBundle> {
  if (cached) return Promise.resolve(cached);
  if (pending) return pending;

  pending = (async () => {
    let base = UNPKG;
    let source: ThreeBundle['source'] = 'unpkg';
    let THREE: any;

    try {
      THREE = await tryImport('three', `${UNPKG}/build/three.module.js`);
    } catch (err) {
      base = ESM;
      source = 'esm.sh';
      THREE = await dynImport(`${ESM}`);
      if (THREE && THREE.default && !THREE.Scene) THREE = THREE.default;
    }

    const addon = async (key: keyof typeof ADDON_PATHS): Promise<any> => {
      const path = ADDON_PATHS[key];
      if (source === 'unpkg') {
        return await tryImport(`three/addons/${path}`, `${UNPKG}/examples/jsm/${path}?module`);
      }
      return await dynImport(`${ESM}/examples/jsm/${path}`);
    };

    const [orbitMod, transformMod, gltfLoaderMod, objLoaderMod, mtlLoaderMod, gltfExporterMod] =
      await Promise.all([
        addon('OrbitControls'),
        addon('TransformControls'),
        addon('GLTFLoader'),
        addon('OBJLoader'),
        addon('MTLLoader'),
        addon('GLTFExporter'),
      ]);

    // Unwrap each module namespace object to its real constructor.
    const OrbitControls = unwrapAddon(orbitMod, 'OrbitControls');
    const TransformControls = unwrapAddon(transformMod, 'TransformControls');
    const GLTFLoader = unwrapAddon(gltfLoaderMod, 'GLTFLoader');
    const OBJLoader = unwrapAddon(objLoaderMod, 'OBJLoader');
    const MTLLoader = unwrapAddon(mtlLoaderMod, 'MTLLoader');
    const GLTFExporter = unwrapAddon(gltfExporterMod, 'GLTFExporter');

    let RoomEnvironment: any = null;
    try {
      RoomEnvironment = unwrapAddon(await addon('RoomEnvironment'), 'RoomEnvironment');
    } catch {
      RoomEnvironment = null; // purely cosmetic (studio reflections)
    }

    cached = {
      version: VERSION,
      THREE,
      OrbitControls,
      TransformControls,
      GLTFLoader,
      OBJLoader,
      MTLLoader,
      GLTFExporter,
      RoomEnvironment,
      source,
    };
    return cached;
  })();

  return pending;
}

export function getThree(): any {
  if (!cached) throw new Error('Three.js is still loading.');
  return cached.THREE;
}

export function threeReady(): boolean {
  return cached !== null;
}

export function threeSource(): string {
  return cached ? `${cached.source} (r${cached.version})` : 'loading…';
}
