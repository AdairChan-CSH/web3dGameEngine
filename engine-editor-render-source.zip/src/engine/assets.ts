/**
 * IndexedDB asset store.
 *
 * Imported models and textures can be far larger than the localStorage quota,
 * so their bytes live here (keyed by asset id) while the project JSON only
 * stores the id. That way save/load round-trips keep imported assets.
 */

export interface StoredAsset {
  id: string;
  name: string;
  kind: 'model' | 'texture';
  ext: string;
  mime: string;
  size: number;
  created: number;
  data: ArrayBuffer;
}

const DB_NAME = 'webforge-assets';
const STORE = 'assets';

function openDb(): Promise<any> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('This browser has no IndexedDB, so imported models cannot be stored.'));
      return;
    }
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE, { keyPath: 'id' });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error('Could not open the asset database'));
  });
}

export async function putAsset(asset: StoredAsset): Promise<void> {
  const db = await openDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).put(asset);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
  db.close();
}

export async function getAsset(id: string): Promise<StoredAsset | null> {
  const db = await openDb();
  const out = await new Promise<StoredAsset | null>((resolve, reject) => {
    const tx = db.transaction(STORE, 'readonly');
    const req = tx.objectStore(STORE).get(id);
    req.onsuccess = () => resolve((req.result as StoredAsset) ?? null);
    req.onerror = () => reject(req.error);
  });
  db.close();
  return out;
}

export async function listAssets(): Promise<Array<Omit<StoredAsset, 'data'>>> {
  const db = await openDb();
  const out = await new Promise<StoredAsset[]>((resolve, reject) => {
    const tx = db.transaction(STORE, 'readonly');
    const req = tx.objectStore(STORE).getAll();
    req.onsuccess = () => resolve((req.result as StoredAsset[]) ?? []);
    req.onerror = () => reject(req.error);
  });
  db.close();
  return out.map(({ data: _data, ...rest }) => rest);
}

export async function deleteAsset(id: string): Promise<void> {
  const db = await openDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
  db.close();
}

export function assetId(prefix = 'asset'): string {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

export function isIndexedDbAvailable(): boolean {
  return typeof indexedDB !== 'undefined';
}
