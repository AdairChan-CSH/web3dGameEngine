/**
 * React ⇄ engine glue.
 *
 * The engine is a plain imperative object; React reads it through
 * useSyncExternalStore so panels re-render only when the engine says something
 * changed (scene edits, console output, stats, remote bridge traffic).
 */

import { createContext, useContext, useEffect, useState, useSyncExternalStore, type ReactNode } from 'react';
import type { EngineCore } from './core';

const EngineContext = createContext<EngineCore | null>(null);

export function EngineProvider({ core, children }: { core: EngineCore; children: ReactNode }) {
  return <EngineContext.Provider value={core}>{children}</EngineContext.Provider>;
}

/** The engine instance itself (methods, graph, logs…). */
export function useEngine(): EngineCore {
  const core = useContext(EngineContext);
  if (!core) throw new Error('<EngineProvider> is missing — the editor cannot reach the engine.');
  return core;
}

/** Bumps whenever the scene / selection / console changes. */
export function useEngineVersion(): number {
  const core = useEngine();
  return useSyncExternalStore(
    (cb) => core.subscribe('change', cb),
    () => core.version,
    () => 0,
  );
}

/** Bumps a few times a second with fresh renderer statistics. */
export function useEngineStats() {
  const core = useEngine();
  useSyncExternalStore(
    (cb) => core.subscribe('stats', cb),
    () => core.statsVersion,
    () => 0,
  );
  return core.stats;
}

/** Bumps whenever the remote-control panel has new traffic. */
export function useRemoteTick(): number {
  const core = useEngine();
  return useSyncExternalStore(
    (cb) => core.subscribe('remote', cb),
    () => core.remoteVersion,
    () => 0,
  );
}

/** True on narrow screens — panels become drawers. */
export function useIsCompact(breakpoint = 1024): boolean {
  const query = `(max-width: ${breakpoint - 1}px)`;
  const [compact, setCompact] = useState(() =>
    typeof window !== 'undefined' ? window.matchMedia(query).matches : false,
  );
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const mq = window.matchMedia(query);
    const handler = () => setCompact(mq.matches);
    handler();
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, [query]);
  return compact;
}

/** Simple debounce for text inputs that compile/validate as you type. */
export function useDebounced<T>(value: T, delay = 400): T {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const timer = window.setTimeout(() => setDebounced(value), delay);
    return () => window.clearTimeout(timer);
  }, [value, delay]);
  return debounced;
}
