/**
 * The WebForge scripting VM.
 *
 * A small C#/Java/Unity-JavaScript flavoured language, implemented from scratch:
 *
 *    tokenizer  ->  parser (AST)  ->  tree-walking interpreter
 *
 * HARD RULE: user script text is NEVER passed to eval() or new Function().
 * The interpreter below decides what every construct means, which also makes the
 * sandbox safe: scripts can only reach the host API we explicitly hand them.
 *
 * Supported syntax
 *   class Foo extends Component { ... }
 *   public float speed = 5.0;  public string tag = "hero";
 *   public Vector3 dir = new Vector3(0,0,1);  public bool on = true;
 *   void Start() {}   void Update(float dt) {}   void FixedUpdate(float dt) {}
 *   void OnCollision(Collision other) {}   void OnKeyDown(string key) {}
 *   float Help(float a, float b) { return a + b; }
 *   let/var/typed locals, assignment (+=, ++, ...), if/else if/else, while,
 *   for(init; cond; update), break/continue, return,
 *   full expression grammar with && || ! == != < > <= >= + - * / % and calls,
 *   member access on host objects (this.transform.position.x = 1;),
 *   array literals + indexing, new Vector3(...) / new Quaternion().
 */

import type { FieldSpec, ScriptInstance } from './types';

/* ------------------------------------------------------------------ errors */

export class ScriptError extends Error {
  line: number;
  scriptName: string;
  constructor(message: string, line: number, scriptName: string) {
    super(message);
    this.name = 'ScriptError';
    this.line = line;
    this.scriptName = scriptName;
  }
}

/* ---------------------------------------------------------------- tokenizer */

type TokenType = 'num' | 'str' | 'ident' | 'kw' | 'op' | 'punc' | 'eof';

interface Token {
  type: TokenType;
  value: string;
  line: number;
  num?: number;
}

const KEYWORDS = new Set([
  'class', 'extends', 'implements', 'public', 'private', 'protected', 'static', 'final',
  'void', 'int', 'float', 'double', 'string', 'bool', 'boolean', 'var', 'let', 'const',
  'if', 'else', 'while', 'for', 'return', 'new', 'true', 'false', 'null', 'this',
  'break', 'continue', 'function', 'override', 'virtual', 'in',
]);

const OPERATORS = [
  '&&', '||', '==', '!=', '<=', '>=', '+=', '-=', '*=', '/=', '++', '--',
  '+', '-', '*', '/', '%', '<', '>', '!', '=',
];

const PUNCT = ['(', ')', '{', '}', '[', ']', ';', ',', '.'];

function tokenize(source: string, scriptName: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;
  let line = 1;
  const n = source.length;

  const isDigit = (c: string) => c >= '0' && c <= '9';
  const isIdentStart = (c: string) => /[A-Za-z_$]/.test(c);
  const isIdentPart = (c: string) => /[A-Za-z0-9_$]/.test(c);

  while (i < n) {
    const c = source[i];

    if (c === '\n') { line++; i++; continue; }
    if (c === ' ' || c === '\t' || c === '\r') { i++; continue; }

    // comments
    if (c === '/' && source[i + 1] === '/') {
      while (i < n && source[i] !== '\n') i++;
      continue;
    }
    if (c === '/' && source[i + 1] === '*') {
      i += 2;
      while (i < n && !(source[i] === '*' && source[i + 1] === '/')) {
        if (source[i] === '\n') line++;
        i++;
      }
      i += 2;
      continue;
    }

    // numbers
    if (isDigit(c) || (c === '.' && isDigit(source[i + 1]))) {
      let start = i;
      while (i < n && (isDigit(source[i]) || source[i] === '.')) i++;
      if (source[i] === 'f' || source[i] === 'F' || source[i] === 'd') i++;
      const raw = source.slice(start, i);
      const value = parseFloat(raw);
      if (Number.isNaN(value)) throw new ScriptError(`Invalid number literal '${raw}'`, line, scriptName);
      tokens.push({ type: 'num', value: raw, num: value, line });
      continue;
    }

    // strings
    if (c === '"' || c === "'") {
      const quote = c;
      i++;
      let out = '';
      let closed = false;
      while (i < n) {
        const ch = source[i];
        if (ch === '\\') {
          const next = source[i + 1];
          if (next === 'n') out += '\n';
          else if (next === 't') out += '\t';
          else if (next === 'r') out += '\r';
          else out += next;
          i += 2;
          continue;
        }
        if (ch === quote) { closed = true; i++; break; }
        if (ch === '\n') break;
        out += ch;
        i++;
      }
      if (!closed) throw new ScriptError('Unterminated string literal', line, scriptName);
      tokens.push({ type: 'str', value: out, line });
      continue;
    }

    // identifiers / keywords
    if (isIdentStart(c)) {
      let start = i;
      while (i < n && isIdentPart(source[i])) i++;
      const word = source.slice(start, i);
      tokens.push({ type: KEYWORDS.has(word) ? 'kw' : 'ident', value: word, line });
      continue;
    }

    // operators (longest first)
    let matched = false;
    for (const op of OPERATORS) {
      if (source.startsWith(op, i)) {
        tokens.push({ type: 'op', value: op, line });
        i += op.length;
        matched = true;
        break;
      }
    }
    if (matched) continue;

    if (PUNCT.includes(c)) {
      tokens.push({ type: 'punc', value: c, line });
      i++;
      continue;
    }

    throw new ScriptError(`Unexpected character '${c}'`, line, scriptName);
  }

  tokens.push({ type: 'eof', value: '<eof>', line });
  return tokens;
}

/* ---------------------------------------------------------------------- AST */

interface Node { type: string; line: number }

interface ClassDecl extends Node {
  name: string;
  base: string;
  fields: FieldDecl[];
  methods: MethodDecl[];
}

interface FieldDecl extends Node {
  name: string;
  declType: string;
  init: any | null;
  isPublic: boolean;
}

interface MethodDecl extends Node {
  name: string;
  params: string[];
  body: any; // Block
  declType: string;
}

/* ------------------------------------------------------------------- parser */

class Parser {
  private toks: Token[];
  private pos = 0;
  private scriptName: string;

  constructor(tokens: Token[], scriptName: string) {
    this.toks = tokens;
    this.scriptName = scriptName;
  }

  private peek(offset = 0): Token { return this.toks[Math.min(this.pos + offset, this.toks.length - 1)]; }
  private next(): Token { return this.toks[this.pos++]; }
  private at(value: string, offset = 0): boolean { return this.peek(offset).value === value; }
  private atType(type: TokenType, offset = 0): boolean { return this.peek(offset).type === type; }
  private fail(message: string, line?: number): never {
    throw new ScriptError(message, line ?? this.peek().line, this.scriptName);
  }
  private expect(value: string): Token {
    if (!this.at(value)) this.fail(`Expected '${value}' but found '${this.peek().value}'`);
    return this.next();
  }
  private expectIdent(what = 'identifier'): Token {
    if (!this.atType('ident')) this.fail(`Expected ${what} but found '${this.peek().value}'`);
    return this.next();
  }
  private acceptSemi(): void { if (this.at(';')) this.next(); }

  private isTypeKeyword(tok: Token): boolean {
    return tok.type === 'kw' && ['void', 'int', 'float', 'double', 'string', 'bool', 'boolean', 'var', 'let', 'const'].includes(tok.value);
  }

  /* ------------------------------------------------------------ top level */

  parseProgram(): ClassDecl[] {
    const classes: ClassDecl[] = [];
    while (!this.atType('eof')) {
      if (this.at('class')) classes.push(this.parseClass());
      else this.fail(`Expected 'class' declaration but found '${this.peek().value}'`);
    }
    if (!classes.length) this.fail('No class found. A script must declare exactly one class.');
    return classes;
  }

  private parseClass(): ClassDecl {
    const line = this.next().line; // 'class'
    const name = this.expectIdent('class name').value;
    let base = 'Component';
    if (this.at('extends')) {
      this.next();
      base = this.expectIdent('base class name').value;
    }
    this.expect('{');
    const fields: FieldDecl[] = [];
    const methods: MethodDecl[] = [];
    while (!this.at('}')) {
      if (this.atType('eof')) this.fail(`Unclosed class body for '${name}'`, line);
      const member = this.parseMember();
      if (member.kind === 'field') fields.push(member.field);
      else methods.push(member.method);
    }
    this.expect('}');
    return { type: 'ClassDecl', name, base, fields, methods, line };
  }

  private parseMember(): { kind: 'field'; field: FieldDecl } | { kind: 'method'; method: MethodDecl } {
    const line = this.peek().line;
    let isPublic = true;
    while (this.at('public') || this.at('private') || this.at('protected') || this.at('static') || this.at('override') || this.at('virtual') || this.at('final')) {
      if (this.at('private') || this.at('protected')) isPublic = false;
      this.next();
    }
    if (this.at('function')) this.next();

    let declType = '';
    if (this.isTypeKeyword(this.peek())) {
      declType = this.next().value;
    } else if (this.atType('ident') && this.atType('ident', 1)) {
      declType = this.next().value; // explicit custom type: Vector3 dir = ...
    }

    // a member with no type at all: "spawn()" or "static Foo()"
    if (!declType && this.atType('ident') && this.at('(', 1)) {
      const name = this.next().value;
      return { kind: 'method', method: this.parseMethodRest(name, '', line) };
    }

    const nameTok = this.expectIdent('member name');
    if (this.at('(')) {
      return { kind: 'method', method: this.parseMethodRest(nameTok.value, declType, line) };
    }

    // field declaration
    let init: any = null;
    if (this.at('=')) {
      this.next();
      init = this.parseExpression();
    }
    this.acceptSemi();
    return {
      kind: 'field',
      field: { type: 'FieldDecl', name: nameTok.value, declType: declType || 'var', init, isPublic, line },
    };
  }

  private parseMethodRest(name: string, declType: string, line: number): MethodDecl {
    this.expect('(');
    const params: string[] = [];
    while (!this.at(')')) {
      // "float dt", "Vector3 v", "key"
      if (this.isTypeKeyword(this.peek())) this.next();
      else if (this.atType('ident') && (this.atType('ident', 1) || this.at('[', 1))) this.next();
      const p = this.expectIdent('parameter name');
      params.push(p.value);
      if (this.at(',')) this.next();
      else break;
    }
    this.expect(')');
    const body = this.parseBlock();
    return { type: 'MethodDecl', name, params, body, declType, line };
  }

  /* ------------------------------------------------------------ statements */

  private parseBlock(): any {
    const line = this.expect('{').line;
    const body: any[] = [];
    while (!this.at('}')) {
      if (this.atType('eof')) this.fail('Unexpected end of script — missing }', line);
      body.push(this.parseStatement());
    }
    this.expect('}');
    return { type: 'Block', body, line };
  }

  private looksLikeDeclaration(): boolean {
    const t = this.peek();
    if (this.isTypeKeyword(t)) return true;
    if (t.type === 'ident' && this.atType('ident', 1)) return true;                 // Vector3 dir
    if (t.type === 'ident' && this.at('[', 1) && this.at(']', 2) && this.atType('ident', 3)) return true; // float[] xs
    return false;
  }

  private parseDeclaration(): any {
    const line = this.peek().line;
    this.next(); // type
    if (this.at('[')) { this.next(); this.expect(']'); }
    const name = this.expectIdent('variable name').value;
    let init: any = null;
    if (this.at('=')) { this.next(); init = this.parseExpression(); }
    this.acceptSemi();
    return { type: 'VarDecl', name, init, line };
  }

  private parseStatement(): any {
    const tok = this.peek();
    if (this.at('{')) return this.parseBlock();
    if (this.at('if')) return this.parseIf();
    if (this.at('while')) return this.parseWhile();
    if (this.at('for')) return this.parseFor();
    if (this.at('return')) {
      const line = this.next().line;
      let value: any = null;
      if (!this.at(';') && !this.at('}')) value = this.parseExpression();
      this.acceptSemi();
      return { type: 'Return', value, line };
    }
    if (this.at('break')) { const line = this.next().line; this.acceptSemi(); return { type: 'Break', line }; }
    if (this.at('continue')) { const line = this.next().line; this.acceptSemi(); return { type: 'Continue', line }; }
    if (this.at('class')) this.fail('Nested classes are not supported');
    if (this.looksLikeDeclaration()) return this.parseDeclaration();

    const expr = this.parseExpression();
    this.acceptSemi();
    return { type: 'ExprStmt', expr, line: tok.line };
  }

  private parseIf(): any {
    const line = this.next().line;
    this.expect('(');
    const cond = this.parseExpression();
    this.expect(')');
    const then = this.parseStatement();
    let alt: any = null;
    if (this.at('else')) {
      this.next();
      alt = this.at('if') ? this.parseIf() : this.parseStatement();
    }
    return { type: 'If', cond, then, alt, line };
  }

  private parseWhile(): any {
    const line = this.next().line;
    this.expect('(');
    const cond = this.parseExpression();
    this.expect(')');
    const body = this.parseStatement();
    return { type: 'While', cond, body, line };
  }

  private parseFor(): any {
    const line = this.next().line;
    this.expect('(');
    let init: any = null;
    if (!this.at(';')) init = this.looksLikeDeclaration() ? this.parseDeclaration() : this.parseForClause();
    else this.next();
    const cond = this.at(';') ? null : this.parseExpression();
    this.expect(';');
    let update: any = this.at(')') ? null : this.parseForClause();
    this.expect(')');
    const body = this.parseStatement();
    return { type: 'For', init, cond, update, body, line };
  }

  /** for-clause: `i = i + 1`, `i++`, or a plain expression. */
  private parseForClause(): any {
    const line = this.peek().line;
    const expr = this.parseExpression();
    this.acceptSemi();
    return { type: 'ExprStmt', expr, line };
  }

  /* ----------------------------------------------------------- expressions */

  parseExpression(): any { return this.parseAssignment(); }

  private isAssignable(node: any): boolean {
    return node && (node.type === 'Ident' || node.type === 'Member' || node.type === 'Index');
  }

  private parseAssignment(): any {
    const left = this.parseOr();
    const t = this.peek();
    if (t.type === 'op' && ['=', '+=', '-=', '*=', '/='].includes(t.value) && this.isAssignable(left)) {
      this.next();
      const value = this.parseAssignment();
      return { type: 'Assign', target: left, op: t.value, value, line: t.line };
    }
    return left;
  }

  private parseOr(): any {
    let left = this.parseAnd();
    while (this.at('||')) {
      const line = this.next().line;
      left = { type: 'Logical', op: '||', left, right: this.parseAnd(), line };
    }
    return left;
  }

  private parseAnd(): any {
    let left = this.parseEquality();
    while (this.at('&&')) {
      const line = this.next().line;
      left = { type: 'Logical', op: '&&', left, right: this.parseEquality(), line };
    }
    return left;
  }

  private parseEquality(): any {
    let left = this.parseRelational();
    while (this.at('==') || this.at('!=')) {
      const op = this.next();
      left = { type: 'Binary', op: op.value, left, right: this.parseRelational(), line: op.line };
    }
    return left;
  }

  private parseRelational(): any {
    let left = this.parseAdditive();
    while (this.at('<') || this.at('>') || this.at('<=') || this.at('>=')) {
      const op = this.next();
      left = { type: 'Binary', op: op.value, left, right: this.parseAdditive(), line: op.line };
    }
    return left;
  }

  private parseAdditive(): any {
    let left = this.parseMultiplicative();
    while (this.at('+') || this.at('-')) {
      const op = this.next();
      left = { type: 'Binary', op: op.value, left, right: this.parseMultiplicative(), line: op.line };
    }
    return left;
  }

  private parseMultiplicative(): any {
    let left = this.parseUnary();
    while (this.at('*') || this.at('/') || this.at('%')) {
      const op = this.next();
      left = { type: 'Binary', op: op.value, left, right: this.parseUnary(), line: op.line };
    }
    return left;
  }

  private parseUnary(): any {
    if (this.at('!') || this.at('-') || this.at('+')) {
      const op = this.next();
      return { type: 'Unary', op: op.value, arg: this.parseUnary(), line: op.line };
    }
    return this.parsePostfix();
  }

  private parsePostfix(): any {
    let expr = this.parsePrimary();
    for (;;) {
      if (this.at('.')) {
        this.next();
        const name = this.expectIdent('property name');
        expr = { type: 'Member', object: expr, name: name.value, line: name.line };
        continue;
      }
      if (this.at('(')) {
        const line = this.next().line;
        const args: any[] = [];
        while (!this.at(')')) {
          args.push(this.parseExpression());
          if (this.at(',')) this.next();
          else break;
        }
        this.expect(')');
        expr = { type: 'Call', callee: expr, args, line };
        continue;
      }
      if (this.at('[')) {
        const line = this.next().line;
        const index = this.parseExpression();
        this.expect(']');
        expr = { type: 'Index', object: expr, index, line };
        continue;
      }
      if ((this.at('++') || this.at('--')) && this.isAssignable(expr)) {
        const op = this.next();
        expr = {
          type: 'Assign',
          target: expr,
          op: op.value === '++' ? '+=' : '-=',
          value: { type: 'Literal', value: 1, line: op.line },
          line: op.line,
        };
        continue;
      }
      break;
    }
    return expr;
  }

  private parsePrimary(): any {
    const tok = this.peek();
    if (tok.type === 'num') { this.next(); return { type: 'Literal', value: tok.num, line: tok.line }; }
    if (tok.type === 'str') { this.next(); return { type: 'Literal', value: tok.value, line: tok.line }; }
    if (this.at('true')) { this.next(); return { type: 'Literal', value: true, line: tok.line }; }
    if (this.at('false')) { this.next(); return { type: 'Literal', value: false, line: tok.line }; }
    if (this.at('null')) { this.next(); return { type: 'Literal', value: null, line: tok.line }; }
    if (this.at('this')) { this.next(); return { type: 'This', line: tok.line }; }
    if (this.at('new')) {
      this.next();
      const name = this.expectIdent('type name after new');
      this.expect('(');
      const args: any[] = [];
      while (!this.at(')')) {
        args.push(this.parseExpression());
        if (this.at(',')) this.next();
        else break;
      }
      this.expect(')');
      return { type: 'New', className: name.value, args, line: name.line };
    }
    if (this.at('(')) {
      this.next();
      const expr = this.parseExpression();
      this.expect(')');
      return expr;
    }
    if (this.at('[')) {
      this.next();
      const items: any[] = [];
      while (!this.at(']')) {
        items.push(this.parseExpression());
        if (this.at(',')) this.next();
        else break;
      }
      this.expect(']');
      return { type: 'ArrayLiteral', items, line: tok.line };
    }
    if (tok.type === 'ident') { this.next(); return { type: 'Ident', name: tok.value, line: tok.line }; }
    return this.fail(`Unexpected token '${tok.value}' in expression`);
  }
}

/* ------------------------------------------------------------------ runtime */

export interface ScriptHostClock { delta: number; elapsed: number; frame: number; fixed: number }

export interface ScriptHost {
  /** log a message into the editor Console */
  log(level: 'log' | 'warn' | 'error', message: string, info?: { script?: string; line?: number }): void;
  /** real-time values for Time.* */
  clock(): ScriptHostClock;
  /** keyboard query used by Input.* */
  input: {
    down(key: string): boolean;
    pressed(key: string): boolean;
    up(key: string): boolean;
    axis(name: string): number;
    mouseDelta(): { x: number; y: number };
  };
  /** create a primitive at runtime and return its GameObject */
  instantiate(type: string, position?: any): any;
  /** remove a GameObject from the scene */
  destroy(obj: any): void;
  /** find a GameObject by name */
  find(name: string): any;
  /** broadcast an engine event (this.emit) */
  emit(instance: ScriptInstance, name: string, payload: any): void;
  /** called when a script writes a public field from inside itself */
  onFieldWrite?(instance: ScriptInstance, name: string, value: any): void;
}

export interface ScriptClass {
  name: string;
  base: string;
  fields: FieldSpec[];
  methods: Map<string, MethodDecl>;
  methodNames: string[];
  source: string;
  scriptName: string;
  ast: ClassDecl;
}

/* ------------------------------------------------------------- value helpers */

function isVectorLike(v: any): boolean {
  return !!v && typeof v === 'object' && typeof v.x === 'number' && typeof v.y === 'number' && typeof v.z === 'number';
}

function numberish(v: any): number | null {
  if (typeof v === 'number') return v;
  if (typeof v === 'boolean') return v ? 1 : 0;
  if (v && typeof v === 'object' && typeof v.valueOf === 'function') {
    const p = v.valueOf();
    if (typeof p === 'number' && !Number.isNaN(p)) return p;
  }
  return null;
}

export function formatValue(v: any): string {
  if (v === null || v === undefined) return 'null';
  if (typeof v === 'number') return Number.isInteger(v) ? String(v) : v.toFixed(2);
  if (typeof v === 'string') return v;
  if (typeof v === 'boolean') return v ? 'true' : 'false';
  if (Array.isArray(v)) return '[' + v.map(formatValue).join(', ') + ']';
  if (isVectorLike(v)) return `(${formatValue(v.x)}, ${formatValue(v.y)}, ${formatValue(v.z)})`;
  if (v.__kind === 'gameobject') return `[Object ${v.name}]`;
  if (v.__kind === 'component') return `[Component ${v.className}]`;
  if (v.__kind === 'transform') return '[Transform]';
  try { return String(v); } catch { return '[object]'; }
}

function fmtArgs(args: any[]): string {
  return args.map(formatValue).join(' ');
}

function typeToKind(declType: string): FieldSpec['kind'] {
  const t = (declType || '').toLowerCase();
  if (t === 'string') return 'string';
  if (t === 'bool' || t === 'boolean') return 'bool';
  if (t === 'vector3' || t === 'vector2' || t === 'color') return 'vec3';
  return 'number';
}

function defaultValueForKind(kind: FieldSpec['kind'], three: any): any {
  if (kind === 'string') return '';
  if (kind === 'bool') return false;
  if (kind === 'vec3') return new three.Vector3(0, 0, 0);
  return 0;
}

function coerceFieldValue(spec: FieldSpec, value: any, three: any): any {
  switch (spec.kind) {
    case 'string':
      return typeof value === 'string' ? value : formatValue(value);
    case 'bool':
      if (typeof value === 'boolean') return value;
      if (typeof value === 'number') return value !== 0;
      return !!value;
    case 'vec3': {
      if (isVectorLike(value)) return new three.Vector3(value.x, value.y, value.z);
      if (Array.isArray(value)) return new three.Vector3(value[0] || 0, value[1] || 0, value[2] || 0);
      return new three.Vector3(0, 0, 0);
    }
    default: {
      const num = numberish(value);
      return num === null ? 0 : num;
    }
  }
}

/* ---------------------------------------------------------- control signals */

class ReturnSignal { constructor(public value: any) {} }
class BreakSignal {}
class ContinueSignal {}

/* ------------------------------------------------------------- interpreter */

const MAX_STEPS = 2_000_000;

class Interpreter {
  private rt: ScriptRuntime;
  private steps = 0;

  constructor(rt: ScriptRuntime) { this.rt = rt; }

  private budget(line: number, script: string): void {
    if (++this.steps > MAX_STEPS) {
      throw new ScriptError('Execution budget exceeded — possible infinite loop.', line, script);
    }
  }

  execBlock(block: any, scope: Scope, ctx: CallContext): void {
    for (const stmt of block.body) this.execStmt(stmt, scope, ctx);
  }

  execStmt(stmt: any, scope: Scope, ctx: CallContext): void {
    this.budget(stmt.line, ctx.scriptName);
    switch (stmt.type) {
      case 'Block': {
        const inner = new Scope(scope);
        this.execBlock(stmt, inner, ctx);
        return;
      }
      case 'VarDecl': {
        const value = stmt.init ? this.evalExpr(stmt.init, scope, ctx) : null;
        scope.define(stmt.name, value);
        return;
      }
      case 'ExprStmt':
        this.evalExpr(stmt.expr, scope, ctx);
        return;
      case 'If': {
        if (truthy(this.evalExpr(stmt.cond, scope, ctx))) this.execStmt(stmt.then, scope, ctx);
        else if (stmt.alt) this.execStmt(stmt.alt, scope, ctx);
        return;
      }
      case 'While': {
        while (truthy(this.evalExpr(stmt.cond, scope, ctx))) {
          this.budget(stmt.line, ctx.scriptName);
          try {
            this.execStmt(stmt.body, scope, ctx);
          } catch (e) {
            if (e instanceof BreakSignal) break;
            if (e instanceof ContinueSignal) continue;
            throw e;
          }
        }
        return;
      }
      case 'For': {
        const inner = new Scope(scope);
        if (stmt.init) this.execStmt(stmt.init, inner, ctx);
        while (stmt.cond ? truthy(this.evalExpr(stmt.cond, inner, ctx)) : true) {
          this.budget(stmt.line, ctx.scriptName);
          try {
            this.execStmt(stmt.body, inner, ctx);
          } catch (e) {
            if (e instanceof BreakSignal) break;
            if (e instanceof ContinueSignal) { /* fall through to update */ }
            else throw e;
          }
          if (stmt.update) this.execStmt(stmt.update, inner, ctx);
        }
        return;
      }
      case 'Return': {
        throw new ReturnSignal(stmt.value ? this.evalExpr(stmt.value, scope, ctx) : null);
      }
      case 'Break': throw new BreakSignal();
      case 'Continue': throw new ContinueSignal();
      default:
        throw new ScriptError(`Unsupported statement '${stmt.type}'`, stmt.line, ctx.scriptName);
    }
  }

  evalExpr(node: any, scope: Scope, ctx: CallContext): any {
    this.budget(node.line, ctx.scriptName);
    switch (node.type) {
      case 'Literal':
        return node.value;
      case 'ArrayLiteral':
        return node.items.map((i: any) => this.evalExpr(i, scope, ctx));
      case 'This':
        return ctx.self;
      case 'Ident': {
        const local = scope.lookup(node.name);
        if (local.found) return local.value;
        if (ctx.self && node.name in ctx.self) return ctx.self[node.name];
        throw new ScriptError(`Unknown variable '${node.name}'`, node.line, ctx.scriptName);
      }
      case 'Member': {
        const obj = this.evalExpr(node.object, scope, ctx);
        return this.getMember(obj, node.name, node.line, ctx);
      }
      case 'Index': {
        const obj = this.evalExpr(node.object, scope, ctx);
        const idx = this.evalExpr(node.index, scope, ctx);
        const key = typeof idx === 'number' ? idx : formatValue(idx);
        if (obj === null || obj === undefined) {
          throw new ScriptError('Cannot index null', node.line, ctx.scriptName);
        }
        const v = (obj as any)[key];
        return typeof v === 'function' ? v.bind(obj) : v;
      }
      case 'Unary': {
        if (node.op === '!') return !truthy(this.evalExpr(node.arg, scope, ctx));
        const v = this.toNumber(this.evalExpr(node.arg, scope, ctx), node.line, ctx);
        return node.op === '-' ? -v : v;
      }
      case 'Logical': {
        const left = this.evalExpr(node.left, scope, ctx);
        if (node.op === '&&') return truthy(left) ? this.evalExpr(node.right, scope, ctx) : left;
        return truthy(left) ? left : this.evalExpr(node.right, scope, ctx);
      }
      case 'Binary':
        return this.evalBinary(node, scope, ctx);
      case 'Assign':
        return this.evalAssign(node, scope, ctx);
      case 'New': {
        const ctor = this.resolveCallee(node.className, scope, ctx, node.line);
        const args = node.args.map((a: any) => this.evalExpr(a, scope, ctx));
        if (typeof ctor !== 'function') {
          throw new ScriptError(`'${node.className}' is not a constructible type`, node.line, ctx.scriptName);
        }
        return ctor(...args);
      }
      case 'Call': {
        const args = node.args.map((a: any) => this.evalExpr(a, scope, ctx));
        if (node.callee.type === 'Member') {
          const obj = this.evalExpr(node.callee.object, scope, ctx);
          const fn = this.getMember(obj, node.callee.name, node.callee.line, ctx);
          return this.invoke(fn, obj, args, node.line, ctx, node.callee.name);
        }
        const callee = this.resolveCallee(node.callee.name, scope, ctx, node.line);
        return this.invoke(callee, null, args, node.line, ctx, node.callee.name);
      }
      default:
        throw new ScriptError(`Unsupported expression '${node.type}'`, node.line, ctx.scriptName);
    }
  }

  private resolveCallee(name: string, scope: Scope, ctx: CallContext, line: number): any {
    const local = scope.lookup(name);
    if (local.found) return local.value;
    if (ctx.self && name in ctx.self) return ctx.self[name];
    throw new ScriptError(`Unknown function or type '${name}'`, line, ctx.scriptName);
  }

  private invoke(fn: any, self: any, args: any[], line: number, ctx: CallContext, label: string): any {
    if (typeof fn !== 'function') {
      throw new ScriptError(`'${label}' is not callable`, line, ctx.scriptName);
    }
    try {
      return fn.apply(self, args);
    } catch (err) {
      if (err instanceof ScriptError) throw err;
      if (err instanceof ReturnSignal || err instanceof BreakSignal || err instanceof ContinueSignal) throw err;
      const message = err instanceof Error ? err.message : String(err);
      throw new ScriptError(`${label}(): ${message}`, line, ctx.scriptName);
    }
  }

  private getMember(obj: any, name: string, line: number, ctx: CallContext): any {
    if (obj === null || obj === undefined) {
      throw new ScriptError(`Cannot read property '${name}' of ${obj === null ? 'null' : 'undefined'}`, line, ctx.scriptName);
    }
    if (name === 'length' && (Array.isArray(obj) || typeof obj === 'string')) return obj.length;
    let value: any;
    try {
      value = obj[name];
    } catch (err) {
      throw new ScriptError(`Reading '${name}' failed: ${err instanceof Error ? err.message : String(err)}`, line, ctx.scriptName);
    }
    if (typeof value === 'function') return value.bind(obj);
    return value;
  }

  private evalBinary(node: any, scope: Scope, ctx: CallContext): any {
    const op = node.op;
    if (op === '&&' || op === '||') {
      const left = truthy(this.evalExpr(node.left, scope, ctx));
      if (op === '&&') return left ? truthy(this.evalExpr(node.right, scope, ctx)) : false;
      return left ? true : truthy(this.evalExpr(node.right, scope, ctx));
    }

    const l = this.evalExpr(node.left, scope, ctx);
    const r = this.evalExpr(node.right, scope, ctx);

    switch (op) {
      case '==': return this.looseEqual(l, r);
      case '!=': return !this.looseEqual(l, r);
      case '+': {
        if (typeof l === 'string' || typeof r === 'string') return formatValue(l) + formatValue(r);
        if (isVectorLike(l) && isVectorLike(r)) return l.clone().add(r);
        return this.toNumber(l, node.line, ctx) + this.toNumber(r, node.line, ctx);
      }
      case '-': {
        if (isVectorLike(l) && isVectorLike(r)) return l.clone().sub(r);
        return this.toNumber(l, node.line, ctx) - this.toNumber(r, node.line, ctx);
      }
      case '*': {
        if (isVectorLike(l) && isVectorLike(r)) return l.clone().multiply(r);
        if (isVectorLike(l)) return l.clone().multiplyScalar(this.toNumber(r, node.line, ctx));
        if (isVectorLike(r)) return r.clone().multiplyScalar(this.toNumber(l, node.line, ctx));
        return this.toNumber(l, node.line, ctx) * this.toNumber(r, node.line, ctx);
      }
      case '/': {
        const d = this.toNumber(r, node.line, ctx);
        if (d === 0) throw new ScriptError('Division by zero', node.line, ctx.scriptName);
        return this.toNumber(l, node.line, ctx) / d;
      }
      case '%': return this.toNumber(l, node.line, ctx) % this.toNumber(r, node.line, ctx);
      case '<': return this.compare(l, r, node.line, ctx) < 0;
      case '>': return this.compare(l, r, node.line, ctx) > 0;
      case '<=': return this.compare(l, r, node.line, ctx) <= 0;
      case '>=': return this.compare(l, r, node.line, ctx) >= 0;
      default:
        throw new ScriptError(`Unsupported operator '${op}'`, node.line, ctx.scriptName);
    }
  }

  private compare(l: any, r: any, line: number, ctx: CallContext): number {
    if (typeof l === 'string' || typeof r === 'string') {
      const a = formatValue(l);
      const b = formatValue(r);
      return a < b ? -1 : a > b ? 1 : 0;
    }
    const a = this.toNumber(l, line, ctx);
    const b = this.toNumber(r, line, ctx);
    return a < b ? -1 : a > b ? 1 : 0;
  }

  private looseEqual(l: any, r: any): boolean {
    if (l === r) return true;
    if (l === null || r === null) return false;
    if (typeof l === 'string' || typeof r === 'string') return formatValue(l) === formatValue(r);
    const a = numberish(l);
    const b = numberish(r);
    if (a !== null && b !== null) return a === b;
    return false;
  }

  private toNumber(v: any, line: number, ctx: CallContext): number {
    const n = numberish(v);
    if (n === null) {
      throw new ScriptError(`Expected a number but got ${formatValue(v)}`, line, ctx.scriptName);
    }
    return n;
  }

  private evalAssign(node: any, scope: Scope, ctx: CallContext): any {
    const value = this.evalExpr(node.value, scope, ctx);
    const target = node.target;

    if (node.op === '=') {
      this.store(target, value, scope, ctx);
      return value;
    }

    const current = this.load(target, scope, ctx);
    const currentNum = this.toNumber(current, node.line, ctx);
    const valueNum = this.toNumber(value, node.line, ctx);
    let next: any;
    switch (node.op) {
      case '+=': next = typeof current === 'string' ? current + formatValue(value) : currentNum + valueNum; break;
      case '-=': next = currentNum - valueNum; break;
      case '*=': next = currentNum * valueNum; break;
      case '/=': {
        if (valueNum === 0) throw new ScriptError('Division by zero', node.line, ctx);
        next = currentNum / valueNum;
        break;
      }
      default:
        throw new ScriptError(`Unsupported assignment '${node.op}'`, node.line, ctx.scriptName);
    }
    this.store(target, next, scope, ctx);
    return next;
  }

  private load(target: any, scope: Scope, ctx: CallContext): any {
    if (target.type === 'Ident') {
      const local = scope.lookup(target.name);
      if (local.found) return local.value;
      if (ctx.self && target.name in ctx.self) return ctx.self[target.name];
      throw new ScriptError(`Unknown variable '${target.name}'`, target.line, ctx.scriptName);
    }
    if (target.type === 'Member') {
      const obj = this.evalExpr(target.object, scope, ctx);
      return this.getMember(obj, target.name, target.line, ctx);
    }
    if (target.type === 'Index') {
      const obj = this.evalExpr(target.object, scope, ctx);
      const key = this.evalExpr(target.index, scope, ctx);
      return obj[typeof key === 'number' ? key : formatValue(key)];
    }
    throw new ScriptError('Invalid assignment target', target.line, ctx.scriptName);
  }

  private store(target: any, value: any, scope: Scope, ctx: CallContext): void {
    if (target.type === 'Ident') {
      if (scope.assign(target.name, value)) return;
      if (ctx.self && target.name in ctx.self) { ctx.self[target.name] = value; return; }
      // brand new local (typed declaration without a type)
      scope.define(target.name, value);
      return;
    }
    if (target.type === 'Member') {
      const obj = this.evalExpr(target.object, scope, ctx);
      if (obj === null || obj === undefined) {
        throw new ScriptError(`Cannot set '${target.name}' on null`, target.line, ctx.scriptName);
      }
      try {
        obj[target.name] = value;
      } catch (err) {
        throw new ScriptError(
          `Cannot set '${target.name}': ${err instanceof Error ? err.message : String(err)}`,
          target.line,
          ctx.scriptName,
        );
      }
      return;
    }
    if (target.type === 'Index') {
      const obj = this.evalExpr(target.object, scope, ctx);
      const key = this.evalExpr(target.index, scope, ctx);
      if (obj === null || obj === undefined) {
        throw new ScriptError('Cannot assign into null', target.line, ctx.scriptName);
      }
      obj[typeof key === 'number' ? key : formatValue(key)] = value;
      return;
    }
    throw new ScriptError('Invalid assignment target', target.line, ctx.scriptName);
  }
}

function truthy(v: any): boolean {
  if (v === null || v === undefined) return false;
  if (typeof v === 'boolean') return v;
  if (typeof v === 'number') return v !== 0;
  if (typeof v === 'string') return v.length > 0;
  const num = numberish(v);
  if (num !== null) return num !== 0;
  return true;
}

/* --------------------------------------------------------------- scope chain */

class Scope {
  private vars = new Map<string, any>();
  constructor(private parent: Scope | null) {}

  define(name: string, value: any): void { this.vars.set(name, value); }

  lookup(name: string): { found: boolean; value?: any } {
    if (this.vars.has(name)) return { found: true, value: this.vars.get(name) };
    if (this.parent) return this.parent.lookup(name);
    return { found: false };
  }

  assign(name: string, value: any): boolean {
    if (this.vars.has(name)) { this.vars.set(name, value); return true; }
    if (this.parent) return this.parent.assign(name, value);
    return false;
  }
}

interface CallContext {
  self: any;
  scriptName: string;
  className: string;
}

/* --------------------------------------------------------------- built-ins */

function installBuiltins(rt: ScriptRuntime, three: any, host: ScriptHost) {
  /* Math (plus a Unity-flavoured Mathf alias) */
  const m = {
    sin: (a: number) => Math.sin(a), cos: (a: number) => Math.cos(a), tan: (a: number) => Math.tan(a),
    asin: (a: number) => Math.asin(a), acos: (a: number) => Math.acos(a), atan: (a: number) => Math.atan(a),
    atan2: (a: number, b: number) => Math.atan2(a, b), sqrt: (a: number) => Math.sqrt(a),
    abs: (a: number) => Math.abs(a), floor: (a: number) => Math.floor(a), ceil: (a: number) => Math.ceil(a),
    round: (a: number) => Math.round(a), sign: (a: number) => Math.sign(a),
    min: (...a: number[]) => Math.min(...a), max: (...a: number[]) => Math.max(...a),
    pow: (a: number, b: number) => Math.pow(a, b), exp: (a: number) => Math.exp(a), log: (a: number) => Math.log(a),
    hypot: (a: number, b: number) => Math.hypot(a, b), random: () => Math.random(),
    lerp: (a: number, b: number, t: number) => a + (b - a) * t,
    clamp: (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v)),
    clamp01: (v: number) => Math.min(1, Math.max(0, v)),
    moveTowards: (a: number, b: number, d: number) => (Math.abs(b - a) <= d ? b : a + Math.sign(b - a) * d),
    smoothstep: (t: number) => { const x = Math.min(1, Math.max(0, t)); return x * x * (3 - 2 * x); },
    deg2Rad: (d: number) => (d * Math.PI) / 180,
    rad2Deg: (r: number) => (r * 180) / Math.PI,
    repeat: (v: number, len: number) => v - Math.floor(v / len) * len,
    pingPong: (t: number, len: number) => { const x = (((t % (len * 2)) + len * 2) % (len * 2)); return len - Math.abs(x - len); },
    distance2D: (ax: number, ay: number, bx: number, by: number) => Math.hypot(bx - ax, by - ay),
    PI: Math.PI, E: Math.E, TAU: Math.PI * 2, Infinity: Infinity,
  };

  /* Random */
  const rnd = {
    value: () => Math.random(),
    range: (a: number, b: number) => a + Math.random() * ((b ?? 1) - (a ?? 0)),
    int: (a: number, b: number) => Math.floor(a + Math.random() * (b - a + 1)),
    chance: (p: number) => Math.random() < p,
    sign: () => (Math.random() < 0.5 ? -1 : 1),
    insideUnitSphere: () => {
      const v = new three.Vector3();
      do { v.set(Math.random() * 2 - 1, Math.random() * 2 - 1, Math.random() * 2 - 1); } while (v.lengthSq() > 1);
      return v;
    },
  };

  /* Input */
  const input = {
    getKey: (k: string) => host.input.down(String(k)),
    getKeyDown: (k: string) => host.input.pressed(String(k)),
    getKeyUp: (k: string) => host.input.up(String(k)),
    getAxis: (n: string) => host.input.axis(String(n)),
    getMouseX: () => host.input.mouseDelta().x,
    getMouseY: () => host.input.mouseDelta().y,
    get mouseX() { return host.input.mouseDelta().x; },
    get mouseY() { return host.input.mouseDelta().y; },
  };

  /* Time — getters so Time.deltaTime is always fresh */
  const time: any = {};
  Object.defineProperties(time, {
    deltaTime: { get: () => host.clock().delta, enumerable: true },
    fixedDeltaTime: { get: () => host.clock().fixed, enumerable: true },
    time: { get: () => host.clock().elapsed, enumerable: true },
    frameCount: { get: () => host.clock().frame, enumerable: true },
    unscaledDeltaTime: { get: () => host.clock().delta, enumerable: true },
  });

  /* Debug */
  const debug = {
    log: (...a: any[]) => host.log('log', fmtArgs(a)),
    info: (...a: any[]) => host.log('info', fmtArgs(a)),
    warn: (...a: any[]) => host.log('warn', fmtArgs(a)),
    error: (...a: any[]) => host.log('error', fmtArgs(a)),
  };

  /* Vector3 — a constructor function that returns real THREE.Vector3 values,
     so .add/.sub/.normalize/... are the battle-tested three.js maths. */
  const Vec: any = function (x: any, y?: any, z?: any) {
    if (x instanceof three.Vector3) return x.clone();
    if (Array.isArray(x)) return new three.Vector3(Number(x[0]) || 0, Number(x[1]) || 0, Number(x[2]) || 0);
    if (x && typeof x === 'object' && 'x' in x) return new three.Vector3(Number(x.x) || 0, Number(x.y) || 0, Number(x.z) || 0);
    return new three.Vector3(Number(x) || 0, Number(y) || 0, Number(z) || 0);
  };
  Object.defineProperties(Vec, {
    zero: { get: () => new three.Vector3(0, 0, 0) },
    one: { get: () => new three.Vector3(1, 1, 1) },
    up: { get: () => new three.Vector3(0, 1, 0) },
    down: { get: () => new three.Vector3(0, -1, 0) },
    left: { get: () => new three.Vector3(-1, 0, 0) },
    right: { get: () => new three.Vector3(1, 0, 0) },
    forward: { get: () => new three.Vector3(0, 0, 1) },
    back: { get: () => new three.Vector3(0, 0, -1) },
  });
  Vec.lerp = (a: any, b: any, t: number) => a.clone().lerp(b, t);
  Vec.distance = (a: any, b: any) => a.distanceTo(b);
  Vec.dot = (a: any, b: any) => a.dot(b);
  Vec.cross = (a: any, b: any) => a.clone().cross(b);
  Vec.normalize = (a: any) => a.clone().normalize();
  Vec.scale = (a: any, s: number) => a.clone().multiplyScalar(s);
  Vec.add = (a: any, b: any) => a.clone().add(b);
  Vec.sub = (a: any, b: any) => a.clone().sub(b);
  Vec.random = (scale: number) => rnd.insideUnitSphere().multiplyScalar(scale ?? 1);

  /* Quaternion */
  const Quat: any = function () { return new three.Quaternion(); };
  Object.defineProperty(Quat, 'identity', { get: () => new three.Quaternion() });
  Quat.euler = (xDeg: number, yDeg: number, zDeg: number) =>
    new three.Quaternion().setFromEuler(new three.Euler(rad(xDeg), rad(yDeg), rad(zDeg)));
  Quat.axisAngle = (x: number, y: number, z: number, deg: number) =>
    new three.Quaternion().setFromAxisAngle(new three.Vector3(x, y, z).normalize(), rad(deg));
  Quat.slerp = (a: any, b: any, t: number) => a.clone().slerp(b, t);

  const rad = (d: number) => (d * Math.PI) / 180;

  // Unity-style conveniences on real three vectors.
  const proto: any = three.Vector3.prototype;
  if (!('magnitude' in proto)) {
    Object.defineProperty(proto, 'magnitude', { get() { return this.length(); }, configurable: true });
  }
  if (!('sqrMagnitude' in proto)) {
    Object.defineProperty(proto, 'sqrMagnitude', { get() { return this.lengthSq(); }, configurable: true });
  }

  return { Math: m, Mathf: m, Random: rnd, Input: input, Time: time, Debug: debug, Vector3: Vec, Quaternion: Quat };
}

/* ----------------------------------------------------------------- runtime */

export class ScriptRuntime {
  readonly three: any;
  private host: ScriptHost;
  private interp: Interpreter;
  private builtins: any;
  private compiled = new Map<string, ScriptClass>();

  constructor(opts: { three: any; host: ScriptHost }) {
    this.three = opts.three;
    this.host = opts.host;
    this.interp = new Interpreter(this);
    this.builtins = installBuiltins(this, this.three, this.host);
  }

  /* ------------------------------------------------------------ compiling */

  compile(source: string, scriptName: string): ScriptClass {
    const cached = this.compiled.get(scriptName);
    if (cached && cached.source === source) return cached;

    const tokens = tokenize(source, scriptName);
    const parser = new Parser(tokens, scriptName);
    const classes = parser.parseProgram();
    const ast = classes[0]; // one class per file, as in Unity

    const fields: FieldSpec[] = ast.fields.map((f) => {
      const kind = typeToKind(f.declType);
      let value = defaultValueForKind(kind, this.three);
      if (f.init) {
        const evaluated = this.staticEval(f.init);
        if (evaluated !== undefined) value = coerceFieldValue({ name: f.name, type: f.declType, kind, value }, evaluated, this.three);
      }
      return { name: f.name, type: f.declType, kind, value };
    });

    const methods = new Map<string, MethodDecl>();
    for (const method of ast.methods) methods.set(method.name, method);

    const cls: ScriptClass = {
      name: ast.name,
      base: ast.base,
      fields,
      methods,
      methodNames: ast.methods.map((x) => x.name),
      source,
      scriptName,
      ast,
    };
    this.compiled.set(scriptName, cls);
    return cls;
  }

  /** Compile and report problems without throwing (used for live editor checks). */
  validate(source: string, scriptName: string): { ok: boolean; error: { message: string; line: number } | null; className?: string } {
    try {
      const cls = this.compile(source, scriptName);
      return { ok: true, error: null, className: cls.name };
    } catch (err) {
      if (err instanceof ScriptError) return { ok: false, error: { message: err.message, line: err.line } };
      return { ok: false, error: { message: err instanceof Error ? err.message : String(err), line: 1 } };
    }
  }

  /** Evaluate only literal-ish initialisers, so field defaults are known up front. */
  private staticEval(node: any): any {
    try {
      if (!node) return undefined;
      switch (node.type) {
        case 'Literal': return node.value;
        case 'ArrayLiteral': return node.items.map((i: any) => this.staticEval(i));
        case 'Unary': {
          const v = this.staticEval(node.arg);
          const n = numberish(v);
          if (node.op === '-' && n !== null) return -n;
          if (node.op === '!' ) return !truthy(v);
          return undefined;
        }
        case 'New': {
          const ctor = this.builtins[node.className];
          if (typeof ctor !== 'function') return undefined;
          const args = node.args.map((a: any) => this.staticEval(a));
          if (args.some((a: any) => a === undefined)) return undefined;
          return ctor(...args);
        }
        case 'Ident': {
          const statics = this.builtins[node.name];
          return typeof statics === 'object' ? statics : undefined;
        }
        case 'Member': {
          const obj = this.staticEval(node.object);
          if (obj && typeof obj === 'object') {
            const v = obj[node.name];
            return typeof v === 'function' ? undefined : v;
          }
          return undefined;
        }
        default:
          return undefined;
      }
    } catch {
      return undefined;
    }
  }

  /* ----------------------------------------------------------- instances */

  createInstance(cls: ScriptClass, gameObject: any, scriptName: string): ScriptInstance {
    const fields: Record<string, any> = {};
    for (const f of cls.fields) {
      fields[f.name] = isVectorLike(f.value) ? f.value.clone() : f.value;
    }

    const instance: ScriptInstance = {
      id: `${gameObject.id}:${cls.name}:${Math.random().toString(36).slice(2, 8)}`,
      scriptName,
      className: cls.name,
      fields,
      started: false,
      state: null,
      enabled: true,
    };

    // `this` host object — the only surface a script can touch.
    const self: any = {
      __kind: 'component',
      className: cls.name,
      instanceId: instance.id,
      object: gameObject,
      transform: gameObject.transform,
      gameObject,
      emit: (name: any, payload: any) => this.host.emit(instance, String(name ?? 'event'), payload),
      log: (...a: any[]) => this.host.log('log', fmtArgs(a), { script: scriptName }),
      find: (name: any) => this.host.find(String(name)),
      instantiate: (type: any, x?: any, y?: any, z?: any) => {
        if (isVectorLike(x)) return this.host.instantiate(String(type), x);
        if (typeof x === 'number' || typeof y === 'number' || typeof z === 'number') {
          return this.host.instantiate(String(type), new this.three.Vector3(Number(x) || 0, Number(y) || 0, Number(z) || 0));
        }
        return this.host.instantiate(String(type));
      },
      destroy: (target?: any) => this.host.destroy(target && target.__kind === 'gameobject' ? target : gameObject),
      setColor: (hex: any) => { if (typeof gameObject.setColor === 'function') gameObject.setColor(String(hex)); },
      setActive: (on: any) => { if (typeof gameObject.setActive === 'function') gameObject.setActive(truthy(on)); },
      getScript: (name: any) => (gameObject.getComponent ? gameObject.getComponent(String(name)) : null),
      random: (a: any, b: any) => this.builtins.Random.range(a, b),
      getKey: (k: any) => this.host.input.down(String(k)),
      getKeyDown: (k: any) => this.host.input.pressed(String(k)),
      getAxis: (n: any) => this.host.input.axis(String(n)),
      keys: inputAlias(this.host),
      get deltaTime() { return this.host.clock().delta; },
      get time() { return this.host.clock().elapsed; },
      get enabled() { return instance.enabled; },
      set enabled(v: any) { instance.enabled = truthy(v); },
      get name() { return gameObject.name; },
      set name(v: any) { if (typeof gameObject.rename === 'function') gameObject.rename(String(v)); },
    };

    // Built-in namespaces (Math, Input, Time, Debug, Random, Vector3, Quaternion…)
    // are identifiers inside a script, so expose them on `this`.
    for (const key of Object.keys(this.builtins)) {
      if (!(key in self)) self[key] = this.builtins[key];
    }

    // public fields become accessors so `speed = 4` inside the script updates the Inspector
    for (const f of cls.fields) {
      Object.defineProperty(self, f.name, {
        get: () => instance.fields[f.name],
        set: (v: any) => {
          instance.fields[f.name] = coerceFieldValue(f, v, this.three);
          this.host.onFieldWrite?.(instance, f.name, instance.fields[f.name]);
        },
        enumerable: true,
        configurable: true,
      });
    }

    // user methods, callable as this.methodName(...)
    for (const method of cls.methods.values()) {
      self[method.name] = (...args: any[]) => this.runMethod(instance, method.name, args, cls);
    }

    instance.state = { cls, self };
    return instance;
  }

  /** True when the class declares this lifecycle/helper method. */
  hasMethod(instance: ScriptInstance, methodName: string): boolean {
    const state = instance.state;
    if (!state?.cls) return false;
    return state.cls.methods.has(methodName);
  }

  methodNames(instance: ScriptInstance): string[] {
    const state = instance.state;
    return state?.cls ? [...state.cls.methods.keys()] : [];
  }

  /**
   * Runs a lifecycle method. NEVER throws: a script error is reported to the
   * host console with its script name and line number so the engine keeps
   * running exactly as a real editor would.
   */
  callLifecycle(instance: ScriptInstance, methodName: string, args: any[] = []): any {
    if (!instance.enabled) return undefined;
    if (!this.hasMethod(instance, methodName)) {
      if (methodName !== 'Start') return undefined;
      return undefined;
    }
    return this.runMethod(instance, methodName, args);
  }

  private runMethod(instance: ScriptInstance, methodName: string, args: any[], clsOverride?: ScriptClass): any {
    const state = instance.state;
    const cls: ScriptClass = clsOverride ?? state?.cls;
    if (!cls) return undefined;
    const method = cls.methods.get(methodName);
    if (!method) {
      if (!clsOverride) {
        this.host.log('error', `Unknown method '${methodName}' on ${cls.name}`, {
          script: instance.scriptName,
        });
      }
      return undefined;
    }

    const scope = new Scope(null);
    method.params.forEach((p, idx) => scope.define(p, args[idx] ?? null));

    const ctx: CallContext = { self: state.self, scriptName: instance.scriptName, className: cls.name };
    const interp = this.interp;
    interp['steps'] = 0;

    try {
      interp.execBlock(method.body, scope, ctx);
      return undefined;
    } catch (err) {
      if (err instanceof ReturnSignal) return err.value;
      if (err instanceof BreakSignal || err instanceof ContinueSignal) {
        this.host.log('warn', `'break'/'continue' outside of a loop in ${cls.name}.${methodName}()`, {
          script: instance.scriptName, line: method.line,
        });
        return undefined;
      }
      if (err instanceof ScriptError) {
        this.host.log('error', `${err.scriptName} · ${cls.name}.${methodName}() line ${err.line}: ${err.message}`, {
          script: instance.scriptName,
          line: err.line,
        });
      } else {
        this.host.log('error', `${cls.name}.${methodName}(): ${err instanceof Error ? err.message : String(err)}`, {
          script: instance.scriptName,
          line: method.line,
        });
      }
      return undefined;
    }
  }

  /** Exposed for the Inspector: change a public field value. */
  setField(instance: ScriptInstance, field: string, value: any): boolean {
    const state = instance.state;
    const cls: ScriptClass | undefined = state?.cls;
    if (!cls) return false;
    const spec = cls.fields.find((f) => f.name === field);
    if (!spec) return false;
    instance.fields[field] = coerceFieldValue(spec, value, this.three);
    return true;
  }

  fieldSpecs(instance: ScriptInstance): FieldSpec[] {
    const cls: ScriptClass | undefined = instance.state?.cls;
    return cls ? cls.fields : [];
  }
}

/** Unity-ish Key helper exposed as `this.keys`. */
function inputAlias(host: ScriptHost) {
  return {
    W: 'w', A: 'a', S: 's', D: 'd', Space: 'space', Shift: 'shift', Escape: 'escape',
    Up: 'arrowup', Down: 'arrowdown', Left: 'arrowleft', Right: 'arrowright',
    isDown: (k: string) => host.input.down(k),
  };
}
