/**
 * Prefabs — reusable object subtrees.
 *
 * A prefab is a named snapshot of an object *and everything under it*: the local
 * transform of every node, its material, light/camera settings, physics settings
 * and the attached script instances (including their field values). The script
 * sources the prefab depends on travel with it, so dropping a prefab into a
 * different project re-creates the scripts it needs instead of silently
 * attaching nothing.
 *
 * Prefabs live in browser storage next to the projects, so they are available in
 * every scene the user opens with this editor — not just the one they were made
 * in. Nothing in here touches three.js: capturing reads a GameObject, restoring
 * is done by EngineCore.restoreObject(), which already knows how to rebuild an
 * object from a SerializedObject.
 */

import type { GameObject } from './scene';
import type {
  CameraParams,
  LightParams,
  MaterialParams,
  ObjectType,
  PhysicsParams,
  SerializedObject,
  SerializedScript,
} from './types';

export const PREFAB_STORAGE_KEY = 'webforge.prefabs';
export const PREFAB_FORMAT = 'webforge-prefab';

/** One node of a captured subtree (children keep their local transforms). */
export interface PrefabNode {
  name: string;
  type: ObjectType;
  position: [number, number, number];
  rotation: [number, number, number];
  scale: [number, number, number];
  visible: boolean;
  material?: MaterialParams;
  light?: LightParams;
  camera?: CameraParams;
  physics?: PhysicsParams;
  scripts: SerializedScript[];
  assetId?: string | null;
  isPlayer?: boolean;
  children: PrefabNode[];
}

/** Snapshot of a script asset the prefab's instances need in order to run. */
export interface PrefabScriptSource {
  name: string;
  source: string;
}

export interface PrefabStats {
  objects: number;
  depth: number;
  scripts: number;
  physicsBodies: number;
  lights: number;
  cameras: number;
  materials: number;
}

export interface Prefab {
  id: string;
  name: string;
  format: typeof PREFAB_FORMAT;
  version: 1;
  created: number;
  updated: number;
  root: PrefabNode;
  scriptSources: PrefabScriptSource[];
  stats: PrefabStats;
}

export function newPrefabId(): string {
  return `prefab_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
}

/* ------------------------------------------------------------- capturing */

export function capturePrefabNode(obj: GameObject): PrefabNode {
  const def = obj.serialize();
  return {
    name: obj.name,
    type: obj.type,
    position: [def.position[0], def.position[1], def.position[2]],
    rotation: [def.rotation[0], def.rotation[1], def.rotation[2]],
    scale: [def.scale[0], def.scale[1], def.scale[2]],
    visible: def.visible,
    material: def.material ? { ...def.material } : undefined,
    light: def.light ? { ...def.light } : undefined,
    camera: def.camera ? { ...def.camera } : undefined,
    physics: def.physics ? { ...def.physics } : undefined,
    scripts: (def.scripts ?? []).map((s) => ({
      scriptName: s.scriptName,
      className: s.className,
      fields: safeClone(s.fields),
      enabled: s.enabled !== false,
    })),
    assetId: def.assetId ?? null,
    isPlayer: !!def.isPlayer,
    children: obj.children.map(capturePrefabNode),
  };
}

function safeClone(value: any): any {
  try {
    return JSON.parse(JSON.stringify(value ?? {}));
  } catch {
    return {};
  }
}

function walk(node: PrefabNode, cb: (node: PrefabNode, depth: number) => void, depth = 0): void {
  cb(node, depth);
  for (const child of node.children ?? []) walk(child, cb, depth + 1);
}

export function prefabStats(root: PrefabNode): PrefabStats {
  const stats: PrefabStats = { objects: 0, depth: 1, scripts: 0, physicsBodies: 0, lights: 0, cameras: 0, materials: 0 };
  walk(root, (node, depth) => {
    stats.objects += 1;
    stats.depth = Math.max(stats.depth, depth + 1);
    stats.scripts += node.scripts?.length ?? 0;
    if (node.physics?.usePhysics) stats.physicsBodies += 1;
    if (node.light) stats.lights += 1;
    if (node.camera) stats.cameras += 1;
    if (node.material) stats.materials += 1;
  });
  return stats;
}

/** Every script asset name the prefab's instances reference. */
export function prefabScriptNames(root: PrefabNode): string[] {
  const names = new Set<string>();
  walk(root, (node) => {
    for (const script of node.scripts ?? []) if (script.scriptName) names.add(script.scriptName);
  });
  return [...names];
}

/** Convert a captured node back into the definition restoreObject() expects. */
export function prefabNodeToSerialized(
  node: PrefabNode,
  options: { name?: string; parentId?: string | null; position?: [number, number, number] } = {},
): SerializedObject {
  return {
    id: `prefab_node_${Math.random().toString(36).slice(2, 8)}`,
    name: options.name ?? node.name,
    type: node.type,
    parentId: options.parentId ?? null,
    position: options.position ?? [node.position[0], node.position[1], node.position[2]],
    rotation: [node.rotation[0], node.rotation[1], node.rotation[2]],
    scale: [node.scale[0], node.scale[1], node.scale[2]],
    visible: node.visible !== false,
    material: node.material ? { ...node.material } : undefined,
    light: node.light ? { ...node.light } : undefined,
    camera: node.camera ? { ...node.camera } : undefined,
    physics: node.physics ? { ...node.physics } : undefined,
    scripts: (node.scripts ?? []).map((s) => ({ ...s, fields: safeClone(s.fields) })),
    assetId: node.assetId ?? null,
    isPlayer: !!node.isPlayer,
  };
}

/* ----------------------------------------------------------- naming / copy */

export function uniquePrefabName(existing: Prefab[], base: string): string {
  const clean = (base || 'Prefab').trim() || 'Prefab';
  const taken = existing.map((p) => p.name);
  if (!taken.includes(clean)) return clean;
  let i = 1;
  while (taken.includes(`${clean} ${i}`)) i++;
  return `${clean} ${i}`;
}

export function prefabSummary(prefab: Prefab): string {
  const s = prefab.stats;
  const parts = [`${s.objects} ${s.objects === 1 ? 'object' : 'objects'}`];
  if (s.scripts) parts.push(`${s.scripts} ${s.scripts === 1 ? 'script' : 'scripts'}`);
  if (s.physicsBodies) parts.push(`${s.physicsBodies} physics`);
  if (s.lights) parts.push(`${s.lights} ${s.lights === 1 ? 'light' : 'lights'}`);
  return parts.join(' · ');
}

const TYPE_ACCENTS: Record<string, string> = {
  Cube: '#7cd4ff',
  Sphere: '#ffd166',
  Plane: '#8be9a8',
  Cylinder: '#ffb457',
  Torus: '#c792ea',
  Capsule: '#4ea8ff',
  Cone: '#ff6b9d',
  Light: '#ffe6a8',
  Camera: '#9fd8ff',
  Empty: '#8fa0b8',
  Model: '#b8c6da',
};

/** Colour used for a prefab's card in the panel: the authored one when there is one. */
export function prefabAccent(prefab: Prefab): string {
  const node = prefab.root;
  if (node.material?.color) return node.material.color;
  if (node.light?.color) return node.light.color;
  return TYPE_ACCENTS[node.type] ?? '#7cd4ff';
}

/* --------------------------------------------------------- browser storage */

export function readPrefabStore(): Prefab[] {
  try {
    const raw = localStorage.getItem(PREFAB_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(isPrefabLike).map(normalizePrefab);
  } catch {
    return [];
  }
}

export function writePrefabStore(prefabs: Prefab[]): boolean {
  try {
    localStorage.setItem(PREFAB_STORAGE_KEY, JSON.stringify(prefabs));
    return true;
  } catch {
    return false;
  }
}

function isPrefabLike(value: any): boolean {
  return !!value && typeof value === 'object' && typeof value.name === 'string' && !!value.root && typeof value.root === 'object';
}

/** Tolerate older / hand-edited entries: fill in anything missing. */
function normalizePrefab(value: any): Prefab {
  const root = normalizeNode(value.root);
  return {
    id: typeof value.id === 'string' && value.id ? value.id : newPrefabId(),
    name: String(value.name),
    format: PREFAB_FORMAT,
    version: 1,
    created: Number(value.created) || Date.now(),
    updated: Number(value.updated) || Number(value.created) || Date.now(),
    root,
    scriptSources: Array.isArray(value.scriptSources)
      ? value.scriptSources
          .filter((s: any) => s && typeof s.name === 'string' && typeof s.source === 'string')
          .map((s: any) => ({ name: String(s.name), source: String(s.source) }))
      : [],
    stats: prefabStats(root),
  };
}

function normalizeNode(value: any): PrefabNode {
  const vec = (input: any, fallback: [number, number, number]): [number, number, number] =>
    Array.isArray(input) && input.length >= 3
      ? [Number(input[0]) || 0, Number(input[1]) || 0, Number(input[2]) || 0]
      : fallback;
  return {
    name: typeof value.name === 'string' ? value.name : 'Object',
    type: (typeof value.type === 'string' ? value.type : 'Cube') as ObjectType,
    position: vec(value.position, [0, 0, 0]),
    rotation: vec(value.rotation, [0, 0, 0]),
    scale: Array.isArray(value.scale) && value.scale.length >= 3
      ? [Number(value.scale[0]) || 0, Number(value.scale[1]) || 0, Number(value.scale[2]) || 0]
      : [1, 1, 1],
    visible: value.visible !== false,
    material: value.material ?? undefined,
    light: value.light ?? undefined,
    camera: value.camera ?? undefined,
    physics: value.physics ?? undefined,
    scripts: Array.isArray(value.scripts) ? value.scripts : [],
    assetId: value.assetId ?? null,
    isPlayer: !!value.isPlayer,
    children: Array.isArray(value.children) ? value.children.map(normalizeNode) : [],
  };
}
