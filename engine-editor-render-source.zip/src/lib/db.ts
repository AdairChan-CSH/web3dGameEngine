import { createClient } from "@supabase/supabase-js";

// SuperCool managed database (public url + anon key).
const url = "https://prjf71fdea1c12ba90664de.databasepad.com";
const anonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjE1ZTk3ZDU0LWUzMjktNGMwYi05NTk3LTY3Y2Q4MDU0MzFjZiJ9.eyJwcm9qZWN0SWQiOiJwcmpmNzFmZGVhMWMxMmJhOTA2NjRkZSIsInJvbGUiOiJhbm9uIiwiaWF0IjoxNzg5OTIzMzcxLCJleHAiOjIxMDUyODMzNzEsImlzcyI6ImZhbW91cy5kYXRhYmFzZXBhZCIsImF1ZCI6ImZhbW91cy5jbGllbnRzIn0.c4mxn_FdXR6y2WRd4nbenl-S_T_CAtOWcNULO1S0rJc";

export const db = createClient(url, anonKey);
export default db;
