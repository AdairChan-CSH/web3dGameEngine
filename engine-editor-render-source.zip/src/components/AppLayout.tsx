/**
 * AppLayout — the whole editor shell.
 *
 * Single source of truth for page UI: the docked panels (Hierarchy / viewport /
 * Inspector), the resizable console dock, the status bar and the compact-screen
 * drawers. The engine instance is created here and shared through context.
 */

import { useEffect, useRef, useState } from 'react';
import {
  TriangleAlert,
  Boxes,
  BookOpen,
  Layers,
  Loader,
  Package,
  PanelLeftClose,
  PanelLeftOpen,
  PanelRightClose,
  PanelRightOpen,
  Rows3,
  SlidersHorizontal,
} from 'lucide-react';
import { EngineCore } from '@/engine/core';
import { EngineProvider, useEngine, useEngineStats, useEngineVersion, useIsCompact } from '@/engine/engine-context';
import { Toolbar } from './editor/Toolbar';
import { HierarchyPanel } from './editor/HierarchyPanel';
import { PrefabsPanel } from './editor/PrefabsPanel';
import { InspectorPanel } from './editor/InspectorPanel';
import { BottomPanel } from './editor/BottomPanel';
import { ViewportArea } from './editor/ViewportArea';
import { CloseX, IconButton, TabStrip, Tag } from './editor/ui';
import { cn } from '@/lib/utils';
import type { ViewTab } from '@/engine/types';

type LeftPanelTab = 'hierarchy' | 'prefabs';

export default function AppLayout() {
  const [core] = useState(() => new EngineCore());

  useEffect(() => {
    void core.init();
    return () => core.dispose();
  }, [core]);

  return (
    <EngineProvider core={core}>
      <EditorShell />
    </EngineProvider>
  );
}

function EditorShell() {
  const core = useEngine();
  useEngineVersion();
  const stats = useEngineStats();
  const isCompact = useIsCompact(1024);

  const [tab, setTab] = useState<ViewTab>('scene');
  const [bottomHeight, setBottomHeight] = useState(230);
  const [leftOpen, setLeftOpen] = useState(true);
  const [rightOpen, setRightOpen] = useState(true);
  const [bottomOpen, setBottomOpen] = useState(true);
  const [drawer, setDrawer] = useState<null | 'hierarchy' | 'prefabs' | 'inspector' | 'bottom'>(null);
  const [leftTab, setLeftTab] = useState<LeftPanelTab>('hierarchy');

  const shellRef = useRef<HTMLDivElement>(null);
  const trackedReady = useRef(false);
  const trackedPlay = useRef(false);

  /* analytics: the two moments that matter for this app */
  useEffect(() => {
    if (core.ready && !trackedReady.current) {
      trackedReady.current = true;
      core.track('engine_ready', { three: core.threeSourceLabel });
    }
    if (core.playState === 'playing' && !trackedPlay.current) {
      trackedPlay.current = true;
      core.track('play_mode_started', { objects: core.objectCount() });
    }
    if (core.playState === 'stopped') trackedPlay.current = false;
  }, [core, core.ready, core.playState, core.version]);

  const startResize = (event: React.PointerEvent) => {
    event.preventDefault();
    const move = (ev: PointerEvent) => {
      const rect = shellRef.current?.getBoundingClientRect();
      if (!rect) return;
      const next = rect.bottom - ev.clientY - 24;
      setBottomHeight(Math.max(120, Math.min(next, rect.height * 0.72)));
    };
    const stop = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', stop);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', stop);
  };

  const openPanel = (panel: LeftPanelTab | 'inspector' | 'bottom') => {
    if (isCompact) {
      setDrawer(panel);
      return;
    }
    if (panel === 'inspector') setRightOpen(true);
    else if (panel === 'bottom') setBottomOpen(true);
    else {
      setLeftTab(panel);
      setLeftOpen(true);
    }
  };

  /** Saves from the Hierarchy should land somewhere the user can see them. */
  const revealPrefabs = () => {
    if (isCompact) {
      setDrawer('prefabs');
    } else {
      setLeftTab('prefabs');
      setLeftOpen(true);
    }
  };

  const hierarchy = (
    <HierarchyPanel
      onPick={() => setDrawer(null)}
      onSavedAsPrefab={() => revealPrefabs()}
      onOpenPrefabs={revealPrefabs}
    />
  );
  const inspector = <InspectorPanel onPick={() => setDrawer(null)} />;
  const prefabs = <PrefabsPanel onPick={() => setDrawer(null)} />;

  return (
    <div ref={shellRef} className="relative flex h-screen w-full flex-col overflow-hidden bg-[#0b0d11] text-slate-200">
      <Toolbar onOpenPanel={openPanel} compact={isCompact} />

      <div className="flex min-h-0 flex-1">
        {/* left dock — Hierarchy and Prefabs share it */}
        {!isCompact && leftOpen ? (
          <aside className="flex w-[248px] shrink-0 flex-col border-r border-[#232833] xl:w-[276px]">
            <TabStrip
              value={leftTab}
              onChange={(value) => setLeftTab(value as LeftPanelTab)}
              tabs={[
                { value: 'hierarchy', label: 'Hierarchy', icon: Layers, badge: String(core.objectCount()) },
                {
                  value: 'prefabs',
                  label: 'Prefabs',
                  icon: Package,
                  badge: core.prefabs.length ? String(core.prefabs.length) : undefined,
                },
              ]}
            />
            <div className="flex min-h-0 flex-1 flex-col">{leftTab === 'prefabs' ? prefabs : hierarchy}</div>
            <button
              type="button"
              onClick={() => setLeftOpen(false)}
              className="flex h-6 items-center justify-center border-t border-[#232833] bg-[#12161d] text-slate-500 transition-colors hover:text-sky-300"
              title="Collapse the left dock"
            >
              <PanelLeftClose className="h-3.5 w-3.5" />
            </button>
          </aside>
        ) : null}

        {/* centre column */}
        <main className="flex min-w-0 flex-1 flex-col">
          {!isCompact && !leftOpen ? (
            <div className="flex h-6 items-center border-b border-[#232833] bg-[#12161d] px-1">
              <IconButton icon={PanelLeftOpen} label="Show the Hierarchy and Prefabs panels" onClick={() => setLeftOpen(true)} className="h-5 w-5" />
            </div>
          ) : null}

          <ViewportArea tab={tab} onTab={setTab} />

          {bottomOpen ? (
            <>
              <div
                onPointerDown={startResize}
                className="group flex h-1.5 shrink-0 cursor-row-resize items-center justify-center bg-[#12161d] transition-colors hover:bg-sky-500/30"
                title="Drag to resize the console dock"
              >
                <span className="h-[2px] w-10 rounded-full bg-[#2b323f] group-hover:bg-sky-400/70" />
              </div>
              <div className="shrink-0 border-t border-[#232833]" style={{ height: bottomHeight }}>
                <div className="relative h-full">
                  <BottomPanel onOpenDocs={() => setTab('docs')} />
                  <button
                    type="button"
                    onClick={() => setBottomOpen(false)}
                    className="absolute right-1.5 top-1.5 rounded border border-[#2b323f] bg-[#12161d] px-1.5 py-0.5 text-[10px] text-slate-400 transition-colors hover:text-sky-300"
                    title="Hide the console dock"
                  >
                    hide
                  </button>
                </div>
              </div>
            </>
          ) : (
            <button
              type="button"
              onClick={() => setBottomOpen(true)}
              className="flex h-7 shrink-0 items-center gap-2 border-t border-[#232833] bg-[#12161d] px-2 text-[10px] text-slate-400 transition-colors hover:text-sky-300"
            >
              <Rows3 className="h-3.5 w-3.5" /> show console &amp; script editor
            </button>
          )}
        </main>

        {/* right dock */}
        {!isCompact && rightOpen ? (
          <aside className="flex w-[286px] shrink-0 flex-col border-l border-[#232833] xl:w-[320px]">
            <div className="flex min-h-0 flex-1 flex-col">{inspector}</div>
            <button
              type="button"
              onClick={() => setRightOpen(false)}
              className="flex h-6 items-center justify-center border-t border-[#232833] bg-[#12161d] text-slate-500 transition-colors hover:text-sky-300"
              title="Collapse the Inspector panel"
            >
              <PanelRightClose className="h-3.5 w-3.5" />
            </button>
          </aside>
        ) : null}

        {!isCompact && !rightOpen ? (
          <div className="flex h-full w-6 flex-col items-center border-l border-[#232833] bg-[#12161d] pt-1">
            <IconButton icon={PanelRightOpen} label="Show the Inspector panel" onClick={() => setRightOpen(true)} className="h-5 w-5" />
          </div>
        ) : null}
      </div>

      {/* status bar */}
      <footer className="z-20 flex h-6 shrink-0 items-center gap-2 border-t border-[#232833] bg-[#12161d] px-2 text-[10px] text-slate-500">
        <span className="flex items-center gap-1 text-slate-400">
          <Boxes className="h-3 w-3 text-sky-400" />
          WebForge
        </span>
        <span className="hidden sm:inline">{core.threeSourceLabel}</span>
        <span className="hidden md:inline">· projects autosave in this browser · import/export JSON &amp; glTF from the File menu</span>
        <span className="ml-auto flex items-center gap-2">
          <span className="font-mono">
            {stats.objects} objects · {stats.scripts} scripts · {core.prefabs.length} prefabs · {stats.geometries} geometries · {stats.textures} textures
          </span>
          {core.playState === 'playing' ? <Tag tone="emerald">running</Tag> : <Tag tone="neutral">{core.playState}</Tag>}
          {isCompact ? (
            <>
              <IconButton icon={SlidersHorizontal} label="Inspector" onClick={() => setDrawer('inspector')} className="h-5 w-5" />
              <IconButton icon={Package} label="Prefabs" onClick={() => setDrawer('prefabs')} className="h-5 w-5" />
              <IconButton icon={Rows3} label="Console" onClick={() => setDrawer('bottom')} className="h-5 w-5" />
            </>
          ) : (
            <button
              type="button"
              onClick={() => setTab('docs')}
              className="flex items-center gap-1 text-slate-400 transition-colors hover:text-sky-300"
            >
              <BookOpen className="h-3 w-3" /> docs
            </button>
          )}
        </span>
      </footer>

      {/* compact drawers */}
      {isCompact && drawer ? (
        <div className="fixed inset-0 z-40 flex">
          {drawer !== 'inspector' ? (
            <div className="h-full w-[300px] max-w-[85vw] border-r border-[#232833] bg-[#11141a] shadow-2xl">
              <div className="flex items-center justify-between border-b border-[#232833] bg-[#151922] px-2 py-1.5">
                <span className="text-[11px] uppercase tracking-wide text-slate-400">
                  {drawer === 'hierarchy' ? 'Hierarchy' : drawer === 'prefabs' ? 'Prefabs' : 'Console & scripts'}
                </span>
                <CloseX onClick={() => setDrawer(null)} label="Close panel" />
              </div>
                  <div className="h-[calc(100%-34px)]">
                    {drawer === 'hierarchy' ? hierarchy : drawer === 'prefabs' ? prefabs : <BottomPanel onOpenDocs={() => { setTab('docs'); setDrawer(null); }} />}
                  </div>
            </div>
          ) : null}

          {drawer === 'inspector' ? (
            <>
              <button type="button" className="flex-1 bg-black/50" aria-label="Close panel" onClick={() => setDrawer(null)} />
              <div className="h-full w-[320px] max-w-[88vw] border-l border-[#232833] bg-[#11141a] shadow-2xl">
                <div className="flex items-center justify-between border-b border-[#232833] bg-[#151922] px-2 py-1.5">
                  <span className="text-[11px] uppercase tracking-wide text-slate-400">Inspector</span>
                  <CloseX onClick={() => setDrawer(null)} label="Close panel" />
                </div>
                <div className="h-[calc(100%-34px)]">{inspector}</div>
              </div>
            </>
          ) : (
            <button type="button" className="flex-1 bg-black/50" aria-label="Close panel" onClick={() => setDrawer(null)} />
          )}
        </div>
      ) : null}

      {/* boot / error overlay */}
      {core.loading || core.loadError ? (
        <div className={cn('absolute inset-0 z-50 flex items-center justify-center bg-[#0b0d11]/90 px-6 backdrop-blur')}>
          <div className="w-full max-w-md rounded-lg border border-[#2a3140] bg-[#12161d] p-5 text-center shadow-2xl">
            {core.loadError ? (
              <>
                <TriangleAlert className="mx-auto h-7 w-7 text-amber-300" />
                <h2 className="mt-2 text-[14px] font-semibold text-slate-100">The 3D engine could not start</h2>
                <p className="mt-1.5 text-[12px] leading-relaxed text-slate-400">{core.loadError}</p>
                <p className="mt-2 text-[11px] leading-relaxed text-slate-500">
                  three.js is loaded from a public CDN, so this usually means the network blocked it, or the browser has WebGL disabled.
                </p>
                <button
                  type="button"
                  onClick={() => window.location.reload()}
                  className="mt-3 rounded border border-sky-500/60 bg-sky-500/15 px-3 py-1.5 text-[12px] text-sky-200 transition-colors hover:bg-sky-500/25"
                >
                  Reload the page
                </button>
              </>
            ) : (
              <>
                <Loader className="mx-auto h-7 w-7 animate-spin text-sky-400" />
                <h2 className="mt-2 text-[14px] font-semibold text-slate-100">Starting the engine…</h2>
                <p className="mt-1.5 text-[12px] text-slate-400">
                  Loading three.js and its controls, loaders and exporters from the CDN, then building the demo scene.
                </p>
                <p className="mt-2 font-mono text-[10px] text-slate-600">{core.threeSourceLabel}</p>
              </>
            )}
          </div>
        </div>
      ) : null}
    </div>
  );
}
