/**
 * Remote Control panel — connect the running engine to an outside command server.
 *
 * Three transports:
 *   • Mock server  — a built-in simulator, so the whole feature can be demoed with
 *                    no backend at all (streams realistic command packets in).
 *   • WebSocket    — speaks the documented JSON packet protocol.
 *   • HTTP polling — POSTs to any endpoint every 2s and executes returned commands;
 *                    this is what the bundled PHP bridge expects.
 *
 * The same dispatcher that answers remote packets also answers window.postMessage
 * commands, so an embedding page can drive the editor too.
 */

import { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowDownLeft,
  ArrowUpRight,
  Ban,
  Cable,
  Info,
  Link2,
  Send,
  Server,
  Trash2,
  Unplug,
  Wifi,
  Zap,
} from 'lucide-react';
import { useEngine, useRemoteTick } from '@/engine/engine-context';
import { HANDSHAKE } from '@/engine/bridge';
import { Button, CodeBlock, IconButton, Tag } from './ui';
import { cn } from '@/lib/utils';
import type { RemoteLogEntry } from '@/engine/types';

const POSTMESSAGE_DEMO = `// From a parent page (or the browser console on this page):
const frame = document.querySelector('iframe').contentWindow;

frame.postMessage({
  target: 'engine',
  id: 1,
  method: 'setPosition',
  args: ['<selected>', 0, 4, 0]
}, '*');

// The reply comes back as:
// { target: 'parent', id: 1, ok: true, result: true }

// Any API method works — createObject, animate, attachScript, play, emitEvent…`;

const CONTROL_PHP_SUMMARY = `POST {endpoint}?action=poll      engine asks for commands   → {commands:[…]}
POST {endpoint}?action=push      queue a command for engine ({method, args})
POST {endpoint}?action=response  engine reports the result

# queue a command with curl:
curl -X POST "https://your-host/engine_bridge.php?action=push" \\
     -H "Content-Type: application/json" \\
     -d '{"method":"move","args":["<selected>",0,2,0]}'`;

export function RemoteControlPanel() {
  const core = useEngine();
  useRemoteTick();
  const remote = core.remote;

  const [mode, setMode] = useState<'mock' | 'websocket' | 'poll'>(remote?.status.mode ?? 'mock');
  const [url, setUrl] = useState(remote?.status.url ?? 'ws://localhost:8099/ws');
  const [packet, setPacket] = useState('{\n  "method": "setColor",\n  "args": ["<selected>", "#22d3ee"]\n}');
  const [handled, setHandled] = useState(0);
  const replies = useRef<Array<{ id: any; ok: boolean; result: string; at: number }>>([]);
  const [replyTick, setReplyTick] = useState(0);

  useEffect(() => {
    if (!remote) return;
    remote.setMode(mode);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode]);

  // collect postMessage replies sent back to this window
  useEffect(() => {
    const onMessage = (event: MessageEvent) => {
      const data: any = event.data;
      if (!data || data.target !== 'parent' || !data.engine) return;
      setHandled((n) => n + 1);
      replies.current = [
        { id: data.id, ok: !!data.ok, result: JSON.stringify(data.result ?? data.error), at: Date.now() },
        ...replies.current,
      ].slice(0, 8);
      setReplyTick((n) => n + 1);
    };
    window.addEventListener('message', onMessage);
    return () => window.removeEventListener('message', onMessage);
  }, []);

  const log = remote?.getLog() ?? [];
  const status = remote?.status ?? { mode: 'mock', status: 'disconnected', url: '', detail: '' };
  void replyTick;

  const statusTone =
    status.status === 'connected' ? 'emerald' : status.status === 'connecting' ? 'amber' : status.status === 'error' ? 'rose' : 'neutral';

  const sendPostMessage = (method: string, args: any[]) => {
    const id = Math.floor(Math.random() * 100000);
    window.postMessage({ target: 'engine', id, method, args, replyInWindow: true }, '*');
  };

  const grouped = useMemo(() => log.slice(-120), [log]);

  return (
    <div className="flex h-full min-h-0 flex-col bg-[#0e1116]">
      <header className="flex shrink-0 flex-wrap items-center gap-2 border-b border-[#232833] bg-[#151922] px-3 py-2">
        <Server className="h-4 w-4 text-sky-400" />
        <h2 className="text-[12px] font-semibold tracking-tight text-slate-200">Remote control bridge</h2>
        <Tag tone={statusTone as any}>{status.status}</Tag>
        <Tag tone="neutral">{status.mode}</Tag>
        <span className="font-mono text-[10px] text-slate-500">postMessage handled: {handled}</span>
        <div className="ml-auto">
          <IconButton icon={Trash2} label="Clear bridge log" onClick={() => remote?.clearLog()} />
        </div>
      </header>

      <div className="min-h-0 flex-1 overflow-y-auto px-3 py-3">
        <div className="grid gap-4 lg:grid-cols-2">
          {/* transport */}
          <div className="space-y-3">
            <div className="rounded border border-[#262d38] bg-[#12161d] p-2.5">
              <h3 className="mb-2 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-slate-400">
                <Cable className="h-3.5 w-3.5" /> Transport
              </h3>
              <div className="mb-2 flex flex-wrap gap-1">
                {(
                  [
                    { value: 'mock', label: 'Built-in mock server', icon: Zap },
                    { value: 'websocket', label: 'WebSocket', icon: Wifi },
                    { value: 'poll', label: 'HTTP polling', icon: Server },
                  ] as const
                ).map((option) => (
                  <button
                    key={option.value}
                    type="button"
                    onClick={() => setMode(option.value)}
                    className={cn(
                      'inline-flex items-center gap-1 rounded border px-2 py-1 text-[10px] transition-colors',
                      mode === option.value
                        ? 'border-sky-500/50 bg-sky-500/15 text-sky-200'
                        : 'border-[#262d38] text-slate-400 hover:border-[#39424f] hover:text-slate-200',
                    )}
                  >
                    <option.icon className="h-3 w-3" />
                    {option.label}
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-1.5">
                <input
                  value={url}
                  onChange={(e) => {
                    setUrl(e.target.value);
                    remote?.setUrl(e.target.value);
                  }}
                  placeholder={mode === 'poll' ? 'https://your-host/engine_bridge.php?action=poll' : 'ws://localhost:8099/ws'}
                  disabled={mode === 'mock'}
                  className="min-w-0 flex-1 rounded border border-[#2a3140] bg-[#0c0f14] px-2 py-1 font-mono text-[11px] text-slate-200 outline-none placeholder:text-slate-600 focus:border-sky-500 disabled:opacity-50"
                />
                {status.status === 'disconnected' || status.status === 'error' ? (
                  <Button icon={Link2} variant="primary" onClick={() => remote?.connect(mode === 'mock' ? undefined : url)}>
                    Connect
                  </Button>
                ) : (
                  <Button icon={Unplug} variant="danger" onClick={() => remote?.disconnect()}>
                    Disconnect
                  </Button>
                )}
              </div>

              <p className="mt-2 text-[10px] leading-relaxed text-slate-500">
                {status.detail || 'Not connected.'}
                {mode === 'mock' ? ' The mock server streams command packets so you can watch the panels work without any backend.' : ''}
              </p>

              <div className="mt-2 flex flex-wrap gap-1.5">
                <Button size="sm" onClick={() => remote?.send(HANDSHAKE)}>
                  Send handshake
                </Button>
                <Button size="sm" onClick={() => remote?.send({ type: 'command', method: 'getStats', args: [] })}>
                  Send getStats
                </Button>
                <Button
                  size="sm"
                  onClick={() => {
                    try {
                      remote?.send(JSON.parse(packet));
                    } catch {
                      core.log('error', 'That manual packet is not valid JSON.');
                    }
                  }}
                >
                  Send packet below
                </Button>
              </div>
            </div>

            {/* manual packet */}
            <div className="rounded border border-[#262d38] bg-[#12161d] p-2.5">
              <h3 className="mb-2 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-slate-400">
                <Send className="h-3.5 w-3.5" /> Manual packet
              </h3>
              <textarea
                value={packet}
                onChange={(e) => setPacket(e.target.value)}
                spellCheck={false}
                rows={5}
                className="w-full resize-y rounded border border-[#2a3140] bg-[#0b0e13] px-2 py-1.5 font-mono text-[11px] text-slate-200 outline-none focus:border-sky-500"
              />
              <p className="mt-1 text-[10px] text-slate-500">
                Packets use the same method names as the API table: <span className="font-mono text-slate-400">{'{ "method": "animate", "args": [id, {…}] }'}</span>
              </p>
            </div>

            {/* postMessage */}
            <div className="rounded border border-[#262d38] bg-[#12161d] p-2.5">
              <h3 className="mb-2 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-slate-400">
                <ArrowDownLeft className="h-3.5 w-3.5" /> Embedded page bridge (window.postMessage)
              </h3>
              <p className="mb-2 text-[11px] leading-relaxed text-slate-400">
                The engine listens for <span className="font-mono text-slate-300">{'{ target: "engine", method, args }'}</span> messages from any frame
                and replies with <span className="font-mono text-slate-300">{'{ target: "parent", ok, result }'}</span>. Try it right here:
              </p>
              <div className="flex flex-wrap gap-1.5">
                <Button size="sm" icon={Send} onClick={() => sendPostMessage('ping', [])}>
                  ping
                </Button>
                <Button size="sm" icon={Send} onClick={() => sendPostMessage('listObjects', [])}>
                  listObjects
                </Button>
                <Button
                  size="sm"
                  icon={Send}
                  onClick={() => sendPostMessage('createObject', ['From postMessage', 'Torus'])}
                >
                  createObject
                </Button>
                <Button size="sm" icon={Send} onClick={() => sendPostMessage('setColor', ['<selected>', '#ff8ac4'])}>
                  setColor selected
                </Button>
                <Button size="sm" icon={Send} onClick={() => sendPostMessage('play', [])}>
                  play
                </Button>
              </div>
              <div className="mt-2 max-h-[160px] space-y-1 overflow-y-auto">
                {replies.current.length === 0 ? (
                  <p className="text-[10px] text-slate-500">Replies to your postMessage calls appear here.</p>
                ) : (
                  replies.current.map((r) => (
                    <div key={`${r.id}-${r.at}`} className="rounded border border-[#242a35] bg-[#0b0e13] px-2 py-1">
                      <p className="flex items-center gap-1.5 font-mono text-[10px] text-slate-400">
                        <ArrowUpRight className="h-3 w-3 text-sky-300" /> id {String(r.id)} {r.ok ? 'ok' : 'failed'}
                      </p>
                      <pre className="overflow-x-auto font-mono text-[10px] text-slate-300">{r.result}</pre>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* log + protocol */}
          <div className="space-y-3">
            <div className="rounded border border-[#262d38] bg-[#12161d]">
              <div className="flex items-center gap-1.5 border-b border-[#20252e] px-2.5 py-1.5">
                <Cable className="h-3.5 w-3.5 text-sky-300" />
                <span className="text-[11px] font-semibold text-slate-200">Traffic log</span>
                <span className="ml-auto font-mono text-[10px] text-slate-500">{log.length} packets</span>
              </div>
              <div className="max-h-[340px] min-h-[160px] overflow-y-auto px-2 py-1.5">
                {grouped.length === 0 ? (
                  <p className="flex items-center gap-1.5 px-1 py-2 text-[11px] text-slate-500">
                    <Info className="h-3 w-3" /> Nothing yet — connect the mock server to see the handshake and command stream.
                  </p>
                ) : (
                  grouped.map((entry) => <LogRow key={entry.id} entry={entry} />)
                )}
              </div>
            </div>

            <CodeBlock
              code={POSTMESSAGE_DEMO}
              title="parent-page.js — embed & control the editor"
              note="Works from any origin: the bridge answers every frame that sends a command."
            />

            <CodeBlock
              code={CONTROL_PHP_SUMMARY}
              title="server side (HTTP polling contract)"
              note="The full engine_bridge.php and control.php sources are in the API & Docs tab → PHP bridge."
            />

            <div className="rounded border border-[#262d38] bg-[#12161d] p-2.5">
              <h3 className="mb-1.5 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-slate-400">
                <Ban className="h-3.5 w-3.5" /> Notes
              </h3>
              <ul className="space-y-1 text-[11px] leading-relaxed text-slate-400">
                <li>Commands run through the same dispatcher as <span className="font-mono text-slate-300">window.Engine</span>, so anything documented there can be sent remotely.</li>
                <li><span className="font-mono text-slate-300">"&lt;selected&gt;"</span> in an argument resolves to the object selected in the Hierarchy.</li>
                <li>Every inbound packet is logged with its reply — a failed call never crashes the engine, it reports back with <span className="font-mono text-slate-300">ok: false</span>.</li>
                <li>A raw WebSocket server cannot be written in plain PHP; the shipped bridge uses polling. See the docs for the packet format if you want to run your own relay.</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function LogRow({ entry }: { entry: RemoteLogEntry }) {
  const styles =
    entry.direction === 'in'
      ? { icon: ArrowDownLeft, cls: 'text-emerald-300', label: 'IN' }
      : entry.direction === 'out'
        ? { icon: ArrowUpRight, cls: 'text-sky-300', label: 'OUT' }
        : { icon: Info, cls: 'text-slate-400', label: 'SYS' };
  const Icon = styles.icon;
  return (
    <div className="flex items-start gap-2 border-b border-[#161b23] px-1 py-1 font-mono text-[10px] last:border-0">
      <Icon className={cn('mt-[2px] h-3 w-3 shrink-0', styles.cls)} />
      <span className={cn('w-8 shrink-0', styles.cls)}>{styles.label}</span>
      <span className="min-w-0 flex-1 whitespace-pre-wrap break-all text-slate-300">{entry.text}</span>
    </div>
  );
}
