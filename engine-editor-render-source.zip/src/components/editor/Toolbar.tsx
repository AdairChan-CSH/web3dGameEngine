/**
 * Top toolbar: project menu, playback, gizmo modes, snap, undo/redo and the
 * live renderer statistics readout.
 */

import { useRef } from 'react';
import {
  Activity,
  Boxes,
  Camera,
  Circle,
  Cone,
  Copy,
  Cylinder,
  Download,
  Eye,
  FolderOpen,
  Layers,
  Lightbulb,
  Loader,
  Package,
  Pause,
  Play,
  Redo2,
  RotateCw,
  Save,
  Scaling,
  SlidersHorizontal,
  Sparkles,
  Square,
  Terminal,
  Undo2,
  Upload,
  Box,
  Move,
  Magnet,
  PackagePlus,
} from 'lucide-react';
import { useEngine, useEngineStats, useEngineVersion, useIsCompact } from '@/engine/engine-context';
import { Button, IconButton, Menu, Segmented, Tag, round, type MenuItem } from './ui';
import type { ObjectType } from '@/engine/types';

const ADD_ITEMS: Array<{ type: ObjectType; icon: any }> = [
  { type: 'Cube', icon: Box },
  { type: 'Sphere', icon: Circle },
  { type: 'Plane', icon: Square },
  { type: 'Cylinder', icon: Cylinder },
  { type: 'Torus', icon: Circle },
  { type: 'Capsule', icon: Package },
  { type: 'Cone', icon: Cone },
  { type: 'Light', icon: Lightbulb },
  { type: 'Camera', icon: Camera },
  { type: 'Empty', icon: Boxes },
];

export function Toolbar({
  onOpenPanel,
  compact,
}: {
  onOpenPanel: (panel: 'hierarchy' | 'prefabs' | 'inspector' | 'bottom') => void;
  compact: boolean;
}) {
  const core = useEngine();
  useEngineVersion();
  const stats = useEngineStats();
  const isCompact = useIsCompact(1024);
  const narrow = compact || isCompact;

  const projectInput = useRef<HTMLInputElement>(null);
  const modelInput = useRef<HTMLInputElement>(null);
  const textureInput = useRef<HTMLInputElement>(null);

  const savedProjects = core.listProjects();
  const selected = core.getSelected();

  const fileMenu: MenuItem[] = [
    { label: 'New project (demo scene)', icon: Sparkles, onClick: () => core.newProject() },
    { label: 'Open saved project…', icon: FolderOpen, onClick: () => onOpenPanel('bottom') , hint: 'Saved projects are listed in the Projects menu' },
    { separator: true },
    { label: 'Save project', icon: Save, shortcut: 'Ctrl+S', onClick: () => core.saveProject(core.projectName) },
    { label: 'Export project as JSON', icon: Download, onClick: () => core.exportProjectFile() },
    { label: 'Import project JSON…', icon: Upload, onClick: () => projectInput.current?.click() },
    { separator: true },
    { label: 'Import 3D model (.glb/.gltf/.obj)…', icon: Package, onClick: () => modelInput.current?.click() },
    { label: 'Apply texture to selection (.png/.jpg)…', icon: Camera, onClick: () => textureInput.current?.click() },
    { separator: true },
    { label: 'Export scene as glTF (.glb)', icon: Download, onClick: () => core.exportGLTF() },
  ];

  const addItems: MenuItem[] = [
    ...ADD_ITEMS.map((item) => ({
      label: item.type,
      icon: item.icon,
      onClick: () => core.createObject(item.type),
    })),
    { separator: true },
    { label: 'Import model…', icon: Package, onClick: () => modelInput.current?.click() },
  ];

  const projectItems: MenuItem[] = [
    { label: `Save as "${core.projectName}"`, icon: Save, onClick: () => core.saveProject(core.projectName) },
    { separator: true },
    ...(savedProjects.length
      ? savedProjects.map((name) => ({
          label: name,
          icon: FolderOpen,
          onClick: () => core.loadProject(name),
          checked: name === core.projectName,
        }))
      : [{ label: 'No saved projects yet', disabled: true }]),
  ];

  const readFile = async (input: HTMLInputElement, handler: (file: File) => Promise<unknown>) => {
    const file = input.files?.[0];
    input.value = '';
    if (!file) return;
    try {
      await handler(file);
    } catch (err) {
      core.log('error', `Import failed: ${err instanceof Error ? err.message : String(err)}`);
    }
  };

  const fpsTone = stats.fps >= 50 ? 'text-emerald-300' : stats.fps >= 28 ? 'text-amber-300' : 'text-rose-300';

  return (
    <header className="z-30 flex shrink-0 flex-wrap items-center gap-2 border-b border-[#232833] bg-[#12161d] px-2 py-1.5">
      <input
        ref={projectInput}
        type="file"
        accept=".json,application/json"
        className="hidden"
        onChange={(e) => { const el = e.target; void readFile(el, (f) => core.importProjectFile(f)); }}
      />
      <input
        ref={modelInput}
        type="file"
        accept=".glb,.gltf,.obj"
        multiple={false}
        className="hidden"
        onChange={(e) => { const el = e.target; void readFile(el, (f) => core.importModelFile(f)); }}
      />
      <input
        ref={textureInput}
        type="file"
        accept="image/png,image/jpeg,image/webp"
        className="hidden"
        onChange={(e) => { const el = e.target; void readFile(el, (f) => core.importTextureFile(f)); }}
      />

      {/* brand */}
      <div className="flex items-center gap-2 pr-1">
        <span className="flex h-7 w-7 items-center justify-center rounded-md bg-gradient-to-br from-sky-500 to-indigo-600 shadow-lg shadow-sky-900/40">
          <Boxes className="h-4 w-4 text-white" />
        </span>
        <div className="hidden leading-tight sm:block">
          <p className="text-[13px] font-semibold tracking-tight text-slate-100">WebForge</p>
          <p className="font-mono text-[9px] uppercase tracking-[0.16em] text-slate-500">3D engine</p>
        </div>
      </div>

      <div className="flex items-center gap-1">
        <Menu items={fileMenu} trigger={<span className="flex items-center gap-1">File</span>} />
        <Menu items={addItems} trigger={<span className="flex items-center gap-1">Add Object</span>} width={210} />
        <Menu items={projectItems} trigger={<span className="flex items-center gap-1">Projects</span>} width={250} />
      </div>

      <div className="mx-1 hidden h-6 w-px bg-[#252b36] sm:block" />

      {/* playback */}
      <div className="flex items-center gap-1">
        <Button
          icon={Play}
          variant={core.playState === 'playing' ? 'primary' : 'default'}
          onClick={() => core.play()}
          title="Play (runs scripts + physics)"
          active={core.playState === 'playing'}
        >
          {!narrow ? 'Play' : ''}
        </Button>
        <IconButton
          icon={Pause}
          label="Pause"
          onClick={() => core.pause()}
          active={core.playState === 'paused'}
          disabled={core.playState !== 'playing'}
        />
        <IconButton icon={Square} label="Stop (restores the pre-play scene)" onClick={() => core.stop()} disabled={core.playState === 'stopped'} />
      </div>

      <div className="mx-1 hidden h-6 w-px bg-[#252b36] md:block" />

      {/* gizmo */}
      <div className="flex items-center gap-1">
        <Segmented
          value={core.gizmoMode}
          onChange={(v) => core.setGizmoMode(v as any)}
          options={[
            { value: 'translate', label: 'Move', icon: Move, title: 'Translate gizmo (W)' },
            { value: 'rotate', label: 'Rotate', icon: RotateCw, title: 'Rotate gizmo (E)' },
            { value: 'scale', label: 'Scale', icon: Scaling, title: 'Scale gizmo (R)' },
          ]}
        />
        <IconButton
          icon={Magnet}
          label="Toggle snapping"
          active={core.snapEnabled}
          onClick={() => core.setSnap(!core.snapEnabled)}
        />
        <select
          value={String(core.snapSize)}
          onChange={(e) => core.setSnap(core.snapEnabled, parseFloat(e.target.value))}
          title="Snap step"
          className="rounded border border-[#2a3140] bg-[#0c0f14] px-1 py-1 font-mono text-[10px] text-slate-300 outline-none focus:border-sky-500"
        >
          {[0.1, 0.25, 0.5, 1, 2].map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
      </div>

      <div className="mx-1 hidden h-6 w-px bg-[#252b36] sm:block" />

      <div className="flex items-center gap-1">
        <IconButton icon={Undo2} label={core.canUndo() ? `Undo ${core.undoLabel()}` : 'Undo'} onClick={() => core.undo()} disabled={!core.canUndo()} />
        <IconButton icon={Redo2} label={core.canRedo() ? `Redo ${core.redoLabel()}` : 'Redo'} onClick={() => core.redo()} disabled={!core.canRedo()} />
        <IconButton icon={Copy} label="Duplicate selection (Ctrl+D)" onClick={() => selected && core.duplicateObject(selected.id)} disabled={!selected} />
        <IconButton icon={Eye} label="Focus selection (F)" onClick={() => core.focusSelected()} />
        <IconButton
          icon={Terminal}
          label="Delete selection"
          tone="danger"
          onClick={() => selected && core.deleteObject(selected.id)}
          disabled={!selected}
        />
      </div>

      {narrow ? (
        <div className="ml-auto flex items-center gap-1">
          <IconButton icon={Layers} label="Hierarchy" onClick={() => onOpenPanel('hierarchy')} />
          <IconButton icon={PackagePlus} label="Prefabs" onClick={() => onOpenPanel('prefabs')} />
          <IconButton icon={SlidersHorizontal} label="Inspector" onClick={() => onOpenPanel('inspector')} />
          <IconButton icon={Terminal} label="Console & scripts" onClick={() => onOpenPanel('bottom')} />
        </div>
      ) : null}

      {/* stats */}
      <div className="ml-auto flex flex-wrap items-center gap-2 pl-2">
        <span className="hidden max-w-[190px] truncate rounded border border-[#2a3140] bg-[#0f131a] px-2 py-1 text-[10px] text-slate-400 lg:inline-flex">
          {core.projectName}
        </span>
        <div className="flex items-center gap-2 rounded border border-[#242a35] bg-[#0f131a] px-2 py-1 font-mono text-[10px]">
          <span className={fpsTone}>{stats.fps} fps</span>
          <span className="text-slate-600">|</span>
          <span className="text-slate-400" title="Draw calls">{stats.drawCalls} dc</span>
          <span className="text-slate-600">|</span>
          <span className="text-slate-400" title="Triangles">{formatCount(stats.triangles)} tris</span>
          <span className="text-slate-600">|</span>
          <span className="text-slate-400" title="Objects in the scene">{stats.objects} obj</span>
          <span className="hidden text-slate-600 sm:inline">|</span>
          <span className="hidden text-slate-400 sm:inline" title="Script instances running">{stats.scripts} scr</span>
        </div>
        {core.playState === 'playing' ? (
          <Tag tone="emerald">running</Tag>
        ) : core.playState === 'paused' ? (
          <Tag tone="amber">paused</Tag>
        ) : (
          <Tag tone="neutral">edit</Tag>
        )}
        {core.loading ? (
          <span className="flex items-center gap-1 text-[10px] text-amber-300">
            <Loader className="h-3 w-3 animate-spin" /> loading three.js
          </span>
        ) : (
          <span className="hidden font-mono text-[9px] text-slate-600 xl:inline" title="three.js build in use">
            <Activity className="mr-1 inline h-3 w-3" />
            {core.threeSourceLabel}
          </span>
        )}
      </div>
    </header>
  );
}

function formatCount(n: number): string {
  if (n >= 1000000) return `${round(n / 1000000)}M`;
  if (n >= 1000) return `${Math.round(n / 100) / 10}k`;
  return String(n ?? 0);
}
