/**
 * Bottom dock: Console + Script Editor.
 *
 * The console collects everything the engine and user scripts say, with
 * per-script line numbers. The script editor is a monospace editor with a
 * syntax-highlighted layer, line numbers and live parsing — user code is
 * parsed by the engine's own interpreter, never evaluated as JavaScript.
 */

import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import {
  Activity,
  ChevronDown,
  Code2,
  Copy,
  Eraser,
  FilePlus2,
  Info,
  Link2,
  OctagonAlert,
  Play,
  ScrollText,
  Terminal,
  Trash2,
  TriangleAlert,
} from 'lucide-react';
import { useEngine, useEngineVersion } from '@/engine/engine-context';
import { Button, IconButton, TabStrip, Tag, formatTime } from './ui';
import { cn } from '@/lib/utils';
import type { EngineCore } from '@/engine/core';
import type { LogEntry, LogLevel, SceneHealthGizmo, SceneHealthReport, SceneRepairReport } from '@/engine/types';

const FONT_STYLE = {
  fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace',
  fontSize: '12px',
  lineHeight: '18px',
  tabSize: 2,
} as const;

const LEVEL_STYLES: Record<LogLevel, { row: string; badge: string; label: string }> = {
  log: { row: 'text-slate-300', badge: 'text-slate-500', label: 'LOG' },
  info: { row: 'text-sky-200', badge: 'text-sky-400', label: 'INF' },
  warn: { row: 'text-amber-200', badge: 'text-amber-400', label: 'WRN' },
  error: { row: 'text-rose-200 bg-rose-500/5', badge: 'text-rose-400', label: 'ERR' },
};

export function BottomPanel({ onOpenDocs }: { onOpenDocs?: () => void }) {
  const core = useEngine();
  useEngineVersion();
  const [tab, setTab] = useState<'console' | 'editor'>('console');
  const [jump, setJump] = useState<{ line: number; token: number } | null>(null);

  const errorCount = core.logs.filter((l) => l.level === 'error').length;

  const jumpTo = (entry: LogEntry) => {
    if (!entry.script) return;
    const asset = core.getScript(entry.script);
    if (!asset) return;
    core.setCurrentScript(asset.id);
    setTab('editor');
    setJump({ line: entry.line ?? 1, token: Date.now() });
  };

  /** Console toolbar action: run the engine's scene integrity check. */
  const runHealthCheck = () => {
    try {
      logHealthReport(core, core.checkSceneHealth());
    } catch (err) {
      core.log('error', `Scene health check failed: ${err instanceof Error ? err.message : String(err)}`);
    }
  };

  /** Console toolbar action: audit the scene and apply the three safe repairs. */
  const runRepair = () => {
    try {
      logRepairReport(core, core.repairScene());
    } catch (err) {
      core.log('error', `Scene repair failed: ${err instanceof Error ? err.message : String(err)}`);
    }
  };

  return (
    <div className="flex h-full min-h-0 flex-col bg-[#0e1116]">
      <TabStrip
        tabs={[
          { value: 'console', label: 'Console', icon: Terminal, badge: errorCount ? String(errorCount) : undefined },
          { value: 'editor', label: 'Script Editor', icon: Code2 },
        ]}
        value={tab}
        onChange={(v) => setTab(v as 'console' | 'editor')}
        right={
          <>
            {tab === 'console' ? (
              <>
                <span className="hidden font-mono text-[10px] text-slate-500 sm:inline">{core.logs.length} lines</span>
                <IconButton icon={Copy} label="Copy all log lines" onClick={() => copyLogs(core.logs)} />
                <IconButton icon={Eraser} label="Clear console" onClick={() => core.clearConsole()} />
                <Button size="sm" icon={Activity} onClick={runHealthCheck} title="Run a scene integrity check and log the report">
                  Health
                </Button>
                <Button
                  size="sm"
                  icon={Link2}
                  onClick={runRepair}
                  title="Fix detached scene nodes, a dead selection and the gizmo binding — then log the report"
                >
                  Repair
                </Button>
              </>
            ) : (
              <Button size="sm" icon={ScrollText} onClick={() => onOpenDocs?.()} title="Open the scripting reference">
                Scripting reference
              </Button>
            )}
          </>
        }
      />
      <div className="min-h-0 flex-1">
        {tab === 'console' ? <ConsoleView onJump={jumpTo} /> : <ScriptEditor jump={jump} onOpenDocs={onOpenDocs} />}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------- console */

function ConsoleView({ onJump }: { onJump: (entry: LogEntry) => void }) {
  const core = useEngine();
  const [filter, setFilter] = useState<'all' | LogLevel>('all');
  const [autoScroll, setAutoScroll] = useState(true);
  const scroller = useRef<HTMLDivElement>(null);

  const entries = useMemo(
    () => (filter === 'all' ? core.logs : core.logs.filter((l) => l.level === filter)),
    [core.logs, filter],
  );

  useEffect(() => {
    if (!autoScroll || !scroller.current) return;
    scroller.current.scrollTop = scroller.current.scrollHeight;
  }, [entries.length, autoScroll]);

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex shrink-0 items-center gap-1.5 border-b border-[#1e232c] px-2 py-1">
        {(['all', 'log', 'info', 'warn', 'error'] as const).map((level) => (
          <button
            key={level}
            type="button"
            onClick={() => setFilter(level)}
            className={cn(
              'rounded px-1.5 py-0.5 font-mono text-[10px] uppercase transition-colors',
              filter === level ? 'bg-sky-500/20 text-sky-200' : 'text-slate-500 hover:bg-white/5 hover:text-slate-300',
            )}
          >
            {level}
            {level !== 'all' && core.logs.some((l) => l.level === level)
              ? ` ${core.logs.filter((l) => l.level === level).length}`
              : ''}
          </button>
        ))}
        <label className="ml-auto flex cursor-pointer items-center gap-1 text-[10px] text-slate-500">
          <input type="checkbox" checked={autoScroll} onChange={(e) => setAutoScroll(e.target.checked)} className="accent-sky-500" />
          follow
        </label>
      </div>

      <div ref={scroller} className="min-h-0 flex-1 overflow-y-auto font-mono text-[11px]">
        {entries.length === 0 ? (
          <p className="px-3 py-3 text-[11px] text-slate-500">
            Nothing logged yet. Scripts write here with <span className="text-slate-300">Debug.log("…")</span>, and the engine reports
            API calls, play-mode events and script errors.
          </p>
        ) : (
          entries.map((entry) => {
            const style = LEVEL_STYLES[entry.level] ?? LEVEL_STYLES.log;
            const Icon = entry.level === 'error' ? OctagonAlert : entry.level === 'warn' ? TriangleAlert : entry.level === 'info' ? Info : undefined;
            return (
              <button
                key={entry.id}
                type="button"
                onClick={() => onJump(entry)}
                className={cn(
                  'flex w-full items-start gap-2 border-b border-[#141821] px-2 py-[3px] text-left transition-colors hover:bg-white/5',
                  style.row,
                )}
                title={entry.script ? 'Open this line in the Script Editor' : undefined}
              >
                <span className="shrink-0 text-[10px] text-slate-600">{formatTime(entry.time)}</span>
                {Icon ? <Icon className={cn('mt-[2px] h-3 w-3 shrink-0', style.badge)} /> : <span className={cn('mt-[2px] shrink-0 text-[9px]', style.badge)}>•</span>}
                <span className="min-w-0 flex-1 whitespace-pre-wrap break-words">{entry.message}</span>
                {entry.script ? (
                  <span className="shrink-0 rounded border border-[#2a3140] px-1 text-[9px] text-slate-400">
                    {entry.script}
                    {entry.line ? `:${entry.line}` : ''}
                  </span>
                ) : null}
              </button>
            );
          })
        )}
      </div>
    </div>
  );
}

async function copyLogs(entries: LogEntry[]): Promise<void> {
  const text = entries.map((e) => `[${formatTime(e.time)}] ${e.level.toUpperCase()}: ${e.message}${e.script ? ` (${e.script}:${e.line ?? 0})` : ''}`).join('\n');
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    /* clipboard may be blocked — the console is still there */
  }
}

/* ------------------------------------------------------------ health check */

/** "attached to Cube (id obj_1) — target valid" / "detached". */
function describeGizmo(gizmo: SceneHealthGizmo): string {
  if (!gizmo.attached) return 'detached';
  const what = gizmo.targetName ? `${gizmo.targetName} (id ${gizmo.targetId ?? 'unknown'})` : `id ${gizmo.targetId ?? 'unknown'}`;
  return `attached to ${what} — target ${gizmo.valid ? 'valid' : 'NOT valid'}`;
}

/** Writes EngineCore.checkSceneHealth() into the console as ordinary log lines. */
function logHealthReport(core: EngineCore, report: SceneHealthReport): void {
  core.log('info', 'Scene health check');

  if (!report.ready) {
    if (core.loadError) core.log('error', `The engine could not be checked: ${core.loadError}`);
    else core.log('info', 'The engine is still loading, so the scene could not be checked yet — try again in a moment.');
    return;
  }

  // 1 — three.js nodes attached to the scene root
  if (report.detached.length) {
    core.log('warn', `Objects not attached to the scene: ${report.detached.length} problem(s) found`);
    for (const issue of report.detached) core.log('warn', `  • ${issue.name} (id ${issue.id}) — ${issue.detail}`);
  } else {
    core.log('info', 'Objects not attached to the scene: OK — every node reaches the scene root');
  }

  // 2 — the selection (and the gizmo target it drives)
  if (report.selection.length) {
    core.log('warn', `Selection: ${report.selection.length} problem(s) found`);
    for (const issue of report.selection) core.log('warn', `  • ${issue.name} (id ${issue.id}) — ${issue.detail}`);
  } else {
    core.log('info', 'Selection: OK — the selection points at a live object in the scene');
  }
  core.log('info', `Gizmo target for the selection: ${describeGizmo(report.gizmo)}`);


  // 3 — geometry
  if (report.geometry.length) {
    core.log('warn', `Objects with no geometry: ${report.geometry.length} problem(s) found`);
    for (const issue of report.geometry) core.log('warn', `  • ${issue.name} (id ${issue.id}) — ${issue.detail}`);
  } else {
    core.log('info', 'Objects with no geometry: OK — every mesh carries geometry');
  }

  // 4 — gizmo target state
  core.log(
    'info',
    `Gizmo target state: mode ${report.gizmo.mode} — ${
      report.gizmo.attached
        ? `attached to ${report.gizmo.targetName ?? '(unnamed node)'}${
            report.gizmo.targetId ? ` (id ${report.gizmo.targetId})` : ''
          }`
        : 'detached (not attached to any object)'
    }`,
  );
  if (report.gizmoIssues.length) {
    core.log('warn', `Gizmo target problems: ${report.gizmoIssues.length} problem(s) found`);
    for (const issue of report.gizmoIssues) core.log('warn', `  • ${issue.name} (id ${issue.id}) — ${issue.detail}`);
  } else {
    core.log('info', 'Gizmo target problems: none');
  }

  // summary
  if (report.total) {
    core.log('warn', `Scene health: ${report.total} problem(s) found in ${report.objectCount} object(s)`);
  } else {
    core.log('info', `Scene health: all clear — no problems found in ${report.objectCount} object(s)`);
  }
}

/**
 * Writes EngineCore.repairScene() into the console in the same shape as the health report:
 * a header, one line per fixed item, the leftovers, and a closing count.
 */
function logRepairReport(core: EngineCore, repair: SceneRepairReport): void {
  core.log('info', 'Scene repair');

  if (!repair.ready) {
    if (core.loadError) core.log('error', `The scene could not be repaired: ${core.loadError}`);
    else core.log('info', 'The engine is still loading, so the scene could not be repaired yet — try again in a moment.');
    return;
  }

  // 1 — detached three.js nodes put back under the scene root
  if (repair.reattached.length) {
    core.log('info', `Detached nodes re-attached to scene: ${repair.reattached.length} fixed`);
    for (const issue of repair.reattached) core.log('info', `  • ${issue.name} (id ${issue.id}) — re-attached to scene`);
  } else {
    core.log('info', 'Detached nodes re-attached to scene: none needed');
  }
  for (const issue of repair.unrepairable) {
    core.log('warn', `  • ${issue.name} (id ${issue.id}) — ${issue.detail}; it cannot be re-attached, so it was left as is`);
  }

  // 2 — a selection pointing at a deleted or detached object
  if (repair.selectionCleared) {
    core.log(
      'info',
      `Dead selection cleared: ${repair.selectionCleared.name} (id ${repair.selectionCleared.id}) — ${repair.selectionCleared.detail}`,
    );
  } else {
    core.log('info', 'Dead selection cleared: nothing to clear — the selection points at a live object');
  }

  // 3 — the gizmo, re-synced with the (possibly cleared) selection
  core.log('info', `Gizmo target after repair: ${describeGizmo(repair.gizmo)}`);
  core.log(
    'info',
    `Gizmo target state: mode ${repair.gizmo.mode} — ${
      repair.gizmo.attached
        ? `attached to ${repair.gizmo.targetName ?? '(unnamed node)'}${
            repair.gizmo.targetId ? ` (id ${repair.gizmo.targetId})` : ''
          }`
        : 'detached (not attached to any object)'
    }`,
  );

  // remainder — what the repair deliberately does not touch
  const manual = repair.leftForManualReview.length + repair.unrepairable.length;
  if (repair.leftForManualReview.length) {
    core.log(
      'warn',
      `Objects with no geometry left untouched: ${repair.leftForManualReview.length} still need manual attention`,
    );
    for (const issue of repair.leftForManualReview) core.log('warn', `  • ${issue.name} (id ${issue.id}) — ${issue.detail}`);
  } else {
    core.log('info', 'Objects with no geometry left untouched: none found');
  }

  // summary
  if (!repair.fixed) {
    core.log(
      'info',
      `Nothing to repair — no detached nodes and no dead selection found in ${repair.audit.objectCount} object(s)`,
    );
  }
  core.log(!repair.fixed && manual ? 'warn' : 'info', `Scene repair: ${repair.fixed} fixed, ${manual} left for manual review`);
}


/* ----------------------------------------------------------- script editor */

function ScriptEditor({ jump, onOpenDocs }: { jump: { line: number; token: number } | null; onOpenDocs?: () => void }) {
  const core = useEngine();
  useEngineVersion();

  const list = core.scriptList();
  const currentId = core.currentScriptId ?? list[0]?.id ?? null;
  const asset = list.find((s) => s.id === currentId) ?? list[0] ?? null;

  const [source, setSource] = useState(asset?.source ?? '');
  const [padLeft, setPadLeft] = useState(52);
  const taRef = useRef<HTMLTextAreaElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const gutterRef = useRef<HTMLDivElement>(null);

  // swap the buffer when another script is selected
  useEffect(() => {
    setSource(asset?.source ?? '');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [asset?.id]);

  // keep the textarea text aligned with the highlighted layer
  useLayoutEffect(() => {
    if (gutterRef.current) setPadLeft(gutterRef.current.offsetWidth + 14);
  }, [source, asset?.id]);

  // jump to a line coming from the console
  useEffect(() => {
    const ta = taRef.current;
    if (!jump || !ta) return;
    const lines = ta.value.split('\n');
    const index = Math.max(0, Math.min(jump.line - 1, lines.length - 1));
    let offset = 0;
    for (let i = 0; i < index; i++) offset += lines[i].length + 1;
    ta.focus();
    ta.setSelectionRange(offset, offset + (lines[index]?.length ?? 0));
    const target = Math.max(0, (index - 3) * 18);
    ta.scrollTop = target;
    if (scrollRef.current) scrollRef.current.scrollTop = target;
  }, [jump]);

  const attachedCount = core.objectsOrEmpty().filter((o) => o.scripts.some((i) => i.scriptName === asset?.name)).length;
  const lines = source.split('\n');
  const highlighted = useMemo(() => highlightScript(source), [source]);

  const update = (value: string) => {
    setSource(value);
    if (asset) core.setScriptSource(asset.id, value);
  };

  return (
    <div className="flex h-full min-h-0 flex-col">
      {/* script tabs + actions */}
      <div className="flex shrink-0 items-center gap-1 overflow-x-auto border-b border-[#1e232c] px-1.5 py-1">
        {list.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => core.setCurrentScript(item.id)}
            className={cn(
              'flex shrink-0 items-center gap-1 rounded border px-1.5 py-0.5 font-mono text-[10px] transition-colors',
              item.id === asset?.id
                ? 'border-sky-500/50 bg-sky-500/15 text-sky-100'
                : 'border-[#262d38] text-slate-400 hover:border-[#39424f] hover:text-slate-200',
            )}
            title={item.error ? `Error on line ${item.error.line}: ${item.error.message}` : 'Parses cleanly'}
          >
            {item.error ? <span className="h-1.5 w-1.5 rounded-full bg-rose-400" /> : <span className="h-1.5 w-1.5 rounded-full bg-emerald-400/70" />}
            {item.name}
          </button>
        ))}
        <span className="ml-1 flex shrink-0 items-center gap-1">
          <IconButton
            icon={FilePlus2}
            label="New script"
            onClick={() => {
              const created = core.createScript();
              core.setCurrentScript(created.id);
            }}
          />
          <IconButton
            icon={Trash2}
            label="Delete this script"
            tone="danger"
            disabled={!asset}
            onClick={() => {
              if (!asset) return;
              core.deleteScript(asset.id);
              const next = core.scriptList()[0];
              core.setCurrentScript(next ? next.id : null);
            }}
          />
          {asset ? (
            <Button
              size="sm"
              icon={Link2}
              disabled={!core.selectedId}
              title="Attach this script to the selected object"
              onClick={() => {
                const selected = core.getSelected();
                if (selected && asset) {
                  core.attachScript(selected, asset.name);
                  core.log('log', `Attached ${asset.name} to ${selected.name}`);
                }
              }}
            >
              Attach to selection
            </Button>
          ) : null}
        </span>
        <span className="ml-auto flex shrink-0 items-center gap-1 pr-1">
          {asset?.error ? (
            <Tag tone="rose">line {asset.error.line}</Tag>
          ) : (
            <Tag tone="emerald">parses cleanly</Tag>
          )}
          <Tag tone="neutral">on {attachedCount} object{attachedCount === 1 ? '' : 's'}</Tag>
        </span>
      </div>

      {/* error bar */}
      {asset?.error ? (
        <div className="shrink-0 border-b border-rose-500/30 bg-rose-500/10 px-2.5 py-1 font-mono text-[10px] text-rose-200">
          line {asset.error.line}: {asset.error.message}
        </div>
      ) : null}

      {/* editor */}
      {asset ? (
        <div className="relative min-h-0 flex-1 overflow-hidden bg-[#0b0e13]" onClick={() => taRef.current?.focus()}>
          <div ref={scrollRef} className="pointer-events-none absolute inset-0 overflow-hidden">
            <div className="flex min-h-full w-max min-w-full">
              <div
                ref={gutterRef}
                className="sticky left-0 z-10 select-none border-r border-[#1a1f28] bg-[#0b0e13] px-2 py-2 text-right text-[11px] text-slate-600"
                style={{ lineHeight: FONT_STYLE.lineHeight }}
              >
                {lines.map((_, i) => (
                  <div key={i}>{i + 1}</div>
                ))}
              </div>
              <pre className="px-3 py-2 text-slate-300" style={FONT_STYLE}>
                <code dangerouslySetInnerHTML={{ __html: highlighted }} />
              </pre>
            </div>
          </div>
          <textarea
            ref={taRef}
            value={source}
            spellCheck={false}
            wrap="off"
            onChange={(e) => update(e.target.value)}
            onScroll={(e) => {
              if (!scrollRef.current) return;
              scrollRef.current.scrollTop = e.currentTarget.scrollTop;
              scrollRef.current.scrollLeft = e.currentTarget.scrollLeft;
            }}
            onKeyDown={(e) => {
              if (e.key === 'Tab') {
                e.preventDefault();
                const ta = e.currentTarget;
                const start = ta.selectionStart;
                const end = ta.selectionEnd;
                const next = source.slice(0, start) + '  ' + source.slice(end);
                update(next);
                requestAnimationFrame(() => ta.setSelectionRange(start + 2, start + 2));
              }
            }}
            className="absolute inset-0 h-full w-full resize-none whitespace-pre bg-transparent py-2 pr-2 text-transparent caret-sky-300 outline-none selection:bg-sky-500/40"
            style={{ ...FONT_STYLE, paddingLeft: padLeft }}
            aria-label={`${asset.name} source code`}
          />
        </div>
      ) : (
        <div className="flex flex-1 items-center justify-center p-6 text-[11px] text-slate-500">
          Create a script with the <span className="mx-1 text-slate-300">New</span> button to get started.
        </div>
      )}

      {/* status bar */}
      <div className="flex shrink-0 items-center gap-2 border-t border-[#1e232c] bg-[#12161d] px-2 py-1 font-mono text-[10px] text-slate-500">
        <Play className="h-3 w-3 text-emerald-400" />
        <span>
          {asset ? asset.name : 'no script'} · {lines.length} lines · parsed by the in-app interpreter (never eval)
        </span>
        <span className="ml-auto flex items-center gap-2">
          <button type="button" className="text-slate-400 transition-colors hover:text-sky-300" onClick={() => onOpenDocs?.()}>
            scripting reference
          </button>
          <ChevronDown className="h-3 w-3" />
        </span>
      </div>
    </div>
  );
}

/* --------------------------------------------------------- highlighting */

const KEYWORDS = [
  'class', 'extends', 'Component', 'public', 'private', 'protected', 'void', 'float', 'int', 'double', 'string', 'bool',
  'Vector3', 'Quaternion', 'GameObject', 'Collision', 'let', 'var', 'if', 'else', 'while', 'for', 'return', 'break',
  'continue', 'new', 'this', 'true', 'false', 'null', 'and', 'or', 'not',
];

const LIFECYCLE = ['Start', 'Update', 'FixedUpdate', 'LateUpdate', 'OnCollision', 'OnKeyDown', 'OnKeyUp', 'OnClick', 'OnEvent'];
const BUILTINS = ['Math', 'Mathf', 'Input', 'Time', 'Debug', 'Random', 'Key'];
const HELPERS = ['transform', 'object', 'emit', 'log', 'find', 'instantiate', 'destroy', 'setColor', 'setActive', 'position', 'rotation', 'scale', 'velocity', 'name'];

function escapeHtml(text: string): string {
  return text.replace(/[&<>]/g, (c) => (c === '&' ? '&amp;' : c === '<' ? '&lt;' : '&gt;'));
}

/**
 * Tokenise user source into HTML for the highlight layer that sits under the
 * transparent textarea. Pure string work — no code is executed.
 */
export function highlightScript(source: string): string {
  const pattern = new RegExp(
    [
      '(\\/\\/[^\\n]*)', // 1 comment
      '("(?:[^"\\\\]|\\\\.)*")', // 2 string
      '(\\b\\d+(?:\\.\\d+)?\\b)', // 3 number
      `(\\b(?:${KEYWORDS.join('|')})\\b)`, // 4 keyword
      `(\\b(?:${BUILTINS.join('|')})\\b)`, // 5 builtin namespace
      `(\\b(?:${LIFECYCLE.join('|')})\\b)`, // 6 lifecycle
      `(\\b(?:${HELPERS.join('|')})\\b)`, // 7 helper
      '([{}()\\[\\];,.=+\\-*/%<>!&|])', // 8 punctuation
    ].join('|'),
    'g',
  );

  const classes = [
    '',
    'text-slate-500 italic',
    'text-amber-300',
    'text-orange-300',
    'text-sky-400',
    'text-violet-300',
    'text-emerald-300',
    'text-teal-200',
    'text-slate-500',
  ];

  let html = '';
  let last = 0;
  let match: RegExpExecArray | null;
  while ((match = pattern.exec(source)) !== null) {
    if (match.index > last) html += escapeHtml(source.slice(last, match.index));
    const groupIndex = match.slice(1).findIndex((g) => g !== undefined);
    const cls = classes[groupIndex + 1] ?? '';
    html += cls ? `<span class="${cls}">${escapeHtml(match[0])}</span>` : escapeHtml(match[0]);
    last = match.index + match[0].length;
  }
  html += escapeHtml(source.slice(last));
  return html || ' ';
}
