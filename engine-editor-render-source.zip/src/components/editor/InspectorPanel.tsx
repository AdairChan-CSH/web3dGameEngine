/**
 * Inspector panel — live editing for the selected object:
 * Transform, Mesh/Material, Light, Camera, Physics and attached Scripts
 * (including editable public fields of each attached class).
 */

import { useRef } from 'react';
import {
  Box,
  Camera as CameraIcon,
  Circle,
  CircleDot,
  Cone,
  Cylinder,
  Layers,
  Lightbulb,
  Package,
  Pill,
  SlidersHorizontal,
  Square,
  Sparkles,
  Trash2,
  Copy,
  Plus,
  Cpu,
  Move3d,
  Image as ImageIcon,
  Zap,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { useEngine, useEngineStats, useEngineVersion } from '@/engine/engine-context';
import type { GameObject } from '@/engine/scene';
import type { ScriptInstance } from '@/engine/types';
import {
  Button,
  CheckField,
  ColorField,
  EmptyHint,
  IconButton,
  Menu,
  NumberField,
  Section,
  SelectField,
  SliderField,
  Tag,
  TextField,
  round,
  type MenuItem,
} from './ui';
import { cn } from '@/lib/utils';

const TYPE_ICONS: Record<string, LucideIcon> = {
  Cube: Box,
  Sphere: Circle,
  Plane: Square,
  Cylinder: Cylinder,
  Torus: CircleDot,
  Capsule: Pill,
  Cone: Cone,
  Light: Lightbulb,
  Camera: CameraIcon,
  Empty: Layers,
  Model: Package,
};

export function InspectorPanel({ onPick }: { onPick?: () => void }) {
  const core = useEngine();
  useEngineVersion();
  const stats = useEngineStats();
  void stats;
  const obj = core.getSelected();
  const textureInput = useRef<HTMLInputElement>(null);

  if (!obj) {
    return (
      <div className="flex h-full min-h-0 flex-col bg-[#11141a]">
        <Header title="Inspector" />
        <EmptyHint
          icon={SlidersHorizontal}
          title="Nothing selected"
          description="Click an object in the viewport or the Hierarchy to edit its components, or add one from the Add Object menu."
        />
      </div>
    );
  }

  const Icon = TYPE_ICONS[obj.type] ?? Box;

  const scriptMenuItems: MenuItem[] = core.scriptList().map((asset) => ({
    label: asset.error ? `${asset.name} (has errors)` : asset.name,
    icon: Sparkles,
    disabled: !!asset.error && !asset.className,
    onClick: () => {
      const instance = core.attachScript(obj, asset.name);
      if (instance) core.log('log', `Attached ${asset.name} to ${obj.name}`);
      onPick?.();
    },
  }));

  return (
    <div className="flex h-full min-h-0 flex-col bg-[#11141a]">
      <Header title="Inspector" />

      <div className="min-h-0 flex-1 overflow-y-auto">
        {/* ---------------------------------------------------------- object */}
        <div className="flex items-center gap-2 border-b border-[#20252e] px-2.5 py-2">
          <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded border border-[#2a3140] bg-[#161b24]">
            <Icon className="h-3.5 w-3.5 text-sky-300" />
          </span>
          <div className="min-w-0 flex-1">
            <LiveText
              value={obj.name}
              onCommit={(next) => {
                if (next && next !== obj.name) core.renameObject(obj.id, next);
              }}
            />
          </div>
          <IconButton icon={Copy} label="Duplicate object" onClick={() => core.duplicateObject(obj.id)} />
          <IconButton
            icon={obj.three.visible ? Sparkles : Sparkles}
            label={obj.three.visible ? 'Hide object' : 'Show object'}
            active={!obj.three.visible}
            onClick={() => obj.setActive(!obj.three.visible)}
          />
          <IconButton icon={Trash2} label="Delete object" tone="danger" onClick={() => core.deleteObject(obj.id)} />
        </div>

        <div className="flex flex-wrap items-center gap-1.5 border-b border-[#20252e] px-2.5 py-2">
          <Tag tone="neutral">{obj.type}</Tag>
          <Tag tone="neutral">{obj.id.slice(0, 12)}</Tag>
          {obj.parent ? <Tag tone="sky">child of {obj.parent.name}</Tag> : <Tag tone="sky">scene root</Tag>}
          {obj.physics.usePhysics ? <Tag tone="emerald">physics</Tag> : null}
        </div>

        {/* ------------------------------------------------------- transform */}
        <Section title="Transform" actions={<IconButton icon={Move3d} label="Focus in viewport (F)" onClick={() => core.focusSelected()} />}>
          <div onFocusCapture={() => core.beginEdit(obj.id)} onBlurCapture={() => core.endEdit(obj.id, 'Move object')}>
            <VecRow
              label="Position"
              value={{ x: obj.three.position.x, y: obj.three.position.y, z: obj.three.position.z }}
              step={0.1}
              onChange={(axis, v) => {
                obj.three.position[axis] = v;
                core.notifyChange?.();
              }}
            />
          </div>
          <div onFocusCapture={() => core.beginEdit(obj.id)} onBlurCapture={() => core.endEdit(obj.id, 'Rotate object')}>
            <VecRow
              label="Rotation"
              suffix="°"
              value={{
                x: obj.three.rotation.x / (Math.PI / 180),
                y: obj.three.rotation.y / (Math.PI / 180),
                z: obj.three.rotation.z / (Math.PI / 180),
              }}
              step={5}
              onChange={(axis, v) => {
                obj.three.rotation[axis] = v * (Math.PI / 180);
                obj.three.rotation[axis] = obj.three.rotation[axis];
              }}
            />
          </div>
          <div onFocusCapture={() => core.beginEdit(obj.id)} onBlurCapture={() => core.endEdit(obj.id, 'Scale object')}>
            <VecRow
              label="Scale"
              step={0.1}
              min={0.001}
              value={{ x: obj.three.scale.x, y: obj.three.scale.y, z: obj.three.scale.z }}
              onChange={(axis, v) => {
                obj.three.scale[axis] = v;
                core.invalidateHalfExtents(obj.id);
              }}
            />
          </div>
          <div className="flex items-center gap-1 pt-1">
            <Button
              size="sm"
              onClick={() => {
                core.beginEdit(obj.id);
                obj.three.position.set(0, 0, 0);
                obj.three.rotation.set(0, 0, 0);
                obj.three.scale.set(1, 1, 1);
                obj.velocity?.set?.(0, 0, 0);
                core.invalidateHalfExtents(obj.id);
                core.endEdit(obj.id, 'Reset transform');
              }}
            >
              Reset transform
            </Button>
            <CheckField
              label="Player (Game view follows it)"
              checked={obj.isPlayer}
              onChange={(v) => {
                obj.isPlayer = v;
                if (core.ready) core.graph.touch();
              }}
            />
          </div>
        </Section>

        {/* -------------------------------------------------------- material */}
        {obj.materialParams ? (
          <Section
            title="Mesh / Material"
            actions={
              <>
                <input
                  ref={textureInput}
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    e.target.value = '';
                    if (file) void core.importTextureFile(file);
                  }}
                />
                <IconButton icon={ImageIcon} label="Apply a texture image to this object" onClick={() => textureInput.current?.click()} />
              </>
            }
          >
            <ColorField label="Colour" value={obj.materialParams.color} onChange={(v) => core.setMaterialParams(obj.id, { color: v }, false)} onCommit={() => core.notifyChange()} />
            <SliderField label="Metalness" value={obj.materialParams.metalness} min={0} max={1} step={0.01} onChange={(v) => core.setMaterialParams(obj.id, { metalness: v }, false)} />
            <SliderField label="Roughness" value={obj.materialParams.roughness} min={0} max={1} step={0.01} onChange={(v) => core.setMaterialParams(obj.id, { roughness: v }, false)} />
            <ColorField label="Emissive" value={obj.materialParams.emissive} onChange={(v) => core.setMaterialParams(obj.id, { emissive: v }, false)} />
            <SliderField
              label="Emissive power"
              value={obj.materialParams.emissiveIntensity}
              min={0}
              max={4}
              step={0.05}
              onChange={(v) => core.setMaterialParams(obj.id, { emissiveIntensity: v }, false)}
            />
            <SliderField label="Opacity" value={obj.materialParams.opacity} min={0.05} max={1} step={0.01} onChange={(v) => core.setMaterialParams(obj.id, { opacity: v }, false)} />
            <div className="flex flex-wrap gap-3 pt-1">
              <CheckField label="Wireframe" checked={obj.materialParams.wireframe} onChange={(v) => core.setMaterialParams(obj.id, { wireframe: v })} />
              <CheckField label="Two-sided" checked={obj.materialParams.doubleSided} onChange={(v) => core.setMaterialParams(obj.id, { doubleSided: v })} />
            </div>
          </Section>
        ) : null}

        {/* ----------------------------------------------------------- light */}
        {obj.lightParams ? (
          <Section title="Light">
            <div className="flex items-center gap-1.5 pb-1">
              <Tag tone="amber">{lightKind(obj)} light</Tag>
              <span className="text-[10px] text-slate-500">casts real-time shadows</span>
            </div>
            <ColorField label="Colour" value={obj.lightParams.color} onChange={(v) => core.setLightParams(obj.id, { color: v }, false)} />
            <SliderField label="Intensity" value={obj.lightParams.intensity} min={0} max={40} step={0.2} onChange={(v) => core.setLightParams(obj.id, { intensity: v }, false)} />
            <NumberFieldRow label="Distance / range" value={obj.lightParams.distance} min={0} step={1} onChange={(v) => core.setLightParams(obj.id, { distance: v }, false)} />
            <CheckField label="Cast shadows" checked={obj.lightParams.castShadow} onChange={(v) => core.setLightParams(obj.id, { castShadow: v })} />
          </Section>
        ) : null}

        {/* ---------------------------------------------------------- camera */}
        {obj.cameraParams ? (
          <Section title="Camera">
            <SliderField label="Field of view" value={obj.cameraParams.fov} min={20} max={110} step={1} onChange={(v) => core.setCameraParams(obj.id, { fov: v }, false)} />
            <NumberFieldRow label="Near clip" value={obj.cameraParams.near} min={0.01} step={0.1} onChange={(v) => core.setCameraParams(obj.id, { near: v }, false)} />
            <NumberFieldRow label="Far clip" value={obj.cameraParams.far} min={1} step={10} onChange={(v) => core.setCameraParams(obj.id, { far: v }, false)} />
            <CheckField
              label="Main Camera (Game view follows this object)"
              hint="Marking a camera as Main makes the Game view copy its transform — perfect for a FollowCamera script."
              checked={obj.cameraParams.isMain}
              onChange={(v) => core.setCameraParams(obj.id, { isMain: v })}
            />
          </Section>
        ) : null}

        {/* --------------------------------------------------------- physics */}
        <Section title="Physics">
          <CheckField label="Use physics" hint="Gravity, velocity integration, ground + box collisions" checked={obj.physics.usePhysics} onChange={(v) => core.setPhysicsParams(obj.id, { usePhysics: v })} />
          <CheckField label="Gravity" checked={obj.physics.useGravity} onChange={(v) => core.setPhysicsParams(obj.id, { useGravity: v })} />
          <CheckField label="Kinematic (script driven, unmovable)" checked={obj.physics.kinematic} onChange={(v) => core.setPhysicsParams(obj.id, { kinematic: v })} />
          <CheckField label="Collides with other objects" checked={obj.physics.collides} onChange={(v) => core.setPhysicsParams(obj.id, { collides: v })} />
          <SliderField label="Mass" value={obj.physics.mass} min={0.1} max={10} step={0.1} onChange={(v) => core.setPhysicsParams(obj.id, { mass: v }, false)} />
          <SliderField label="Bounce" value={obj.physics.bounce} min={0} max={1} step={0.01} onChange={(v) => core.setPhysicsParams(obj.id, { bounce: v }, false)} />
          <div className="flex items-center gap-2 pt-1 font-mono text-[10px] text-slate-500">
            <Zap className="h-3 w-3 text-amber-300" />
            velocity {round(obj.velocity.x)}, {round(obj.velocity.y)}, {round(obj.velocity.z)}
            {obj.grounded ? <Tag tone="emerald">grounded</Tag> : null}
          </div>
        </Section>

        {/* --------------------------------------------------------- scripts */}
        <Section
          title={`Scripts${obj.scripts.length ? ` (${obj.scripts.length})` : ''}`}
          actions={
            <Menu
              items={scriptMenuItems}
              width={230}
              trigger={
                <span className="flex items-center gap-1">
                  <Plus className="h-3 w-3" /> Add Script
                </span>
              }
            />
          }
        >
          {obj.scripts.length ? (
            <div className="space-y-2">
              {obj.scripts.map((instance) => (
                <ScriptCard key={instance.id} obj={obj} instance={instance} />
              ))}
            </div>
          ) : (
            <p className="pb-1 text-[11px] leading-relaxed text-slate-500">
              No scripts attached. Use <span className="text-slate-300">Add Script</span> — the public fields of the class
              become editable inputs here and can also be changed from outside with{' '}
              <span className="font-mono text-slate-400">Engine.setScriptField()</span>.
            </p>
          )}
        </Section>

        <div className="px-2.5 py-3">
          <p className="flex items-start gap-1.5 text-[10px] leading-relaxed text-slate-500">
            <Cpu className="mt-0.5 h-3 w-3 shrink-0" />
            Everything on this panel is also reachable from code: <span className="font-mono text-slate-400">Engine.getSelection()</span>,{' '}
            <span className="font-mono text-slate-400">Engine.setPosition()</span>,{' '}
            <span className="font-mono text-slate-400">Engine.animate()</span>.
          </p>
        </div>
      </div>
    </div>
  );
}

/* --------------------------------------------------------------- pieces */

function Header({ title }: { title: string }) {
  return (
    <header className="flex h-9 shrink-0 items-center gap-2 border-b border-[#232833] bg-[#151922] px-2.5">
      <SlidersHorizontal className="h-3.5 w-3.5 text-sky-400" />
      <h2 className="text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-300">{title}</h2>
    </header>
  );
}

/* The object name is edited inline in the panel header (see LiveText above). */

function VecRow({
  label,
  value,
  onChange,
  step = 0.1,
  min,
  suffix,
}: {
  label: string;
  value: { x: number; y: number; z: number };
  onChange: (axis: 'x' | 'y' | 'z', v: number) => void;
  step?: number;
  min?: number;
  suffix?: string;
}) {
  return (
    <div className="flex items-center gap-2">
      <span className="w-[68px] shrink-0 text-[10px] uppercase tracking-wide text-slate-500">{label}</span>
      <div className="grid flex-1 grid-cols-3 gap-1">
        {(['x', 'y', 'z'] as const).map((axis) => (
          <NumberField
            key={axis}
            value={value[axis]}
            step={step}
            min={min}
            suffix={suffix}
            title={`${label} ${axis.toUpperCase()}`}
            onChange={(v) => onChange(axis, v)}
          />
        ))}
      </div>
    </div>
  );
}

function NumberFieldRow({
  label,
  value,
  onChange,
  step,
  min,
  max,
  suffix,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
  step?: number;
  min?: number;
  max?: number;
  suffix?: string;
}) {
  return (
    <div className="flex items-center gap-2">
      <span className="w-[100px] shrink-0 text-[10px] uppercase tracking-wide text-slate-500">{label}</span>
      <NumberField value={value} onChange={onChange} step={step} min={min} max={max} suffix={suffix} />
    </div>
  );
}

function ScriptCard({ obj, instance }: { obj: GameObject; instance: ScriptInstance }) {
  const core = useEngine();
  const fields = Object.keys(instance.fields ?? {});

  return (
    <div className={cn('rounded border border-[#262d38] bg-[#141821]', !instance.enabled && 'opacity-60')}>
      <div className="flex items-center gap-1.5 border-b border-[#20252e] px-2 py-1.5">
        <Sparkles className="h-3 w-3 text-emerald-300" />
        <span className="truncate text-[11px] font-medium text-slate-200">{instance.className}</span>
        <span className="ml-auto flex items-center gap-1">
          <CheckField
            label=""
            hint="Enable / disable this script instance"
            checked={instance.enabled}
            onChange={(v) => core.setScriptEnabled(obj.id, instance.id, v)}
          />
          <IconButton
            icon={Trash2}
            label="Remove script"
            tone="danger"
            onClick={() => core.detachScript(obj.id, instance.id)}
          />
        </span>
      </div>
      <div className="space-y-1.5 px-2 py-2">
        {instance.lastError ? (
          <p className="rounded border border-rose-500/40 bg-rose-500/10 px-1.5 py-1 font-mono text-[10px] text-rose-300">
            line {instance.lastError.line}: {instance.lastError.message}
          </p>
        ) : null}
        {fields.length ? (
          fields.map((field) => {
            const value = instance.fields[field];
            const key = `${instance.id}.${field}`;
            if (typeof value === 'boolean') {
              return (
                <CheckField
                  key={key}
                  label={field}
                  checked={value}
                  onChange={(v) => core.setScriptField(obj.id, instance.id, field, v)}
                />
              );
            }
            if (typeof value === 'number') {
              return (
                <div key={key} className="flex items-center gap-2">
                  <span className="w-[100px] shrink-0 truncate font-mono text-[10px] text-slate-400" title={field}>
                    {field}
                  </span>
                  <NumberField value={value} onChange={(v) => core.setScriptField(obj.id, instance.id, field, v)} />
                </div>
              );
            }
            if (value && typeof value === 'object' && 'x' in value && 'y' in value && 'z' in value) {
              return (
                <VecRow
                  key={key}
                  label={field}
                  value={{ x: Number(value.x) || 0, y: Number(value.y) || 0, z: Number(value.z) || 0 }}
                  step={0.1}
                  onChange={(axis, v) => {
                    const next = { x: Number(value.x) || 0, y: Number(value.y) || 0, z: Number(value.z) || 0 };
                    next[axis] = v;
                    core.setScriptField(obj.id, instance.id, field, next);
                  }}
                />
              );
            }
            return (
              <div key={key} className="flex items-center gap-2">
                <span className="w-[100px] shrink-0 truncate font-mono text-[10px] text-slate-400" title={field}>
                  {field}
                </span>
                <TextField
                  value={String(value ?? '')}
                  onChange={() => undefined}
                  onCommit={() => undefined}
                  key={`${key}-${String(value)}`}
                  className="hidden"
                />
                <LiveText
                  value={String(value ?? '')}
                  onCommit={(v) => core.setScriptField(obj.id, instance.id, field, v)}
                />
              </div>
            );
          })
        ) : (
          <p className="text-[10px] text-slate-500">No public fields on this class.</p>
        )}
      </div>
    </div>
  );
}

/** Text editor that keeps local state while typing and commits on blur/Enter. */
function LiveText({ value, onCommit }: { value: string; onCommit: (v: string) => void }) {
  const ref = useRef<HTMLInputElement>(null);
  return (
    <input
      ref={ref}
      defaultValue={value}
      key={value}
      onBlur={(e) => {
        if (e.target.value !== value) onCommit(e.target.value);
      }}
      onKeyDown={(e) => {
        if (e.key === 'Enter') (e.target as HTMLInputElement).blur();
      }}
      className="w-full rounded border border-[#2a3140] bg-[#0c0f14] px-1.5 py-1 text-[11px] text-slate-200 outline-none focus:border-sky-500"
    />
  );
}

function lightKind(obj: GameObject): string {
  const light = obj.light;
  if (!light) return 'Point';
  if (light.isDirectionalLight) return 'Directional';
  if (light.isSpotLight) return 'Spot';
  if (light.isPointLight) return 'Point';
  if (light.isAmbientLight) return 'Ambient';
  if (light.isHemisphereLight) return 'Hemisphere';
  return 'Point';
}
