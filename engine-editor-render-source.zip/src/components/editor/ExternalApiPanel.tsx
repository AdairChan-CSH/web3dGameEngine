/**
 * External API panel — a searchable reference of every method on
 * window.Engine / window.GameEngine with a live "Run" button and copyable
 * snippets, so the API can be driven from a console, an iframe parent or a server.
 */

import { useMemo, useState } from 'react';
import {
  Check,
  ChevronRight,
  CornerDownLeft,
  Play,
  Search,
  Terminal,
  TriangleAlert,
  Zap,
} from 'lucide-react';
import { useEngine, useEngineVersion } from '@/engine/engine-context';
import { API_CATEGORIES, API_METHODS } from '@/engine/docs';
import { Button, CodeBlock, CopyButton, Tag } from './ui';
import { cn } from '@/lib/utils';

interface RunResult {
  method: string;
  ok: boolean;
  at: number;
  value: string;
}

const QUICKSTART = `// Everything below runs today — from this page's console, an iframe parent,
// or a server through the remote bridge.

Engine.ping()                                        // is the editor alive?
const id = Engine.createObject("Bouncer", "Sphere")  // → "obj_…"
Engine.setPosition(id, 0, 6, 0)
Engine.setColor(id, "#ff5fb0")
Engine.setPhysics(id, { usePhysics: true, bounce: 0.7 })
Engine.animate(id, { rotation: [0, 360, 0], duration: 3, loop: true })
Engine.attachScript(id, "BobAndFloat", { amplitude: 0.6, speed: 2.2 })
Engine.play()

// subscribe to events raised by scripts with this.emit(...)
Engine.on("player_jump", (payload) => console.log("jumped!", payload))`;

export function ExternalApiPanel() {
  const core = useEngine();
  useEngineVersion();
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<string>('All');
  const [results, setResults] = useState<RunResult[]>([]);
  const [expanded, setExpanded] = useState<string | null>(API_METHODS[0]?.name ?? null);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return API_METHODS.filter((m) => {
      if (category !== 'All' && m.category !== category) return false;
      if (!q) return true;
      return (
        m.name.toLowerCase().includes(q) ||
        m.signature.toLowerCase().includes(q) ||
        m.description.toLowerCase().includes(q)
      );
    });
  }, [query, category]);

  const runSample = (method: string, sample: string) => {
    let args: any[];
    try {
      const parsed = JSON.parse(sample || '[]');
      args = Array.isArray(parsed) ? parsed : [parsed];
    } catch {
      setResults((prev) => [{ method, ok: false, at: Date.now(), value: 'The sample arguments are not valid JSON.' }, ...prev].slice(0, 6));
      return;
    }
    const selected = core.selectedId;
    const resolved = args.map((a) => (a === '<selected>' ? selected ?? '' : a));
    const outcome = core.execute(method, resolved);
    setResults((prev) =>
      [
        {
          method,
          ok: outcome.ok,
          at: Date.now(),
          value: outcome.ok ? JSON.stringify(outcome.result, null, 2) : String(outcome.error),
        },
        ...prev,
      ].slice(0, 6),
    );
  };

  return (
    <div className="flex h-full min-h-0 flex-col bg-[#0e1116]">
      <header className="flex shrink-0 flex-wrap items-center gap-2 border-b border-[#232833] bg-[#151922] px-3 py-2">
        <Terminal className="h-4 w-4 text-sky-400" />
        <h2 className="text-[12px] font-semibold tracking-tight text-slate-200">External control API</h2>
        <Tag tone={core.ready ? 'emerald' : 'amber'}>{core.ready ? 'engine ready' : 'starting…'}</Tag>
        <Tag tone="neutral">{API_METHODS.length} methods</Tag>
        <Tag tone="neutral">window.Engine</Tag>
        <div className="ml-auto flex items-center gap-1.5">
          <div className="relative">
            <Search className="pointer-events-none absolute left-1.5 top-1.5 h-3 w-3 text-slate-600" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search methods…"
              className="w-48 rounded border border-[#2a3140] bg-[#0c0f14] py-1 pl-6 pr-2 text-[11px] text-slate-200 outline-none placeholder:text-slate-600 focus:border-sky-500"
            />
          </div>
        </div>
      </header>

      <div className="min-h-0 flex-1 overflow-y-auto px-3 py-3">
        <div className="grid gap-4 lg:grid-cols-[1.15fr_0.85fr]">
          {/* method list */}
          <div className="min-w-0">
            <div className="mb-2 flex flex-wrap gap-1">
              {(['All', ...API_CATEGORIES] as string[]).map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCategory(cat)}
                  className={cn(
                    'rounded border px-1.5 py-0.5 text-[10px] transition-colors',
                    category === cat
                      ? 'border-sky-500/50 bg-sky-500/15 text-sky-200'
                      : 'border-[#262d38] text-slate-400 hover:border-[#39424f] hover:text-slate-200',
                  )}
                >
                  {cat}
                </button>
              ))}
            </div>

            <div className="space-y-1.5">
              {filtered.map((method) => {
                const open = expanded === method.name;
                const snippet = `Engine.${method.name}(${JSON.parse(safeJson(method.sample)).map((a: any) => JSON.stringify(a)).join(', ')})`;
                return (
                  <div key={method.name} className="overflow-hidden rounded border border-[#262d38] bg-[#12161d]">
                    <button
                      type="button"
                      onClick={() => setExpanded(open ? null : method.name)}
                      className="flex w-full items-center gap-2 px-2 py-1.5 text-left transition-colors hover:bg-white/5"
                    >
                      <ChevronRight className={cn('h-3.5 w-3.5 shrink-0 text-slate-500 transition-transform', open && 'rotate-90')} />
                      <span className="min-w-0 flex-1 truncate font-mono text-[11px] text-sky-200">{method.signature}</span>
                      <Tag tone="neutral">{method.category}</Tag>
                    </button>
                    {open ? (
                      <div className="space-y-2 border-t border-[#20252e] px-2.5 py-2">
                        <p className="text-[11px] leading-relaxed text-slate-400">{method.description}</p>
                        <div className="flex flex-wrap items-center gap-1.5">
                          <code className="min-w-0 flex-1 truncate rounded border border-[#262d38] bg-[#0b0e13] px-1.5 py-1 font-mono text-[10px] text-emerald-200">
                            {snippet}
                          </code>
                          <CopyButton text={snippet} label="Copy" />
                        </div>
                        <div className="flex flex-wrap items-center gap-1.5">
                          <code className="min-w-0 flex-1 truncate rounded border border-[#262d38] bg-[#0b0e13] px-1.5 py-1 font-mono text-[10px] text-slate-400">
                            args: {method.sample}
                          </code>
                          <Button size="sm" icon={Play} variant="primary" onClick={() => runSample(method.name, method.sample)}>
                            Run
                          </Button>
                        </div>
                        <p className="text-[10px] text-slate-600">
                          <Code2 />{' '}
                          <span className="font-mono">"&lt;selected&gt;"</span> is replaced with the selected object's id before the call runs.
                        </p>
                      </div>
                    ) : null}
                  </div>
                );
              })}
              {filtered.length === 0 ? <p className="text-[11px] text-slate-500">No method matches “{query}”.</p> : null}
            </div>
          </div>

          {/* right column: quickstart + live results */}
          <div className="min-w-0 space-y-3">
            <CodeBlock code={QUICKSTART} title="quickstart.js" note="window.Engine and window.GameEngine are the same object." />

            <div className="rounded border border-[#262d38] bg-[#12161d]">
              <div className="flex items-center gap-1.5 border-b border-[#20252e] px-2.5 py-1.5">
                <Zap className="h-3.5 w-3.5 text-amber-300" />
                <span className="text-[11px] font-semibold text-slate-200">Live results</span>
                <span className="ml-auto font-mono text-[10px] text-slate-500">{core.bridgeHandled} bridged calls</span>
              </div>
              <div className="max-h-[280px] space-y-1 overflow-y-auto px-2.5 py-2">
                {results.length === 0 ? (
                  <p className="flex items-center gap-1.5 text-[11px] text-slate-500">
                    <CornerDownLeft className="h-3 w-3" /> Press Run on any method to call it against the running scene.
                  </p>
                ) : (
                  results.map((r) => (
                    <div key={`${r.method}-${r.at}`} className="rounded border border-[#242a35] bg-[#0b0e13] px-2 py-1.5">
                      <p className="flex items-center gap-1.5 font-mono text-[10px] text-slate-400">
                        {r.ok ? <Check className="h-3 w-3 text-emerald-400" /> : <TriangleAlert className="h-3 w-3 text-rose-400" />}
                        Engine.{r.method}()
                      </p>
                      <pre className={cn('mt-1 overflow-x-auto font-mono text-[10px]', r.ok ? 'text-slate-300' : 'text-rose-300')}>
                        {r.value}
                      </pre>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="rounded border border-[#262d38] bg-[#12161d] px-2.5 py-2">
              <h3 className="text-[11px] font-semibold text-slate-200">Also available</h3>
              <ul className="mt-1 space-y-1 text-[11px] text-slate-400">
                <li>
                  <span className="font-mono text-sky-200">Engine.emitEvent(name, payload)</span> — scripts react through{' '}
                  <span className="font-mono">OnEvent</span>.
                </li>
                <li>
                  <span className="font-mono text-sky-200">Engine.on(name, fn)</span> — subscribe from outside the editor.
                </li>
                <li>
                  <span className="font-mono text-sky-200">window.postMessage</span> — see the <span className="text-slate-200">Remote Control</span> tab
                  for an embedded-page demo.
                </li>
                <li>
                  <span className="font-mono text-sky-200">window.__WEBFORGE_CORE__</span> — the live engine instance (handy while debugging).
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function safeJson(sample: string): string {
  try {
    const parsed = JSON.parse(sample);
    JSON.parse(sample);
    return Array.isArray(parsed) ? sample : '[]';
  } catch {
    return '[]';
  }
}

function Code2() {
  return <Terminal className="inline h-3 w-3 text-slate-500" />;
}
