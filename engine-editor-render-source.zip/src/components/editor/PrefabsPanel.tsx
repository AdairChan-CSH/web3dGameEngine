/**
 * Prefabs panel — the reusable-object library.
 *
 * Lists every saved prefab, newest first. Clicking a card drops a fresh copy of
 * the whole subtree into the current scene (or "Add" for the same thing), and the
 * strip under each card renames, re-captures, duplicates or deletes it.
 * A card can also be dragged onto the viewport (placed where the cursor is) or
 * onto a Hierarchy row (placed as a child of that object).
 *
 * Prefabs are stored in the browser next to the projects, so the same library is
 * available in every scene you open — that is what "reusable" means here.
 */

import { useMemo, useState } from 'react';
import {
  Check,
  Copy,
  Package,
  PackagePlus,
  Pencil,
  Plus,
  RefreshCw,
  Search,
  Trash2,
  Undo2,
} from 'lucide-react';
import { useEngine, useEngineVersion } from '@/engine/engine-context';
import { prefabAccent, prefabSummary, type Prefab } from '@/engine/prefabs';
import { endPrefabDrag, writePrefabDragData } from '@/engine/prefab-drag';
import { OBJECT_TYPE_ICONS } from './HierarchyPanel';
import { Button, EmptyHint, IconButton, Tag } from './ui';
import { cn } from '@/lib/utils';

export function PrefabsPanel({ onPick }: { onPick?: () => void }) {
  const core = useEngine();
  useEngineVersion();
  const [query, setQuery] = useState('');
  const [renaming, setRenaming] = useState<string | null>(null);
  const [draggingId, setDraggingId] = useState<string | null>(null);
  const [lastPlaced, setLastPlaced] = useState<{ name: string; objects: number } | null>(null);

  const prefabs = core.prefabs;
  const selected = core.selectedId ? core.graph.get(core.selectedId) ?? null : null;

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return prefabs;
    return prefabs.filter((p) => p.name.toLowerCase().includes(q));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [prefabs, query]);

  const saveSelection = () => {
    if (!selected) return;
    const prefab = core.savePrefab(selected.id, selected.name);
    if (!prefab) return;
    setQuery('');
    setRenaming(null);
  };

  const place = (prefab: Prefab) => {
    const obj = core.instantiatePrefab(prefab.id);
    if (!obj) return;
    setLastPlaced({ name: prefab.name, objects: prefab.stats.objects });
    onPick?.();
  };

  return (
    <div className="flex h-full min-h-0 flex-col bg-[#11141a]">
      <header className="flex h-9 shrink-0 items-center gap-1 border-b border-[#232833] bg-[#151922] px-2">
        <Package className="h-3.5 w-3.5 text-sky-400" />
        <h2 className="text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-300">Prefabs</h2>
        <span className="ml-1 font-mono text-[9px] text-slate-600">{prefabs.length}</span>
        <div className="ml-auto">
          <Button
            size="sm"
            variant="primary"
            icon={PackagePlus}
            disabled={!selected}
            onClick={saveSelection}
            title={
              selected
                ? `Save "${selected.name}" — with its children, materials, physics and scripts — as a prefab`
                : 'Select an object in the Hierarchy first'
            }
          >
            Save selection
          </Button>
        </div>
      </header>

      <div className="flex shrink-0 items-center gap-1.5 border-b border-[#1e232c] px-2 py-1.5">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-1.5 top-1.5 h-3 w-3 text-slate-600" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search prefabs"
            aria-label="Search prefabs"
            className="w-full rounded border border-[#262d38] bg-[#0c0f14] py-1 pl-6 pr-2 text-[11px] text-slate-200 outline-none placeholder:text-slate-600 focus:border-sky-500"
          />
        </div>
      </div>

      <div className="min-h-0 flex-1 space-y-1.5 overflow-y-auto p-2">
        {prefabs.length === 0 ? (
          <EmptyHint
            icon={Package}
            title="No prefabs yet"
            description="Select an object in the Hierarchy — children, materials, physics settings and attached scripts all come along — then press Save selection."
          />
        ) : filtered.length === 0 ? (
          <p className="px-1 py-4 text-[11px] text-slate-500">No prefab matches “{query}”.</p>
        ) : (
          filtered.map((prefab) => (
            <PrefabCard
              key={prefab.id}
              prefab={prefab}
              renaming={renaming === prefab.id}
              hasSelection={!!selected}
              dragging={draggingId === prefab.id}
              onDragStateChange={(dragging) => setDraggingId(dragging ? prefab.id : null)}
              onPlace={() => place(prefab)}
              onRenameStart={() => setRenaming(prefab.id)}
              onRenameCancel={() => setRenaming(null)}
              onRename={(name) => {
                setRenaming(null);
                core.renamePrefab(prefab.id, name);
              }}
            />
          ))
        )}
      </div>

      <footer className="shrink-0 border-t border-[#1e232c] px-2 py-1.5">
        {lastPlaced ? (
          <div className="flex items-center gap-1.5">
            <Check className="h-3 w-3 shrink-0 text-emerald-400" />
            <span className="min-w-0 flex-1 truncate text-[10px] text-slate-400">
              Placed “{lastPlaced.name}” ({lastPlaced.objects} {lastPlaced.objects === 1 ? 'object' : 'objects'}) at the view centre.
            </span>
            <Button
              size="sm"
              icon={Undo2}
              title="Remove the objects that were just placed"
              onClick={() => {
                core.undo();
                setLastPlaced(null);
              }}
            >
              Undo
            </Button>
          </div>
        ) : (
          <p className="text-[10px] leading-relaxed text-slate-500">
            Click a prefab to drop a copy into the scene at the centre of the view · drag a card onto the viewport or a
            Hierarchy row to place it there · the library lives in this browser, so every project you open can use it.
          </p>
        )}
      </footer>
    </div>
  );
}

function PrefabCard({
  prefab,
  renaming,
  hasSelection,
  dragging,
  onDragStateChange,
  onPlace,
  onRenameStart,
  onRenameCancel,
  onRename,
}: {
  prefab: Prefab;
  renaming: boolean;
  hasSelection: boolean;
  dragging: boolean;
  onDragStateChange: (dragging: boolean) => void;
  onPlace: () => void;
  onRenameStart: () => void;
  onRenameCancel: () => void;
  onRename: (name: string) => void;
}) {
  const core = useEngine();
  const stats = prefab.stats;
  const accent = prefabAccent(prefab);
  const Icon = OBJECT_TYPE_ICONS[prefab.root.type] ?? Package;

  return (
    <div
      draggable={!renaming}
      onDragStart={(e) => {
        writePrefabDragData(e.dataTransfer, prefab.id, prefab.name);
        onDragStateChange(true);
      }}
      onDragEnd={() => {
        endPrefabDrag();
        onDragStateChange(false);
      }}
      className={cn(
        'overflow-hidden rounded border border-[#242a35] bg-[#141821] transition-all duration-150 hover:-translate-y-px hover:border-sky-500/40 hover:shadow-lg hover:shadow-sky-900/25 focus-within:border-sky-500/40',
        renaming ? 'cursor-auto' : 'cursor-grab active:cursor-grabbing',
        dragging && 'translate-y-0 scale-[0.98] opacity-60 shadow-lg shadow-sky-900/30 ring-1 ring-sky-400/60',
      )}
    >
      <button
        type="button"
        onClick={onPlace}
        title={`Add "${prefab.name}" to the scene — or drag the card onto the viewport or a Hierarchy row`}
        className="group flex w-full items-start gap-2 p-1.5 text-left"
      >
        <span
          className="relative flex h-12 w-12 shrink-0 items-center justify-center rounded border transition-shadow group-hover:shadow-lg group-hover:shadow-sky-900/30"
          style={{ borderColor: `${accent}55`, background: `linear-gradient(150deg, ${accent}33, #0d1219 72%)` }}
        >
          <Icon className="h-5 w-5" style={{ color: accent }} />
          {stats.objects > 1 ? (
            <span className="absolute -bottom-1 -right-1 rounded border border-[#333b4a] bg-[#161b23] px-1 font-mono text-[8px] text-slate-400">
              {stats.objects}
            </span>
          ) : null}
        </span>

        <span className="min-w-0 flex-1">
          {renaming ? (
            <input
              autoFocus
              defaultValue={prefab.name}
              onClick={(e) => e.stopPropagation()}
              onBlur={(e) => onRename(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') (e.target as HTMLInputElement).blur();
                if (e.key === 'Escape') onRenameCancel();
              }}
              aria-label="Prefab name"
              className="w-full rounded border border-sky-500 bg-[#0c0f14] px-1 py-0.5 text-[11.5px] text-slate-100 outline-none"
            />
          ) : (
            <span className="block truncate text-[11.5px] font-medium text-slate-100">{prefab.name}</span>
          )}
          <span className="mt-0.5 block truncate font-mono text-[9.5px] text-slate-500">{prefabSummary(prefab)}</span>
          <span className="mt-1 flex flex-wrap items-center gap-1">
            {stats.scripts ? (
              <Tag tone="sky">
                {stats.scripts} script{stats.scripts === 1 ? '' : 's'}
              </Tag>
            ) : null}
            {stats.physicsBodies ? <Tag tone="amber">physics</Tag> : null}
            {stats.depth > 1 ? <Tag tone="neutral">nested</Tag> : null}
            {stats.lights ? <Tag tone="neutral">{stats.lights === 1 ? 'light' : 'lights'}</Tag> : null}
          </span>
        </span>
      </button>

      <div className="flex items-center gap-1 border-t border-[#1e232c] bg-[#12161d] px-1.5 py-1">
        <Button size="sm" variant="primary" icon={Plus} onClick={onPlace} title={`Add "${prefab.name}" to the scene`}>
          Add
        </Button>
        <span className="ml-auto flex items-center gap-0.5">
          <IconButton icon={Pencil} label="Rename this prefab" className="h-5 w-5" onClick={onRenameStart} />
          <IconButton
            icon={RefreshCw}
            label={
              hasSelection
                ? 'Replace this prefab with the object selected in the Hierarchy'
                : 'Select an object in the Hierarchy to update this prefab'
            }
            className={cn('h-5 w-5', !hasSelection && 'opacity-40')}
            disabled={!hasSelection}
            onClick={() => core.updatePrefabFromSelection(prefab.id)}
          />
          <IconButton icon={Copy} label="Duplicate this prefab" className="h-5 w-5" onClick={() => core.duplicatePrefab(prefab.id)} />
          <IconButton
            icon={Trash2}
            label="Delete this prefab"
            tone="danger"
            className="h-5 w-5"
            onClick={() => core.deletePrefab(prefab.id)}
          />
        </span>
      </div>
    </div>
  );
}
