/**
 * Hierarchy panel — the scene tree.
 * Select, add, rename, duplicate, delete and re-parent (drag & drop) objects.
 *
 * A prefab card dragged out of the Prefabs panel can also be dropped onto a row
 * (the copy becomes a child of that object) or on the empty area below the tree
 * (the copy is added at the scene root).
 */

import { useMemo, useState } from 'react';
import {
  Box,
  Camera,
  ChevronRight,
  Circle,
  CircleDot,
  Cone,
  Copy,
  Cylinder,
  Eye,
  EyeOff,
  Layers,
  Lightbulb,
  Locate,
  Package,
  PackagePlus,
  Pill,
  Plus,
  Search,
  Square,
  Trash2,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { useEngine, useEngineVersion } from '@/engine/engine-context';
import type { GameObject } from '@/engine/scene';
import { isPrefabDragActive, readPrefabDragId } from '@/engine/prefab-drag';
import { Button, IconButton, Menu, Tag, type MenuItem } from './ui';
import { cn } from '@/lib/utils';

/** Shared with the Prefabs panel so a prefab's card shows the same icon as its row. */
export const OBJECT_TYPE_ICONS: Record<string, LucideIcon> = {
  Cube: Box,
  Sphere: Circle,
  Plane: Square,
  Cylinder: Cylinder,
  Torus: CircleDot,
  Capsule: Pill,
  Cone: Cone,
  Light: Lightbulb,
  Camera: Camera,
  Empty: Layers,
  Model: Package,
};

export function HierarchyPanel({
  onPick,
  onSavedAsPrefab,
  onOpenPrefabs,
}: {
  onPick?: () => void;
  /** called with the new prefab's name so the shell can reveal the Prefabs panel */
  onSavedAsPrefab?: (prefabName: string) => void;
  onOpenPrefabs?: () => void;
}) {
  const core = useEngine();
  useEngineVersion();
  const [query, setQuery] = useState('');
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});
  const [renaming, setRenaming] = useState<string | null>(null);
  const [dropTarget, setDropTarget] = useState<string | null>(null);
  const [prefabRootTarget, setPrefabRootTarget] = useState(false);

  const roots = core.ready ? core.graph.roots : [];
  const selectedId = core.selectedId;

  const matches = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return null;
    return core.objectsOrEmpty().filter((o) => o.name.toLowerCase().includes(q));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query, core.version]);

  const addItems: MenuItem[] = core.objectTypes().map((type) => ({
    label: type,
    icon: OBJECT_TYPE_ICONS[type] ?? Box,
    onClick: () => {
      const obj = core.createObject(type);
      core.select(obj.id);
      onPick?.();
    },
  }));

  const saveAsPrefab = () => {
    if (!selectedId) return;
    const prefab = core.savePrefab(selectedId, core.ready ? core.graph.get(selectedId)?.name : undefined);
    if (prefab) onSavedAsPrefab?.(prefab.name);
  };

  const prefabItems: MenuItem[] = [
    {
      label: 'Save selection as a prefab',
      icon: PackagePlus,
      disabled: !selectedId,
      onClick: saveAsPrefab,
      hint: 'Captures this object with its children, materials, physics settings and scripts',
    },
    { label: 'Show the Prefabs panel', icon: Package, onClick: () => onOpenPrefabs?.() },
  ];

  const toggleCollapse = (id: string) => setCollapsed((prev) => ({ ...prev, [id]: !prev[id] }));
  const handleDrop = (targetId: string | null) => {
    const draggedId = dragId;
    setDropTarget(null);
    if (!draggedId || draggedId === targetId) return;
    core.setParent(draggedId, targetId);
  };

  /** A prefab card dropped on a row (or the empty area) is created through the normal
   *  path and then parented to that object — null parent means the scene root. */
  const handlePrefabDrop = (prefabId: string, parentId: string | null) => {
    setDropTarget(null);
    setPrefabRootTarget(false);
    const obj = core.placePrefabUnder(prefabId, parentId);
    if (!obj) return;
    // reveal the new child under the row it was dropped on
    if (parentId) setCollapsed((prev) => (prev[parentId] ? { ...prev, [parentId]: false } : prev));
  };

  return (
    <div className="flex h-full min-h-0 flex-col bg-[#11141a]">
      <header className="flex h-9 shrink-0 items-center gap-1 border-b border-[#232833] bg-[#151922] px-2">
        <Layers className="h-3.5 w-3.5 text-sky-400" />
        <h2 className="text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-300">Hierarchy</h2>
        <span className="ml-1 font-mono text-[9px] text-slate-600">{core.objectCount()}</span>
        <div className="ml-auto flex items-center gap-1">
          <Menu
            items={prefabItems}
            width={228}
            align="right"
            trigger={
              <span className="flex items-center gap-1">
                <PackagePlus className="h-3 w-3" /> Prefab
              </span>
            }
          />
          <Menu
            items={addItems}
            width={200}
            align="right"
            trigger={
              <span className="flex items-center gap-1">
                <Plus className="h-3 w-3" /> Add
              </span>
            }
          />
        </div>
      </header>

      <div className="flex shrink-0 items-center gap-1.5 border-b border-[#1e232c] px-2 py-1.5">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-1.5 top-1.5 h-3 w-3 text-slate-600" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search objects"
            className="w-full rounded border border-[#262d38] bg-[#0c0f14] py-1 pl-6 pr-2 text-[11px] text-slate-200 outline-none placeholder:text-slate-600 focus:border-sky-500"
          />
        </div>
        <IconButton icon={Copy} label="Duplicate selection (Ctrl+D)" disabled={!selectedId} onClick={() => selectedId && core.duplicateObject(selectedId)} />
        <IconButton icon={Locate} label="Focus selection (F)" disabled={!selectedId} onClick={() => core.focusSelected()} />
        <IconButton
          icon={PackagePlus}
          label={selectedId ? 'Save the selection as a reusable prefab' : 'Select an object to save it as a prefab'}
          tone="primary"
          disabled={!selectedId}
          onClick={saveAsPrefab}
        />
        <IconButton icon={Trash2} label="Delete selection" tone="danger" disabled={!selectedId} onClick={() => selectedId && core.deleteObject(selectedId)} />
      </div>

      <div
        className={cn(
          'min-h-0 flex-1 overflow-y-auto py-1',
          prefabRootTarget && 'bg-emerald-500/5 ring-2 ring-inset ring-emerald-400/60',
        )}
        onDragOver={(e) => {
          e.preventDefault();
          const prefabDrag = isPrefabDragActive();
          if (e.dataTransfer) e.dataTransfer.dropEffect = prefabDrag ? 'copy' : 'move';
          setDropTarget(null);
          setPrefabRootTarget(prefabDrag);
        }}
        onDragLeave={() => setPrefabRootTarget(false)}
        onDrop={(e) => {
          e.preventDefault();
          setPrefabRootTarget(false);
          const prefabId = readPrefabDragId(e.dataTransfer);
          if (prefabId) {
            handlePrefabDrop(prefabId, null);
            return;
          }
          handleDrop(null);
        }}
      >
        {matches ? (
          matches.length ? (
            matches.map((obj) => (
              <Row
                key={obj.id}
                obj={obj}
                depth={0}
                selected={obj.id === selectedId}
                renaming={renaming === obj.id}
                onToggle={toggleCollapse}
                collapsed={!!collapsed[obj.id]}
                onSelect={() => core.select(obj.id)}
                onRenameStart={() => setRenaming(obj.id)}
                onRenameEnd={(name) => {
                  setRenaming(null);
                  if (name && name !== obj.name) core.renameObject(obj.id, name);
                }}
                onDragStart={(id) => { dragId = id; }}
                onDropOn={(id) => handleDrop(id)}
                onPrefabDrop={handlePrefabDrop}
                dropTarget={dropTarget}
                setDropTarget={setDropTarget}
                hasChildren={obj.children.length > 0}
              />
            ))
          ) : (
            <p className="px-3 py-4 text-[11px] text-slate-500">No object matches “{query}”.</p>
          )
        ) : roots.length ? (
          roots.map((obj) => (
            <Tree
              key={obj.id}
              obj={obj}
              depth={0}
              selectedId={selectedId}
              collapsed={collapsed}
              onToggle={toggleCollapse}
              renaming={renaming}
              setRenaming={setRenaming}
              onSelect={(id) => core.select(id)}
              onRename={(id, name) => (name && core.renameObject(id, name))}
              onDragStart={(id) => { dragId = id; }}
              onDropOn={handleDrop}
              onPrefabDrop={handlePrefabDrop}
              dropTarget={dropTarget}
              setDropTarget={setDropTarget}
            />
          ))
        ) : (
          <p className="px-3 py-4 text-[11px] text-slate-500">
            The scene is empty. Use <span className="text-slate-300">Add</span> to place your first object.
          </p>
        )}
      </div>

      <footer className="shrink-0 border-t border-[#1e232c] px-2 py-1.5">
        <p className="text-[10px] leading-relaxed text-slate-500">
          Drag a row onto another to parent it · drop on empty space to move it back to the scene root · drop a prefab card
          on a row to place it as a child · save any branch as a reusable prefab with the package button.
        </p>
      </footer>
    </div>
  );
}

let dragId: string | null = null;

function Tree({
  obj,
  depth,
  selectedId,
  collapsed,
  onToggle,
  renaming,
  setRenaming,
  onSelect,
  onRename,
  onDragStart,
  onDropOn,
  onPrefabDrop,
  dropTarget,
  setDropTarget,
}: {
  obj: GameObject;
  depth: number;
  selectedId: string | null;
  collapsed: Record<string, boolean>;
  onToggle: (id: string) => void;
  renaming: string | null;
  setRenaming: (id: string | null) => void;
  onSelect: (id: string) => void;
  onRename: (id: string, name: string) => void;
  onDragStart: (id: string) => void;
  onDropOn: (id: string | null) => void;
  onPrefabDrop: (prefabId: string, parentId: string | null) => void;
  dropTarget: string | null;
  setDropTarget: (id: string | null) => void;
}) {
  return (
    <>
      <Row
        obj={obj}
        depth={depth}
        selected={obj.id === selectedId}
        collapsed={!!collapsed[obj.id]}
        onToggle={onToggle}
        renaming={renaming === obj.id}
        onSelect={() => onSelect(obj.id)}
        onRenameStart={() => setRenaming(obj.id)}
        onRenameEnd={(name) => {
          setRenaming(null);
          onRename(obj.id, name);
        }}
        onDragStart={onDragStart}
        onDropOn={onDropOn}
        onPrefabDrop={onPrefabDrop}
        dropTarget={dropTarget}
        setDropTarget={setDropTarget}
        hasChildren={obj.children.length > 0}
      />
      {!collapsed[obj.id] &&
        obj.children.map((child) => (
          <Tree
            key={child.id}
            obj={child}
            depth={depth + 1}
            selectedId={selectedId}
            collapsed={collapsed}
            onToggle={onToggle}
            renaming={renaming}
            setRenaming={setRenaming}
            onSelect={onSelect}
            onRename={onRename}
            onDragStart={onDragStart}
            onDropOn={onDropOn}
            onPrefabDrop={onPrefabDrop}
            dropTarget={dropTarget}
            setDropTarget={setDropTarget}
          />
        ))}
    </>
  );
}

function Row({
  obj,
  depth,
  selected,
  collapsed,
  onToggle,
  renaming,
  onSelect,
  onRenameStart,
  onRenameEnd,
  onDragStart,
  onDropOn,
  onPrefabDrop,
  dropTarget,
  setDropTarget,
  hasChildren,
}: {
  obj: GameObject;
  depth: number;
  selected: boolean;
  collapsed?: boolean;
  onToggle: (id: string) => void;
  renaming: boolean;
  onSelect: () => void;
  onRenameStart: () => void;
  onRenameEnd: (name: string) => void;
  onDragStart: (id: string) => void;
  onDropOn: (id: string | null) => void;
  onPrefabDrop: (prefabId: string, parentId: string | null) => void;
  dropTarget: string | null;
  setDropTarget: (id: string | null) => void;
  hasChildren: boolean;
}) {
  const Icon = OBJECT_TYPE_ICONS[obj.type] ?? Box;
  const prefabDrag = isPrefabDragActive();
  const isDropTarget = dropTarget === obj.id;

  return (
    <div
      draggable={!renaming}
      onDragStart={(e) => {
        onDragStart(obj.id);
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', obj.id);
      }}
      onDragOver={(e) => {
        e.preventDefault();
        e.stopPropagation();
        if (e.dataTransfer) e.dataTransfer.dropEffect = prefabDrag ? 'copy' : 'move';
        setDropTarget(obj.id);
      }}
      onDragLeave={() => setDropTarget(null)}
      onDrop={(e) => {
        e.preventDefault();
        e.stopPropagation();
        const prefabId = readPrefabDragId(e.dataTransfer);
        if (prefabId) {
          onPrefabDrop(prefabId, obj.id);
          return;
        }
        onDropOn(obj.id);
      }}
      onClick={onSelect}
      onDoubleClick={onRenameStart}
      className={cn(
        'group flex h-7 cursor-pointer items-center gap-1 pr-1.5 text-[11px] transition-colors',
        selected ? 'bg-sky-500/15 text-sky-100' : 'text-slate-300 hover:bg-white/5',
        isDropTarget && prefabDrag && 'bg-emerald-500/15 ring-1 ring-inset ring-emerald-400/80',
        isDropTarget && !prefabDrag && 'ring-1 ring-inset ring-sky-400/70',
      )}
      style={{ paddingLeft: 4 + depth * 12 }}
    >
      <button
        type="button"
        aria-label={collapsed ? 'Expand' : 'Collapse'}
        onClick={(e) => {
          e.stopPropagation();
          onToggle(obj.id);
        }}
        className={cn('flex h-4 w-4 items-center justify-center rounded text-slate-500', !hasChildren && 'opacity-0')}
      >
        <ChevronRight className={cn('h-3 w-3 transition-transform', !collapsed && 'rotate-90')} />
      </button>
      <Icon className={cn('h-3.5 w-3.5 shrink-0', obj.type === 'Light' ? 'text-amber-300' : obj.type === 'Camera' ? 'text-sky-300' : 'text-slate-400')} />
      {renaming ? (
        <input
          autoFocus
          defaultValue={obj.name}
          onClick={(e) => e.stopPropagation()}
          onBlur={(e) => onRenameEnd(e.target.value.trim())}
          onKeyDown={(e) => {
            if (e.key === 'Enter') (e.target as HTMLInputElement).blur();
            if (e.key === 'Escape') onRenameEnd(obj.name);
          }}
          className="min-w-0 flex-1 rounded border border-sky-500 bg-[#0c0f14] px-1 text-[11px] text-slate-100 outline-none"
        />
      ) : (
        <span className="min-w-0 flex-1 truncate">{obj.name}</span>
      )}
      {obj.isPlayer ? <Tag tone="sky">player</Tag> : null}
      {obj.scripts.length ? <span className="font-mono text-[9px] text-slate-500">{obj.scripts.length}s</span> : null}
      <IconButton
        icon={obj.three.visible ? Eye : EyeOff}
        label={obj.three.visible ? 'Hide object' : 'Show object'}
        className={cn('h-5 w-5 opacity-0 group-hover:opacity-100', !obj.three.visible && 'opacity-100')}
        onClick={() => {
          obj.setActive(!obj.three.visible);
        }}
      />
    </div>
  );
}
