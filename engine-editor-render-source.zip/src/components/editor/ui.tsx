/**
 * Small shared UI kit for the editor chrome.
 * Deliberately dependency-light: plain Tailwind + lucide icons so every panel
 * looks identical and nothing has to be loaded over the network twice.
 */

import { useEffect, useRef, useState, type CSSProperties, type ReactNode } from 'react';
import { Check, ChevronDown, ChevronRight, Copy, X } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

/* ------------------------------------------------------------------ shell */

export function PanelShell({
  title,
  icon: Icon,
  actions,
  children,
  className,
}: {
  title: string;
  icon?: LucideIcon;
  actions?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section className={cn('flex h-full min-h-0 flex-col bg-[#11141a]', className)}>
      <header className="flex h-9 shrink-0 items-center gap-2 border-b border-[#232833] bg-[#151922] px-2.5">
        {Icon ? <Icon className="h-3.5 w-3.5 text-sky-400" /> : null}
        <h2 className="text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-300">{title}</h2>
        <div className="ml-auto flex items-center gap-1">{actions}</div>
      </header>
      <div className="min-h-0 flex-1 overflow-y-auto">{children}</div>
    </section>
  );
}

export function Section({
  title,
  actions,
  children,
  collapsible = true,
  defaultOpen = true,
  dense,
}: {
  title: string;
  actions?: ReactNode;
  children: ReactNode;
  collapsible?: boolean;
  defaultOpen?: boolean;
  dense?: boolean;
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border-b border-[#20252e]">
      <div className="flex h-8 items-center gap-1.5 px-2.5">
        {collapsible ? (
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            className="flex flex-1 items-center gap-1.5 text-left text-[11px] font-semibold uppercase tracking-[0.12em] text-slate-400 transition-colors hover:text-slate-200"
            aria-expanded={open}
          >
            {open ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />}
            {title}
          </button>
        ) : (
          <span className="flex-1 text-[11px] font-semibold uppercase tracking-[0.12em] text-slate-400">{title}</span>
        )}
        {actions}
      </div>
      {open ? <div className={cn('px-2.5 pb-2.5', dense ? 'space-y-1' : 'space-y-1.5')}>{children}</div> : null}
    </div>
  );
}

export function Row({ label, children, hint }: { label?: string; children: ReactNode; hint?: string }) {
  return (
    <div className="flex items-center gap-2" title={hint}>
      {label ? <span className="w-[68px] shrink-0 text-[10px] uppercase tracking-wide text-slate-500">{label}</span> : null}
      <div className="flex min-w-0 flex-1 items-center gap-1">{children}</div>
    </div>
  );
}

/* ------------------------------------------------------------------ fields */

export function NumberField({
  value,
  onChange,
  onCommit,
  step = 0.1,
  min,
  max,
  disabled,
  suffix,
  title,
  className,
}: {
  value: number;
  onChange: (v: number) => void;
  onCommit?: () => void;
  step?: number;
  min?: number;
  max?: number;
  disabled?: boolean;
  suffix?: string;
  title?: string;
  className?: string;
}) {
  const [draft, setDraft] = useState(String(round(value)));

  useEffect(() => {
    setDraft(String(round(value)));
  }, [value]);

  const commit = () => {
    const parsed = parseFloat(draft);
    if (Number.isFinite(parsed)) {
      let next = parsed;
      if (min !== undefined) next = Math.max(min, next);
      if (max !== undefined) next = Math.min(max, next);
      onChange(next);
      setDraft(String(round(next)));
    } else {
      setDraft(String(round(value)));
    }
    onCommit?.();
  };

  return (
    <div className={cn('relative flex items-center', className)} title={title}>
      <input
        type="text"
        inputMode="decimal"
        value={draft}
        disabled={disabled}
        onChange={(e) => setDraft(e.target.value)}
        onBlur={commit}
        onKeyDown={(e) => {
          if (e.key === 'Enter') (e.target as HTMLInputElement).blur();
          if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
            e.preventDefault();
            const base = parseFloat(draft);
            const next = (Number.isFinite(base) ? base : 0) + (e.key === 'ArrowUp' ? step : -step);
            setDraft(String(round(next)));
            onChange(next);
          }
        }}
        className="w-full rounded border border-[#2a3140] bg-[#0c0f14] px-1.5 py-1 text-right font-mono text-[11px] text-slate-200 outline-none transition-colors focus:border-sky-500 disabled:opacity-40"
      />
      {suffix ? <span className="pointer-events-none absolute right-1 text-[9px] text-slate-600">{suffix}</span> : null}
    </div>
  );
}

export function TextField({
  value,
  onChange,
  onCommit,
  placeholder,
  disabled,
  mono,
  className,
}: {
  value: string;
  onChange: (v: string) => void;
  onCommit?: () => void;
  placeholder?: string;
  disabled?: boolean;
  mono?: boolean;
  className?: string;
}) {
  return (
    <input
      type="text"
      value={value}
      placeholder={placeholder}
      disabled={disabled}
      onChange={(e) => onChange(e.target.value)}
      onBlur={onCommit}
      onKeyDown={(e) => {
        if (e.key === 'Enter') (e.target as HTMLInputElement).blur();
      }}
      className={cn(
        'w-full rounded border border-[#2a3140] bg-[#0c0f14] px-1.5 py-1 text-[11px] text-slate-200 outline-none transition-colors focus:border-sky-500 disabled:opacity-40',
        mono && 'font-mono',
        className,
      )}
    />
  );
}

export function SliderField({
  label,
  value,
  onChange,
  onCommit,
  min = 0,
  max = 1,
  step = 0.01,
  format,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
  onCommit?: () => void;
  min?: number;
  max?: number;
  step?: number;
  format?: (v: number) => string;
}) {
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between">
        <span className="text-[10px] uppercase tracking-wide text-slate-500">{label}</span>
        <span className="font-mono text-[10px] text-slate-400">{format ? format(value) : round(value)}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        onMouseUp={onCommit}
        onTouchEnd={onCommit}
        className="h-1.5 w-full cursor-pointer appearance-none rounded-full bg-[#252b36] accent-sky-400 outline-none [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-sky-400"
      />
    </div>
  );
}

export function CheckField({
  label,
  checked,
  onChange,
  hint,
  disabled,
}: {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
  hint?: string;
  disabled?: boolean;
}) {
  return (
    <label
      className={cn('flex cursor-pointer items-center gap-2 text-[11px] text-slate-300', disabled && 'cursor-not-allowed opacity-50')}
      title={hint}
    >
      <span
        className={cn(
          'flex h-3.5 w-3.5 shrink-0 items-center justify-center rounded border transition-colors',
          checked ? 'border-sky-400 bg-sky-500/80 text-white' : 'border-[#333b4a] bg-[#0c0f14]',
        )}
      >
        {checked ? <Check className="h-2.5 w-2.5" /> : null}
      </span>
      <input
        type="checkbox"
        className="sr-only"
        checked={checked}
        disabled={disabled}
        onChange={(e) => onChange(e.target.checked)}
      />
      <span className="truncate">{label}</span>
    </label>
  );
}

export function ColorField({
  label,
  value,
  onChange,
  onCommit,
}: {
  label?: string;
  value: string;
  onChange: (v: string) => void;
  onCommit?: () => void;
}) {
  return (
    <Row label={label}>
      <input
        type="color"
        value={value && value.startsWith('#') ? value : '#ffffff'}
        onChange={(e) => onChange(e.target.value)}
        onBlur={onCommit}
        className="h-6 w-8 shrink-0 cursor-pointer rounded border border-[#2a3140] bg-[#0c0f14] p-0.5"
      />
      <TextField value={value} onChange={onChange} onCommit={onCommit} mono />
    </Row>
  );
}

export function SelectField({
  label,
  value,
  options,
  onChange,
}: {
  label?: string;
  value: string;
  options: Array<{ value: string; label: string }>;
  onChange: (v: string) => void;
}) {
  return (
    <Row label={label}>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded border border-[#2a3140] bg-[#0c0f14] px-1.5 py-1 text-[11px] text-slate-200 outline-none focus:border-sky-500"
      >
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </Row>
  );
}

/* ----------------------------------------------------------------- buttons */

export function Button({
  children,
  onClick,
  icon: Icon,
  variant = 'default',
  size = 'md',
  disabled,
  active,
  title,
  className,
}: {
  children?: ReactNode;
  onClick?: () => void;
  icon?: LucideIcon;
  variant?: 'default' | 'primary' | 'danger' | 'ghost';
  size?: 'sm' | 'md';
  disabled?: boolean;
  active?: boolean;
  title?: string;
  className?: string;
}) {
  const variants: Record<string, string> = {
    default: 'border-[#2b323f] bg-[#1a1f29] hover:border-[#39424f] hover:bg-[#222835] text-slate-200',
    primary: 'border-sky-500/60 bg-sky-500/15 hover:bg-sky-500/25 text-sky-200',
    danger: 'border-rose-500/50 bg-rose-500/10 hover:bg-rose-500/20 text-rose-200',
    ghost: 'border-transparent bg-transparent hover:bg-white/5 text-slate-300',
  };
  return (
    <button
      type="button"
      title={title}
      disabled={disabled}
      onClick={onClick}
      className={cn(
        'inline-flex items-center justify-center gap-1.5 rounded border font-medium transition-colors disabled:cursor-not-allowed disabled:opacity-40',
        size === 'sm' ? 'px-1.5 py-0.5 text-[10px]' : 'px-2 py-1 text-[11px]',
        variants[variant],
        active && 'border-sky-400/70 bg-sky-500/20 text-sky-100',
        className,
      )}
    >
      {Icon ? <Icon className={size === 'sm' ? 'h-3 w-3' : 'h-3.5 w-3.5'} /> : null}
      {children}
    </button>
  );
}

export function IconButton({
  icon: Icon,
  label,
  onClick,
  active,
  disabled,
  tone = 'default',
  className,
}: {
  icon: LucideIcon;
  label: string;
  onClick?: () => void;
  active?: boolean;
  disabled?: boolean;
  tone?: 'default' | 'danger' | 'primary';
  className?: string;
}) {
  return (
    <button
      type="button"
      title={label}
      aria-label={label}
      disabled={disabled}
      onClick={onClick}
      className={cn(
        'group relative inline-flex h-6 w-6 shrink-0 items-center justify-center rounded border transition-colors disabled:cursor-not-allowed disabled:opacity-35',
        active
          ? 'border-sky-400/70 bg-sky-500/20 text-sky-200'
          : 'border-transparent text-slate-400 hover:border-[#333c4a] hover:bg-[#1c222c] hover:text-slate-100',
        tone === 'danger' && 'hover:border-rose-500/50 hover:bg-rose-500/10 hover:text-rose-300',
        tone === 'primary' && 'text-sky-300',
        className,
      )}
    >
      <Icon className="h-3.5 w-3.5" />
    </button>
  );
}

/* ------------------------------------------------------------------- menu */

export interface MenuItem {
  label?: string;
  icon?: LucideIcon;
  onClick?: () => void;
  disabled?: boolean;
  shortcut?: string;
  separator?: boolean;
  checked?: boolean;
  hint?: string;
}

export function Menu({
  items,
  trigger,
  align = 'left',
  width = 230,
}: {
  items: MenuItem[];
  trigger: ReactNode;
  align?: 'left' | 'right';
  width?: number;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    window.addEventListener('mousedown', onDown);
    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener('mousedown', onDown);
      window.removeEventListener('keydown', onKey);
    };
  }, [open]);

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className={cn(
          'inline-flex items-center gap-1.5 rounded border px-2 py-1 text-[11px] font-medium transition-colors',
          open
            ? 'border-sky-400/60 bg-sky-500/15 text-sky-100'
            : 'border-[#2b323f] bg-[#1a1f29] text-slate-200 hover:border-[#39424f] hover:bg-[#222835]',
        )}
        aria-expanded={open}
        aria-haspopup="menu"
      >
        {trigger}
        <ChevronDown className="h-3 w-3 opacity-60" />
      </button>
      {open ? (
        <div
          role="menu"
          style={{ width } as CSSProperties}
          className={cn(
            'absolute z-50 mt-1 max-h-[70vh] overflow-y-auto rounded-md border border-[#2b323f] bg-[#161a22] py-1 shadow-2xl shadow-black/60',
            align === 'right' ? 'right-0' : 'left-0',
          )}
        >
          {items.map((item, i) =>
            item.separator ? (
              <div key={`sep-${i}`} className="my-1 h-px bg-[#262c37]" />
            ) : (
              <button
                key={`${item.label}-${i}`}
                type="button"
                role="menuitem"
                disabled={item.disabled}
                title={item.hint}
                onClick={() => {
                  setOpen(false);
                  item.onClick?.();
                }}
                className="flex w-full items-center gap-2 px-2.5 py-1.5 text-left text-[11px] text-slate-300 transition-colors hover:bg-sky-500/10 hover:text-sky-100 disabled:cursor-not-allowed disabled:opacity-40"
              >
                {item.icon ? <item.icon className="h-3.5 w-3.5 shrink-0 text-slate-500" /> : <span className="w-3.5" />}
                <span className="flex-1 truncate">{item.label}</span>
                {item.checked ? <Check className="h-3 w-3 text-sky-400" /> : null}
                {item.shortcut ? <span className="font-mono text-[9px] text-slate-600">{item.shortcut}</span> : null}
              </button>
            ),
          )}
        </div>
      ) : null}
    </div>
  );
}

/* -------------------------------------------------------------- misc bits */

export function Segmented({
  value,
  options,
  onChange,
}: {
  value: string;
  options: Array<{ value: string; label: string; icon?: LucideIcon; title?: string }>;
  onChange: (v: string) => void;
}) {
  return (
    <div className="inline-flex items-center gap-0.5 rounded border border-[#2b323f] bg-[#141821] p-0.5">
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          title={o.title ?? o.label}
          onClick={() => onChange(o.value)}
          className={cn(
            'inline-flex items-center gap-1 rounded px-1.5 py-1 text-[10px] font-medium transition-colors',
            value === o.value ? 'bg-sky-500/20 text-sky-100' : 'text-slate-400 hover:bg-white/5 hover:text-slate-200',
          )}
        >
          {o.icon ? <o.icon className="h-3 w-3" /> : null}
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Tag({ children, tone = 'neutral' }: { children: ReactNode; tone?: 'neutral' | 'sky' | 'amber' | 'rose' | 'emerald' }) {
  const tones: Record<string, string> = {
    neutral: 'border-[#333b4a] bg-[#1b212b] text-slate-400',
    sky: 'border-sky-500/40 bg-sky-500/10 text-sky-300',
    amber: 'border-amber-500/40 bg-amber-500/10 text-amber-300',
    rose: 'border-rose-500/40 bg-rose-500/10 text-rose-300',
    emerald: 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300',
  };
  return (
    <span className={cn('rounded border px-1.5 py-0.5 font-mono text-[9px] uppercase tracking-wide', tones[tone])}>{children}</span>
  );
}

export function EmptyHint({
  icon: Icon,
  title,
  description,
  children,
}: {
  icon?: LucideIcon;
  title: string;
  description?: string;
  children?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center gap-2 px-4 py-8 text-center">
      {Icon ? <Icon className="h-6 w-6 text-slate-600" /> : null}
      <p className="text-[12px] font-medium text-slate-400">{title}</p>
      {description ? <p className="max-w-[240px] text-[11px] leading-relaxed text-slate-500">{description}</p> : null}
      {children}
    </div>
  );
}

export function TabStrip({
  tabs,
  value,
  onChange,
  right,
}: {
  tabs: Array<{ value: string; label: string; icon?: LucideIcon; badge?: string }>;
  value: string;
  onChange: (v: string) => void;
  right?: ReactNode;
}) {
  return (
    <div className="flex h-9 shrink-0 items-stretch gap-0.5 overflow-x-auto border-b border-[#232833] bg-[#151922] px-1.5">
      {tabs.map((tab) => {
        const active = tab.value === value;
        return (
          <button
            key={tab.value}
            type="button"
            onClick={() => onChange(tab.value)}
            className={cn(
              'relative inline-flex shrink-0 items-center gap-1.5 px-2.5 text-[11px] font-medium transition-colors',
              active ? 'text-sky-200' : 'text-slate-400 hover:text-slate-200',
            )}
          >
            {tab.icon ? <tab.icon className="h-3.5 w-3.5" /> : null}
            {tab.label}
            {tab.badge ? (
              <span className="rounded bg-[#232a36] px-1 font-mono text-[9px] text-slate-400">{tab.badge}</span>
            ) : null}
            <span
              className={cn(
                'absolute inset-x-1.5 bottom-0 h-[2px] rounded-full transition-colors',
                active ? 'bg-sky-400' : 'bg-transparent',
              )}
            />
          </button>
        );
      })}
      {right ? <div className="ml-auto flex shrink-0 items-center gap-1 pr-1">{right}</div> : null}
    </div>
  );
}

export function CopyButton({ text, label = 'Copy' }: { text: string; label?: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      type="button"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(text);
          setCopied(true);
          window.setTimeout(() => setCopied(false), 1400);
        } catch {
          setCopied(false);
        }
      }}
      className="inline-flex items-center gap-1 rounded border border-[#2b323f] bg-[#1a1f29] px-1.5 py-0.5 text-[10px] text-slate-300 transition-colors hover:border-sky-500/50 hover:text-sky-200"
    >
      {copied ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
      {copied ? 'Copied' : label}
    </button>
  );
}

export function CodeBlock({ code, title, note, maxHeight = 420 }: { code: string; title?: string; note?: string; maxHeight?: number }) {
  return (
    <div className="overflow-hidden rounded-md border border-[#252b36] bg-[#0b0e13]">
      <div className="flex items-center gap-2 border-b border-[#1f242e] bg-[#12161d] px-2.5 py-1.5">
        <span className="font-mono text-[10px] uppercase tracking-wide text-slate-400">{title ?? 'code'}</span>
        <div className="ml-auto">
          <CopyButton text={code} />
        </div>
      </div>
      <pre className="overflow-auto p-3 font-mono text-[11px] leading-[1.6] text-slate-300" style={{ maxHeight }}>
        <code>{code}</code>
      </pre>
      {note ? <p className="border-t border-[#1f242e] bg-[#0f131a] px-2.5 py-1.5 text-[10px] text-slate-500">{note}</p> : null}
    </div>
  );
}

export function CloseX({ onClick, label }: { onClick: () => void; label: string }) {
  return (
    <button
      type="button"
      aria-label={label}
      onClick={onClick}
      className="inline-flex h-7 w-7 items-center justify-center rounded border border-[#2b323f] bg-[#1a1f29] text-slate-400 transition-colors hover:text-slate-100"
    >
      <X className="h-3.5 w-3.5" />
    </button>
  );
}

export function round(n: number): number {
  if (!Number.isFinite(n)) return 0;
  return Math.round(n * 1000) / 1000;
}

export function formatTime(ts: number): string {
  const d = new Date(ts);
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}
