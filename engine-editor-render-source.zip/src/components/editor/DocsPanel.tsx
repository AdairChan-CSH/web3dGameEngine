/**
 * "API & Docs" tab — the in-app manual.
 *
 * Everything a project owner or integrator needs: the scripting quickstart +
 * reference, the external control API, the postMessage/iframe bridge, the
 * remote-command protocol and the full PHP bridge sources with curl examples.
 */

import { useState } from 'react';
import { BookOpen, Code2, Copy, Link2, Radio, Server, Sparkles, Terminal, Keyboard } from 'lucide-react';
import {
  CURL_EXAMPLES,
  PHP_BRIDGE,
  PHP_REST_RELAY,
  POSTMESSAGE_EXAMPLE,
  SCRIPTS_QUICKSTART,
  SCRIPT_EXAMPLE,
  SCRIPT_REFERENCE,
  WEBSOCKET_NOTE,
  WS_PROTOCOL,
} from '@/engine/docs';
import { API_METHODS } from '@/engine/docs';
import { CodeBlock, CopyButton, Tag } from './ui';
import { cn } from '@/lib/utils';

const SECTIONS = [
  { id: 'scripting', label: 'Scripting', icon: Code2 },
  { id: 'reference', label: 'Script reference', icon: Sparkles },
  { id: 'api', label: 'External API', icon: Terminal },
  { id: 'postmessage', label: 'postMessage / iframe', icon: Link2 },
  { id: 'remote', label: 'Remote control', icon: Radio },
  { id: 'php', label: 'PHP bridge', icon: Server },
  { id: 'shortcuts', label: 'Shortcuts', icon: Keyboard },
];

const COMMAND_FORMAT = `// A command packet (postMessage, WebSocket or HTTP poll — all identical)
{
  "target": "engine",        // required for postMessage, ignored elsewhere
  "id": 42,                  // echoed back so the caller can match the reply
  "method": "setPosition",   // any name from the External API table
  "args": ["obj_3", 0, 4, 0] // positional arguments; "<selected>" = editor selection
}

// The engine answers every packet with
{ "target": "parent", "id": 42, "ok": true, "result": true }
// and, when a call fails
{ "target": "parent", "id": 42, "ok": false, "error": "No object with id 'obj_3'" }`;

const LIFECYCLE_NOTES = `// One class per script. The class name must match the file's script name.
// Types: float int double string bool Vector3 Quaternion GameObject Collision
// Statements: let/var, assignments, if / else if / else, while, for, return
// Operators:  + - * / %   == != < <= > >=   && || !   (strings concatenate with +)

class SpinJump extends Component {
  public float speed = 90.0;
  public int jumpsBeforeReport = 3;

  int jumps = 0;

  void Start() {
    Debug.log(this.object.name + " ready, speed=" + this.speed);
  }

  void Update(float dt) {
    this.transform.rotate(0.0, this.speed * dt, 0.0);

    if (Input.getKeyDown("space")) {
      this.jumps = this.jumps + 1;
      this.emit("jump", this.jumps);
      if (this.jumps >= this.jumpsBeforeReport) {
        Debug.log("That is " + this.jumps + " jumps");
        this.jumps = 0;
      }
    }
  }

  void OnCollision(Collision other) {
    Debug.log("hit " + other.name);
  }
}`;

const PHP_SETUP = `1. Save the two snippets below as engine_bridge.php and control.php on any PHP host.
2. In the editor open Remote Control → transport "HTTP polling" and enter:
       https://your-host/engine_bridge.php?action=poll
3. Press Connect — the engine starts polling that URL every 2 seconds.
4. Queue work from PHP, your phone, a webhook or curl (see the curl examples below).
5. Watch the packets in the Remote Control traffic log, and the effects in the scene.`;

const SHORTCUTS: Array<[string, string]> = [
  ['Left click', 'Select object (raycast pick)'],
  ['Drag gizmo', 'Move / rotate / scale the selection'],
  ['W / E / R', 'Translate / rotate / scale gizmo'],
  ['F', 'Frame the selection'],
  ['Delete', 'Delete the selection'],
  ['Ctrl + D', 'Duplicate the selection'],
  ['Ctrl + Z', 'Undo'],
  ['Ctrl + Shift + Z', 'Redo'],
  ['Ctrl + S', 'Save the project into this browser'],
  ['Escape', 'Clear the selection / release the mouse'],
  ['Play → W A S D', 'Move the player (Space jumps)'],
  ['Play → mouse', 'Look around after clicking the Game view'],
  ['Play → click object', 'Fires that object\'s OnClick() script hook'],
];

export function DocsPanel() {
  const [active, setActive] = useState('scripting');

  const go = (id: string) => {
    setActive(id);
    const el = document.getElementById(`doc-${id}`);
    el?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <div className="flex h-full min-h-0 flex-col bg-[#0e1116]">
      <header className="flex shrink-0 flex-wrap items-center gap-2 border-b border-[#232833] bg-[#151922] px-3 py-2">
        <BookOpen className="h-4 w-4 text-sky-400" />
        <h2 className="text-[12px] font-semibold tracking-tight text-slate-200">API &amp; Docs</h2>
        <style>{`
          .doc-p { font-size: 12px; line-height: 1.7; color: #94a3b8; }
          .doc-code { font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-size: 11px; color: #7dd3fc; background: #0b0e13; padding: 0 3px; border-radius: 3px; }
          .doc-list { list-style: decimal; padding-left: 20px; font-size: 12px; line-height: 1.75; color: #94a3b8; }
          .doc-list li { margin-bottom: 2px; }
        `}</style>
        <Tag tone="sky">no build step · no backend required</Tag>
        <Tag tone="neutral">{API_METHODS.length} API methods</Tag>
      </header>

      <div className="flex shrink-0 items-center gap-1 overflow-x-auto border-b border-[#1c212a] bg-[#12161d] px-2 py-1.5">
        {SECTIONS.map((section) => (
          <button
            key={section.id}
            type="button"
            onClick={() => go(section.id)}
            className={cn(
              'inline-flex shrink-0 items-center gap-1.5 rounded border px-2 py-1 text-[10px] transition-colors',
              active === section.id
                ? 'border-sky-500/50 bg-sky-500/15 text-sky-200'
                : 'border-[#262d38] text-slate-400 hover:border-[#39424f] hover:text-slate-200',
            )}
          >
            <section.icon className="h-3 w-3" />
            {section.label}
          </button>
        ))}
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto px-3 py-4">
        <div className="mx-auto max-w-4xl space-y-8 pb-10">
          {/* ---------------------------------------------------------- hero */}
          <section className="rounded-lg border border-[#252b36] bg-gradient-to-br from-[#151b26] to-[#11151c] p-4">
            <h1 className="text-[17px] font-semibold tracking-tight text-slate-100">WebForge — a 3D game engine that lives in the browser</h1>
            <p className="mt-1.5 max-w-2xl text-[12px] leading-relaxed text-slate-400">
              The whole editor is a single page: a WebGL renderer (three.js from a CDN), a scene graph, a component/script VM written for this
              project, lightweight physics, and the docking UI you are looking at. There is no bundler step for your content and no server: projects
              autosave to this browser and can be exported as JSON or glTF.
            </p>
            <div className="mt-3 grid gap-2 sm:grid-cols-3">
              {[
                { title: 'In the editor', body: 'Panels, gizmos, play mode, console, script editor.' },
                { title: 'From any page', body: 'window.Engine, or postMessage when the editor is embedded in an iframe.' },
                { title: 'From a server', body: 'WebSocket or HTTP polling through the remote bridge, with a bundled PHP relay.' },
              ].map((card) => (
                <div key={card.title} className="rounded border border-[#262d38] bg-[#0f131a] px-2.5 py-2">
                  <p className="text-[11px] font-semibold text-slate-200">{card.title}</p>
                  <p className="mt-0.5 text-[11px] leading-relaxed text-slate-500">{card.body}</p>
                </div>
              ))}
            </div>
          </section>

          {/* ----------------------------------------------------- scripting */}
          <DocSection id="scripting" icon={Code2} title="Writing scripts" subtitle="C#-flavoured, interpreted in the page — never eval()">
            <p className="doc-p">
              Scripts are attached to objects in the Inspector. Public fields become editable inputs, and the lifecycle methods below are called by the
              engine. Your code is tokenised, parsed and executed by the engine's own interpreter: it has no access to the DOM, the network or the
              page, so a broken script can only ever produce console errors.
            </p>
            <CodeBlock code={SCRIPTS_QUICKSTART} title="script-editor quickstart" />
            <CodeBlock code={LIFECYCLE_NOTES} title="types, statements and lifecycle" />
          </DocSection>

          {/* ----------------------------------------------------- reference */}
          <DocSection id="reference" icon={Sparkles} title="Scripting reference" subtitle="Every built-in available inside a user script">
            <div className="space-y-4">
              {SCRIPT_REFERENCE.map((group) => (
                <div key={group.group} className="overflow-hidden rounded border border-[#262d38]">
                  <div className="border-b border-[#20252e] bg-[#151a23] px-2.5 py-1.5 text-[11px] font-semibold text-slate-200">{group.group}</div>
                  <div className="divide-y divide-[#1a1f28]">
                    {group.entries.map((entry) => (
                      <div key={entry.signature} className="grid gap-1 px-2.5 py-1.5 sm:grid-cols-[minmax(180px,240px)_1fr]">
                        <code className="font-mono text-[10px] text-emerald-200">{entry.signature}</code>
                        <p className="text-[11px] leading-relaxed text-slate-400">{entry.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
            <CodeBlock code={SCRIPT_EXAMPLE} title="example — PlayerController" />
          </DocSection>

          {/* ----------------------------------------------------------- api */}
          <DocSection id="api" icon={Terminal} title="External control API" subtitle="window.Engine — the same object as window.GameEngine">
            <p className="doc-p">
              Every documented call is available on the global <code className="doc-code">Engine</code> object: from the browser console, from another
              script on the page, from an embedded iframe or from the remote bridge. The <span className="text-slate-200">External API</span> tab lists
              all {API_METHODS.length} methods with a live Run button; the shape of every call is:
            </p>
            <CodeBlock
              code={`Engine.createObject("Goal", "Torus")            // → "obj_7"
Engine.setColor("obj_7", "#7c5cff")
Engine.animate("obj_7", {
  position: [0, 5, 0],
  rotation: [0, 720, 0],
  duration: 2.5,
  loop: true,
  yoyo: true,
  easing: "easeInOut"
})
Engine.on("player_jump", (payload) => console.log(payload))
Engine.getStats()                                // fps, draw calls, objects`}
              title="console.js"
            />
            <div className="flex flex-wrap items-center gap-2">
              <CopyButton text={`Engine.ping()`} label="Copy Engine.ping()" />
              <span className="text-[11px] text-slate-500">
                Open the browser console and paste it — the editor answers even while paused.
              </span>
            </div>
          </DocSection>

          {/* --------------------------------------------------- postMessage */}
          <DocSection id="postmessage" icon={Link2} title="Embed &amp; control from another page" subtitle="window.postMessage protocol">
            <p className="doc-p">
              The engine listens for messages that carry <code className="doc-code">target: "engine"</code>, executes the requested method and replies to
              the sender. That makes the editor usable as an embeddable 3D view that the surrounding page drives — a CMS, a product configurator, a
              kiosk. The same messages are accepted from any origin, so no CORS setup is needed for the parent page.
            </p>
            <CodeBlock code={COMMAND_FORMAT} title="command + reply format" />
            <CodeBlock code={POSTMESSAGE_EXAMPLE} title="parent.html — working example" />
          </DocSection>

          {/* ------------------------------------------------------- remote */}
          <DocSection id="remote" icon={Radio} title="Remote control bridge" subtitle="Mock server · WebSocket · HTTP polling">
            <p className="doc-p">
              Open <span className="text-slate-200">Remote Control</span> in the viewport tabs. Choose a transport, press Connect and watch the traffic
              log. The built-in mock server streams realistic packets so the whole feature can be demonstrated with nothing running outside the page.
            </p>
            <div className="grid gap-2 sm:grid-cols-3">
              <ModeCard
                title="Built-in mock"
                body="No backend. Sends random moves, colours, spawns and animations every couple of seconds and shows the replies."
              />
              <ModeCard
                title="WebSocket"
                body="ws:// or wss:// endpoint. Handshake on open, then { id, method, args } packets in both directions."
              />
              <ModeCard
                title="HTTP polling"
                body="POSTs to a URL every 2s, executes the returned command list and reports each result back."
              />
            </div>
            <CodeBlock code={WS_PROTOCOL} title="websocket protocol" />
            <CodeBlock code={WEBSOCKET_NOTE} title="about websockets + php" />
          </DocSection>

          {/* ---------------------------------------------------------- php */}
          <DocSection id="php" icon={Server} title="PHP bridge" subtitle="engine_bridge.php + control.php — copy, paste, done">
            <p className="doc-p">
              A plain-PHP relay is included because it is the lowest-friction way to drive the engine from a server, a form or a cron job. It stores
              queued commands in a file, hands them to the engine when it polls, and collects the responses — so your PHP code can read what actually
              happened in the scene.
            </p>
            <ol className="doc-list">
              {PHP_SETUP.split('\n').map((line) => (
                <li key={line}>{line.replace(/^\d+\.\s*/, '')}</li>
              ))}
            </ol>
            <CodeBlock code={PHP_BRIDGE} title="engine_bridge.php" maxHeight={520} />
            <CodeBlock code={PHP_REST_RELAY} title="control.php — one-call REST relay" maxHeight={420} />
            <CodeBlock code={CURL_EXAMPLES} title="curl examples" />
          </DocSection>

          {/* ---------------------------------------------------- shortcuts */}
          <DocSection id="shortcuts" icon={Keyboard} title="Keyboard shortcuts" subtitle="Editor and play-mode controls">
            <div className="overflow-hidden rounded border border-[#262d38]">
              {SHORTCUTS.map(([keys, action]) => (
                <div key={keys} className="flex flex-wrap items-center gap-2 border-b border-[#1a1f28] px-2.5 py-1.5 last:border-0">
                  <kbd className="rounded border border-[#333b4a] bg-[#0f131a] px-1.5 py-0.5 font-mono text-[10px] text-slate-300">{keys}</kbd>
                  <span className="text-[11px] text-slate-400">{action}</span>
                </div>
              ))}
            </div>
            <p className="doc-p">
              Projects autosave into this browser (localStorage) as you work. Use <span className="text-slate-200">File → Export project JSON</span> for a
              portable copy, <span className="text-slate-200">File → Export scene as glTF</span> to hand the geometry to another tool, and the Import
              Model item to bring .glb/.gltf/.obj files in (they are cached in this browser's IndexedDB so saving keeps them).
            </p>
          </DocSection>
        </div>
      </div>
    </div>
  );
}

function DocSection({
  id,
  icon: Icon,
  title,
  subtitle,
  children,
}: {
  id: string;
  icon: any;
  title: string;
  subtitle: string;
  children: React.ReactNode;
}) {
  return (
    <section id={`doc-${id}`} className="scroll-mt-4 space-y-3">
      <div className="flex items-center gap-2 border-b border-[#232833] pb-2">
        <Icon className="h-4 w-4 text-sky-400" />
        <h2 className="text-[14px] font-semibold tracking-tight text-slate-100" dangerouslySetInnerHTML={{ __html: title }} />
        <span className="ml-1 hidden text-[11px] text-slate-500 sm:inline">— {subtitle}</span>
      </div>
      <div className="space-y-3">{children}</div>
    </section>
  );
}

function ModeCard({ title, body }: { title: string; body: string }) {
  return (
    <div className="rounded border border-[#262d38] bg-[#0f131a] px-2.5 py-2">
      <p className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-200">
        <Copy className="h-3 w-3 text-sky-300" />
        {title}
      </p>
      <p className="mt-0.5 text-[11px] leading-relaxed text-slate-500">{body}</p>
    </div>
  );
}
