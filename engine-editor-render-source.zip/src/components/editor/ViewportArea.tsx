/**
 * Central viewport: tabbed between the Scene view (orbit camera + gizmo) and the
 * Game view (play camera, HUD, touch controls), plus the API / Remote / Docs tabs.
 *
 * The WebGL canvas is created by the engine and mounted into this component's host
 * div; it stays mounted (hidden) while the documentation tabs are open so the
 * editor repaints instantly when you switch back.
 *
 * A prefab card dragged out of the Prefabs panel can be dropped straight onto the
 * canvas: the engine raycasts the scene at the cursor and places the copy there.
 */

import { useEffect, useRef, useState } from 'react';
import {
  ArrowBigUp,
  BookOpen,
  Boxes,
  Crosshair,
  Gamepad2,
  Grid2x2,
  LayoutGrid,
  MousePointerClick,
  Radio,
  RotateCcw,
  Sun,
  Terminal,
  Video,
  Move,
  ChevronUp,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { useEngine, useEngineStats, useEngineVersion, useIsCompact } from '@/engine/engine-context';
import { readPrefabDragId } from '@/engine/prefab-drag';
import { Segmented, Tag, IconButton } from './ui';
import { ExternalApiPanel } from './ExternalApiPanel';
import { RemoteControlPanel } from './RemoteControlPanel';
import { DocsPanel } from './DocsPanel';
import { cn } from '@/lib/utils';
import type { ViewTab } from '@/engine/types';

export function ViewportArea({ tab, onTab }: { tab: ViewTab; onTab: (t: ViewTab) => void }) {
  const core = useEngine();
  useEngineVersion();
  const stats = useEngineStats();
  const { isCompact } = { isCompact: useIsCompact(1024) };
  const hostRef = useRef<HTMLDivElement>(null);
  const isViewport = tab === 'scene' || tab === 'game';
  /** true while a prefab is hovering the canvas — drives the strong drop outline */
  const [dropReady, setDropReady] = useState(false);

  // mount / size the canvas
  useEffect(() => {
    if (!isViewport) return;
    core.mountViewport(hostRef.current);
  }, [core, isViewport, core.ready]);

  // prefab drag & drop onto the 3D canvas — the drop lands where the cursor is
  useEffect(() => {
    if (!isViewport) return;
    const canvas: HTMLElement | undefined = core.renderer?.domElement;
    if (!canvas) return;

    const onDragOver = (event: DragEvent) => {
      if (!readPrefabDragId(event.dataTransfer)) return;
      event.preventDefault();
      if (event.dataTransfer) event.dataTransfer.dropEffect = 'copy';
      setDropReady(true);
    };
    const onDragLeave = () => setDropReady(false);
    const onDrop = (event: DragEvent) => {
      const prefabId = readPrefabDragId(event.dataTransfer);
      if (!prefabId) return;
      event.preventDefault();
      setDropReady(false);
      core.placePrefabAtScreen(prefabId, event.clientX, event.clientY);
    };

    canvas.addEventListener('dragover', onDragOver);
    canvas.addEventListener('dragleave', onDragLeave);
    canvas.addEventListener('drop', onDrop);
    return () => {
      canvas.removeEventListener('dragover', onDragOver);
      canvas.removeEventListener('dragleave', onDragLeave);
      canvas.removeEventListener('drop', onDrop);
      setDropReady(false);
    };
  }, [core, isViewport, core.ready]);

  useEffect(() => {
    core.setViewTab(tab === 'game' ? 'game' : 'scene');
  }, [core, tab]);

  // Pressing Play hands the viewport to the game camera — mirror that in the tabs
  // so the UI never shows "Scene" while the game camera is rendering.
  useEffect(() => {
    if (core.viewTab === 'game' && tab !== 'game') onTab('game');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [core.viewTab, tab, core.version]);

  useEffect(() => {
    const onResize = () => core.resize();
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, [core]);

  const selected = core.getSelected();
  const sceneObjects = core.objectsOrEmpty();
  const cameraMode = sceneObjects.find((o) => o.cameraParams?.isMain)
    ? 'Main Camera object'
    : sceneObjects.some((o) => o.isPlayer)
      ? 'First-person follow'
      : 'Free camera';

  return (
    <section className="flex min-h-0 flex-1 flex-col bg-[#0e1116]">
      {/* tab bar */}
      <div className="flex h-9 shrink-0 items-stretch gap-0.5 overflow-x-auto border-b border-[#232833] bg-[#151922] px-1.5">
        {(
          [
            { value: 'scene', label: 'Scene', icon: Boxes },
            { value: 'game', label: 'Game', icon: Gamepad2 },
            { value: 'api', label: 'External API', icon: Terminal },
            { value: 'remote', label: 'Remote Control', icon: Radio },
            { value: 'docs', label: 'API & Docs', icon: BookOpen },
          ] as const
        ).map((item) => {
          const active = item.value === tab;
          return (
            <button
              key={item.value}
              type="button"
              onClick={() => onTab(item.value as ViewTab)}
              className={cn(
                'relative inline-flex shrink-0 items-center gap-1.5 px-2.5 text-[11px] font-medium transition-colors',
                active ? 'text-sky-200' : 'text-slate-400 hover:text-slate-200',
              )}
            >
              <item.icon className="h-3.5 w-3.5" />
              {item.label}
              {item.value === 'game' && core.playState === 'playing' ? (
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
              ) : null}
              <span className={cn('absolute inset-x-1.5 bottom-0 h-[2px] rounded-full', active ? 'bg-sky-400' : 'bg-transparent')} />
            </button>
          );
        })}

        <div className="ml-auto flex shrink-0 items-center gap-1 pr-1">
          <IconButton
            icon={LayoutGrid}
            label="Toggle ground grid"
            active={core.environment.grid}
            onClick={() => core.setEnvironment({ grid: !core.environment.grid })}
          />
          <IconButton
            icon={Sun}
            label="Toggle shadows"
            active={core.environment.shadows}
            onClick={() => core.setEnvironment({ shadows: !core.environment.shadows })}
          />
          <IconButton icon={Crosshair} label="Frame selection (F)" onClick={() => core.focusSelected()} />
          <IconButton icon={RotateCcw} label="Reset editor view" onClick={() => { core.select(null); core.focusSelected(); }} />
          <Segmented
            value={core.environment.sky}
            onChange={(v) => core.setEnvironment({ sky: v as any })}
            options={[
              { value: 'dusk', label: 'Dusk' },
              { value: 'noon', label: 'Noon' },
              { value: 'night', label: 'Night' },
              { value: 'neon', label: 'Neon' },
            ]}
          />
        </div>
      </div>

      {/* 3D host — always mounted so the WebGL context survives tab switches */}
      <div className={cn('relative min-h-0 flex-1', isViewport ? 'block' : 'hidden')}>
        <div ref={hostRef} className="absolute inset-0" />

        {/* prefab drop target — faint while a prefab is being dragged, strong over the canvas */}
        <div
          aria-hidden="true"
          className={cn(
            'prefab-drop-affordance pointer-events-none absolute inset-0 z-10 border-2 border-dashed',
            dropReady ? 'border-emerald-400/90 bg-emerald-400/10' : 'border-sky-400/40 bg-transparent',
          )}
        >
          {dropReady ? (
            <span className="absolute left-1/2 top-3 -translate-x-1/2 rounded border border-emerald-400/60 bg-[#0c1014]/90 px-2 py-1 font-mono text-[10px] text-emerald-200">
              Drop to place at the cursor
            </span>
          ) : null}
        </div>

        {/* top-left status */}
        <div className="pointer-events-none absolute left-2 top-2 flex flex-col gap-1">
          <div className="pointer-events-auto flex items-center gap-1.5 rounded border border-[#2a3140]/80 bg-[#0c1014]/85 px-2 py-1 backdrop-blur">
            <span className={cn('h-1.5 w-1.5 rounded-full', core.playState === 'playing' ? 'bg-emerald-400' : core.playState === 'paused' ? 'bg-amber-400' : 'bg-slate-500')} />
            <span className="font-mono text-[10px] uppercase tracking-wide text-slate-300">
              {core.playState === 'playing' ? 'playing' : core.playState === 'paused' ? 'paused' : 'editing'}
            </span>
            <span className="font-mono text-[10px] text-slate-500">{tab === 'game' ? 'game camera' : 'scene camera'}</span>
            {tab === 'game' ? <Tag tone="sky">{cameraMode}</Tag> : null}
          </div>
          {selected ? (
            <div className="pointer-events-auto flex items-center gap-1.5 rounded border border-[#2a3140]/80 bg-[#0c1014]/85 px-2 py-1 backdrop-blur">
              <MousePointerClick className="h-3 w-3 text-sky-300" />
              <span className="font-mono text-[10px] text-slate-200">{selected.name}</span>
              <span className="font-mono text-[10px] text-slate-500">
                {round2(selected.three.position.x)}, {round2(selected.three.position.y)}, {round2(selected.three.position.z)}
              </span>
            </div>
          ) : null}
        </div>

        {/* top-right stats HUD */}
        <div className="pointer-events-none absolute right-2 top-2 rounded border border-[#2a3140]/80 bg-[#0c1014]/85 px-2 py-1 font-mono text-[10px] text-slate-300 backdrop-blur">
          {stats.fps} fps · {stats.drawCalls} draw calls · {stats.objects} objects
        </div>

        {/* bottom-left controls */}
        <div className="pointer-events-none absolute bottom-2 left-2 max-w-[340px] rounded border border-[#2a3140]/80 bg-[#0c1014]/85 px-2 py-1.5 font-mono text-[10px] leading-relaxed text-slate-400 backdrop-blur">
          {tab === 'game' ? (
            <>
              <p className="text-slate-300">Game view</p>
              <p>WASD / arrows move · Space jump · Shift sprint</p>
              <p>Click the viewport for mouse look (Esc releases)</p>
              <p>Click an object while playing to fire its OnClick</p>
              <p>Objects with a Script show live results in the Console</p>
            </>
          ) : (
            <>
              <p className="text-slate-300">Scene view</p>
              <p>Left click select · drag the gizmo to move</p>
              <p>Left/right drag on empty space orbits · wheel zooms</p>
              <p>W move · E rotate · R scale · F focus · Del remove</p>
              <p>Ctrl+D duplicate · Ctrl+Z undo · Ctrl+S save</p>
              <p>Drag a prefab card here to place it where you drop it</p>
            </>
          )}
        </div>

        {/* touch controls while playing */}
        {isCompact && core.playState === 'playing' && tab === 'game' ? (
          <TouchControls />
        ) : null}
      </div>

      {tab === 'api' ? (
        <div className="min-h-0 flex-1 overflow-hidden">
          <ExternalApiPanel />
        </div>
      ) : null}
      {tab === 'remote' ? (
        <div className="min-h-0 flex-1 overflow-hidden">
          <RemoteControlPanel />
        </div>
      ) : null}
      {tab === 'docs' ? (
        <div className="min-h-0 flex-1 overflow-hidden">
          <DocsPanel />
        </div>
      ) : null}
    </section>
  );
}

function TouchControls() {
  const core = useEngine();
  const hold = (key: string, down: boolean) => () => core.pressVirtualKey(key, down);
  const dpad = 'flex h-9 w-9 items-center justify-center rounded border border-[#3a4453] bg-[#161c26]/90 text-slate-200 active:bg-sky-500/30';

  return (
    <div className="absolute bottom-3 right-3 flex items-end gap-4 select-none">
      <div className="grid grid-cols-3 grid-rows-3 gap-1">
        <span />
        <button type="button" className={dpad} onPointerDown={hold('w', true)} onPointerUp={hold('w', false)} onPointerLeave={hold('w', false)} aria-label="Move forward">
          <ChevronUp className="h-4 w-4" />
        </button>
        <span />
        <button type="button" className={dpad} onPointerDown={hold('a', true)} onPointerUp={hold('a', false)} onPointerLeave={hold('a', false)} aria-label="Move left">
          <ChevronLeft className="h-4 w-4" />
        </button>
        <span />
        <button type="button" className={dpad} onPointerDown={hold('d', true)} onPointerUp={hold('d', false)} onPointerLeave={hold('d', false)} aria-label="Move right">
          <ChevronRight className="h-4 w-4" />
        </button>
        <span />
        <button type="button" className={dpad} onPointerDown={hold('s', true)} onPointerUp={hold('s', false)} onPointerLeave={hold('s', false)} aria-label="Move back">
          <ChevronDown className="h-4 w-4" />
        </button>
        <span />
      </div>
      <button
        type="button"
        aria-label="Jump"
        onPointerDown={hold('space', true)}
        onPointerUp={hold('space', false)}
        onPointerLeave={hold('space', false)}
        className="flex h-14 w-14 items-center justify-center rounded-full border border-sky-400/50 bg-sky-500/20 text-sky-100 active:bg-sky-500/40"
      >
        <ArrowBigUp className="h-5 w-5" />
      </button>
    </div>
  );
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

/* re-exports kept together so the docking layer only imports this module */
export { ExternalApiPanel, RemoteControlPanel, DocsPanel };
export const VIEWPORT_ICONS = { Move, Video, Grid2x2 };
